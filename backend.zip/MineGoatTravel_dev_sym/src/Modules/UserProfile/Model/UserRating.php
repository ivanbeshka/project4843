<?php

namespace App\Modules\UserProfile\Model;

class UserRating
{
    /**
     * @var UserRatingLevel[]
     */
    public array $ratingLevels;

}