<?php

namespace App\Modules\UserProfile\Model;

enum UserRatingType
{
    case Masters;
    case Trips;
    case Skills;
}