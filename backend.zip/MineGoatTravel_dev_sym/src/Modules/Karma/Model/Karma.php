<?php

namespace App\Modules\Karma\Model;

use App\Entity\KarmaIndex;

class Karma
{
    public string $ownerID;

    /**
     * @var KAttribute[]
     */
    public array $attribute;

    /**
     * @param KarmaIndex[] $karmaI
     */
    public static function newInstance(array $karmaI): ?Karma
    {
        if (count($karmaI) == 0) {
            return null;
        }

        $first = array_values($karmaI)[0];
        $karma = new Karma();
        $karma->ownerID = $first->getUserID();
        foreach ($karmaI as $item) {
            $karma->attribute[] = new KAttribute($item);
        }

        return $karma;
    }
}