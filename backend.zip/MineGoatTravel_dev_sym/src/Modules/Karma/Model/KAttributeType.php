<?php

namespace App\Modules\Karma\Model;

enum KAttributeType: string
{
    case Likes = 'Likes';
    case ProfileFullness = 'ProfileFullness';
    case Other = 'Other';
}
