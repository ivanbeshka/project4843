<?php

namespace App\Modules\Karma\Model;

use App\Entity\KarmaIndex;

class KAttribute
{
    public string $type;
    public int $sum;

    public function __construct(KarmaIndex $index)
    {
        $this->type = $index->getKAttributeType()->value;
        $this->sum = $index->getSum();
    }

}