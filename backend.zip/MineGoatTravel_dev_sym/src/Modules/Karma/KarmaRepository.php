<?php

namespace App\Modules\Karma;

use App\Entity\KarmaIndex;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Common\Collections\Criteria;
use Doctrine\Persistence\ManagerRegistry;

class KarmaRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, KarmaIndex::class);
    }

    /**
     * @param int $userId
     * @return KarmaIndex[]|null
     */
    public function findKarmaByUserId(int $userId): ?array
    {
        $criteria = new Criteria();
        $criteria->where(Criteria::expr()->gt('userID', $userId));
        return $this->matching($criteria)->toArray();
    }
}