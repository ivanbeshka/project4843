<?php

namespace App\Modules\Search;

use App\Entity\Trip;
use App\Helpers\FileManager\ImagesManager;
use App\Modules\Search\Model\SearchTripItem;
use App\Modules\Search\Model\ShortMilestone;
use App\Repository\MilestoneRepository;
use App\Repository\TripRepository;

class SearchService
{
    public function __construct(private TripRepository $tripRepository,
                                private MilestoneRepository $milestoneRepository,
                                private ImagesManager $imagesManager)
    {
    }
    /**
     * @param Trip[]|null $trips
     * @return SearchTripItem[]
     */
    private function mapTripsToResponse (?array $trips): array {
        $items = [];
        if (isset($trips)) {
            $shortMilestones = [];
            foreach ($trips as $trip) {
                $shortMilestones[$trip->getObjId()] = $this->milestoneRepository->getShortMilestonesForSearch($trip->getMilestonesIDs());
            }
            $items = array_map(
                fn (Trip $trip) => new SearchTripItem(
                    $trip->getObjId(),
                    $trip->getOwner()->getId(),
                    $trip->getStartDate()->getTimestamp(),
                    $trip->getEndDate()->getTimestamp(),
                    $trip->getTags(),
                    $trip->getMainImage() ? base64_encode($this->imagesManager->getThumbnailDataForImage($trip->getMainImage())) : null,
                    array_reduce($shortMilestones[$trip->getObjId()], fn (?int $carry, ShortMilestone $milestone) => $carry + $milestone->getReviewsNumber()),
                    //array_values(array_filter($shortMilestones[$trip->getObjId()], fn (ShortMilestone $milestone) => $milestone->getType() == 'Город')),
                    array_values($shortMilestones[$trip->getObjId()]),
                    $trip->getName()
                ),
                $trips);
            //dump($items);

        }
        return $items;
    }


    /**
     * @param string $locationID
     * @return SearchTripItem[]
    */
    public function getTripsListWithLocation (string $locationID): array
    {
        $trips = $this->tripRepository->getTripsWithLocation($locationID);
        //dump($trips);
        return $this->mapTripsToResponse($trips);
    }

    /**
     * @param string $userID
     * @return SearchTripItem[]
    */
    public function getUserTripsList (string $userID): array {
        $userID = (int)$userID;
        $trips = [];
        if ($userID > 0) {
            $trips = $this->tripRepository->getUserTrips($userID);
        }
        return $this->mapTripsToResponse($trips);
    }
}


