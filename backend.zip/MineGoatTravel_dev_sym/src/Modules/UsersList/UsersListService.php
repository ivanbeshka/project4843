<?php

namespace App\Modules\UsersList;

use App\Entity\User;
use App\Modules\Karma\KarmaRepository;
use App\Modules\UsersList\Model\UsersListItem;
use Symfony\Component\HttpFoundation\UrlHelper;

class UsersListService
{
    public function __construct(
        private UsersListRepository $usersListRepository,
        private UrlHelper $urlHelper,
        private KarmaRepository $karmaRepository
    ) {
    }


    /**
     * @return UsersListItem[]
     */
    public function getUsersList(): array
    {
        $users = $this->usersListRepository->getUsersWithPhones();

        return array_map(
            fn(User $user) => new UsersListItem(
                $user->getId(),
                $user->getName() ?? $user->getUserIdentifier(),
                $user->getAvatar() != null ? $this->urlHelper->getAbsoluteUrl(
                    '/api/v1/image/'.$user->getAvatar()
                ) : null,
                $this->getKarmaSum($user->getId())
            ),
            $users
        );
    }

    private function getKarmaSum(int $userID): ?int {
        return 50;
//        $karmaIndex = $this->karmaRepository->findKarmaByUserId($userID);
//        return array_sum(array_column($karmaIndex, 'sum'));
    }
}