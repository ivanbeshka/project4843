<?php

namespace App\Modules\UsersList\Model;

class UsersListItem
{
    public string $id;
    public string $name;
    public ?string $avatarURL;
    public int $karmaSum;

    /**
     * @param string $id
     * @param string $name
     * @param string|null $avatarURL
     * @param int|null $karmaSum
     */
    public function __construct(string $id, string $name, ?string $avatarURL, ?int $karmaSum)
    {
        $this->id = $id;
        $this->name = $name;
        $this->avatarURL = $avatarURL;
        $this->karmaSum = $karmaSum ?: 0;
    }

    /**
     * @return string
     */
    public function getId(): string
    {
        return $this->id;
    }

    /**
     * @param string $id
     */
    public function setId(string $id): void
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @return string
     */
    public function getAvatarURL(): string
    {
        return $this->avatarURL;
    }

    /**
     * @param string $avatarURL
     */
    public function setAvatarURL(string $avatarURL): void
    {
        $this->avatarURL = $avatarURL;
    }

    /**
     * @return int
     */
    public function getKarmaSum(): int
    {
        return $this->karmaSum;
    }

    /**
     * @param int $karmaSum
     */
    public function setKarmaSum(int $karmaSum): void
    {
        $this->karmaSum = $karmaSum;
    }

}