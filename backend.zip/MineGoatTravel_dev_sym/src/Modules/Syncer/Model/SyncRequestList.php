<?php

namespace App\Modules\Syncer\Model;

class SyncRequestList
{

}