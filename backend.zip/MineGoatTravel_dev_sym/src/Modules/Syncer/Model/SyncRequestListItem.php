<?php

namespace App\Modules\Syncer\Model;

class SyncRequestListItem
{
    public string $type;
    public mixed $object;
}