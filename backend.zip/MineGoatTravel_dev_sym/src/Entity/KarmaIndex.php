<?php

namespace App\Entity;

use App\Modules\Karma\KarmaRepository;
use App\Modules\Karma\Model\KAttributeType;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: KarmaRepository::class)]
class KarmaIndex
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private int $id;

    #[ORM\Column(type: 'string', length: 64, nullable: false)]
    private string $userID;

    #[ORM\Column(type: 'string', nullable: false, enumType: KAttributeType::class)]
    private KAttributeType $kAttributeType;

    #[ORM\Column(type: 'integer', nullable: false, options: ['default' => 0])]
    private int $sum;

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getUserID(): string
    {
        return $this->userID;
    }

    /**
     * @param string $userID
     */
    public function setUserID(string $userID): void
    {
        $this->userID = $userID;
    }

    /**
     * @return KAttributeType
     */
    public function getKAttributeType(): KAttributeType
    {
        return $this->kAttributeType;
    }

    /**
     * @param KAttributeType $kAttributeType
     */
    public function setKAttributeType(KAttributeType $kAttributeType): void
    {
        $this->kAttributeType = $kAttributeType;
    }

    /**
     * @return int
     */
    public function getSum(): int
    {
        return $this->sum;
    }

    /**
     * @param int $sum
     */
    public function setSum(int $sum): void
    {
        $this->sum = $sum;
    }
}