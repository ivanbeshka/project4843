package ru.minegoat.oversees.domain.user

import ru.minegoat.oversees.R

data class UserRating(
    val ratingLevels: List<UserRatingLevel>
)

data class UserRatingLevel(
    val scale: Int, val points: Int,
    val typeName: String,

    val type: RatingTypeName? = RatingTypeName.valueOf(typeName.uppercase()),

    val name: RatingLevelName? = type?.run{RatingLevelName.fromLevel(RatingTypes.getLevel(points, type))}

//        when (type) {
//        RatingTypeName.MASTERS -> RatingLevelName.fromLevel(RatingTypes.getLevel(points, type))
////
////        {
////            when {
////                points >= 60 -> RatingLevelName.GURU
////                points >= 30 -> RatingLevelName.SPIRITUAL
////                points >= 10 -> RatingLevelName.CONSCIOUS
////                points >= 3 -> RatingLevelName.DISCIPLE
////                else -> RatingLevelName.NEWBIE
////            }
////        }
//        RatingTypeName.TRIPS ->
//
//        {
//            when {
//                points >= 150 -> RatingLevelName.GURU
//                points >= 80 -> RatingLevelName.SPIRITUAL
//                points >= 30 -> RatingLevelName.CONSCIOUS
//                points >= 10 -> RatingLevelName.DISCIPLE
//                else -> RatingLevelName.NEWBIE
//            }
//        }
//        RatingTypeName.SKILLS -> {
//            when {
//                points >= 80 -> RatingLevelName.GURU
//                points >= 40 -> RatingLevelName.SPIRITUAL
//                points >= 15 -> RatingLevelName.CONSCIOUS
//                points >= 5 -> RatingLevelName.DISCIPLE
//                else -> RatingLevelName.NEWBIE
//            }
//        }
//
//        else -> null
//    }
)

data class RatingType(
    val masters: Int,
    val trips: Int,
    val skills: Int
)

class RatingTypes {
    companion object{
        private val ratings: List<RatingType> = listOf(
            RatingType(masters = 0, trips = 0, skills = 0),
            RatingType(masters = 3, trips = 10, skills = 5),
            RatingType(masters = 10, trips = 30, skills = 15),
            RatingType(masters = 30, trips = 80, skills = 40),
            RatingType(masters = 60, trips = 150, skills = 80),
        )
        fun getLevel(value: Int, type:RatingTypeName):Int {
            for (i in ratings.indices){
                when (type){
                    RatingTypeName.MASTERS -> if (value < ratings[i].masters) return i
                    RatingTypeName.TRIPS -> if (value < ratings[i].trips) return i
                    RatingTypeName.SKILLS -> if (value < ratings[i].skills) return i
                }
            }
            return ratings.lastIndex
        }

        fun getMinPoints(level:Int, type:RatingTypeName) =
            when (type){
                RatingTypeName.MASTERS -> ratings[level-1].masters-1
                RatingTypeName.TRIPS -> ratings[level-1].trips-1
                RatingTypeName.SKILLS -> ratings[level-1].skills-1
            }

    }
}


data class UserRatingType(
    val name: String
)

enum class RatingTypeName {
    MASTERS, SKILLS, TRIPS;


    val res: Int
        get() {
            return when (this) {
                MASTERS -> R.string.masters
                SKILLS -> R.string.skill
                TRIPS -> R.string.events
            }
        }
}

enum class RatingLevelName {
    NEWBIE, DISCIPLE, CONSCIOUS, SPIRITUAL, GURU;

    val res: Int
        get() {
            return when (this) {
                NEWBIE -> R.string.newbie
                DISCIPLE -> R.string.disciple
                CONSCIOUS -> R.string.concious
                SPIRITUAL -> R.string.spiritual
                GURU -> R.string.guru
            }
        }
    val level: Int get()= ordinal+1
    companion object{
        fun fromLevel(level: Int) =
            when (level) {
                1 ->NEWBIE
                2-> DISCIPLE
                3->CONSCIOUS
                4->SPIRITUAL
                else ->GURU
            }
    }
}

