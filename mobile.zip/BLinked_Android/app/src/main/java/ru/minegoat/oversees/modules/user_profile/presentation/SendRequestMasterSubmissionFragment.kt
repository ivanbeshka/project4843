package ru.minegoat.oversees.modules.user_profile.presentation

import android.graphics.PorterDuff
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.telephony.PhoneNumberFormattingTextWatcher
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResultListener
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.card.MaterialCardView
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.base.utils.ui.loadImageFromOurApi
import ru.minegoat.oversees.base.utils.ui.view.setCountryCode
import ru.minegoat.oversees.databinding.FragmentSendRequestMasterSubmissionBinding
import ru.minegoat.oversees.domain.user.*
import ru.minegoat.oversees.modules.base.di.ConnectUsComponentHolder
import ru.minegoat.oversees.modules.base.model.SendMessageModelUi
import ru.minegoat.oversees.modules.master_profile.presentation.SocialNetworkBottomSheet
import ru.minegoat.oversees.modules.user_profile.di.UserProfileComponentHolder

class SendRequestMasterSubmissionFragment :
    Fragment(R.layout.fragment_send_request_master_submission) {
    private val binding by viewBinding(FragmentSendRequestMasterSubmissionBinding::bind)

    private val component by featureComponent(ConnectUsComponentHolder)

    private val viewModel by lazyViewModel {
        component.sendConnectUsMessageViewModel().create()
    }

    private val userProfileComponent by featureComponent(UserProfileComponentHolder)

    private val userProfileViewModel by lazyViewModel {
        userProfileComponent.userProfileViewModel().create()
    }

    private val compositeDisposable = CompositeDisposable()

    private val args: SendRequestMasterSubmissionFragmentArgs by navArgs()
    private val userId by lazy { args.userId }

    private var chosenAvatarUrl: String? = null
    private var socialNetworkList = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setFragmentResultListener(BottomSheetCheckPhoneNum.REQUEST_ACTION_KEY) { _, bundle ->
            val countryName = bundle.getString(BottomSheetCheckPhoneNum.ACTION_COUNTRY_NAME_KEY)
            val countryPhone = bundle.getString(BottomSheetCheckPhoneNum.ACTION_COUNTRY_PHONE_KEY)
            val countryCodeName = bundle.getString(BottomSheetCheckPhoneNum.ACTION_COUNTRY_CODE_KEY)
            countryName?.let { name ->
                countryPhone?.let { phone ->
                    countryCodeName?.let { code ->
                        viewModel.setCountryPhone(
                            CountryPhone(
                                name,
                                phone,
                                CountryFlags.valueOf(code)
                            )
                        )
                    }
                }
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        getChosenMasterInfoBundle()

        viewModel.getUserStatus(userId = userId)
        viewModel.status.observe(viewLifecycleOwner) { state ->
            state.on(
                success = { status ->
                    if (status.isSend)
                        checkMessageSendingStatus(requestMasterStatus = status)
                }
            )
        }

        binding.apply {
            sendButton.setOnClickListener() {
                if (etFeedback.text.isNotBlank() &&
                    etInputPhoneNum.text!!.isNotBlank()
                ) {
                    sendMessage()
                    sendUserInfoBundle()
                    findNavController().navigateUp()
                } else {
                    showToast()
                }
            }

            cancelButton.setOnClickListener {
                compositeDisposable.add(
                    viewModel.cancelRequest(userId)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribeBy(
                            onComplete = {
                                sendCancelRequest()
                                findNavController().navigateUp()
                            },
                            onError = {
                                Toast.makeText(requireContext(), getString(R.string.request_cancel_error), Toast.LENGTH_LONG).show()
                            }
                        )
                )
            }
        }

        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }

        binding.clChooseMaster.setOnClickListener {
            findNavController().navigate(R.id.action_sendRequestMasterSubmissionFragment_to_chooseMasterFragment)
        }

        binding.tvPhoneCountryCode.apply {
            setCountryCode(this, CountryPhone.fromPhone(viewModel.phone))
            setOnClickListener {
                findNavController().navigate(R.id.action_sendRequestMasterSubmissionFragment_to_bottomSheetCheckPhoneNum)
            }
        }

        binding.etInputPhoneNum.apply {
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                    //TODO("Not yet implemented")
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    //TODO("Not yet implemented")
                }

                override fun afterTextChanged(s: Editable?) {
                    val text: String = this@apply.text.toString()
                    val textLength: Int = this@apply.text.toString().length
                    if (text.endsWith("-") || text.endsWith(" ") || text.endsWith(" ")) return
                    if (textLength == 1) {
                        if (!text.contains("(")) {
                            this@apply.setText(StringBuilder(text).insert(text.length - 1, "(").toString())
                            this@apply.setSelection(this@apply.text.toString().length)
                        }
                    } else if (textLength == 5) {
                        if (!text.contains(")")) {
                            this@apply.setText(StringBuilder(text).insert(text.length - 1, ")").toString())
                            this@apply.setSelection(this@apply.text.toString().length)
                        }
                    } else if (textLength == 6) {
                        this@apply.setText(StringBuilder(text).insert(text.length - 1, " ").toString())
                        this@apply.setSelection(this@apply.text.toString().length)
                    } else if (textLength == 10) {
                        if (!text.contains("-")) {
                            this@apply.setText(StringBuilder(text).insert(text.length - 1, "-").toString())
                            this@apply.setSelection(this@apply.text.toString().length)
                        }
                    } else if (textLength == 15) {
                        if (text.contains("-")) {
                            this@apply.setText(StringBuilder(text).insert(text.length - 1, "-").toString())
                            this@apply.setSelection(this@apply.text.toString().length)
                        }
                    } else if (textLength == 18) {
                        if (text.contains("-")) {
                            this@apply.setText(StringBuilder(text).insert(text.length - 1, "-").toString())
                            this@apply.setSelection(this@apply.text.toString().length)
                        }
                    }
                }
            })
        }

        setTilPhoneCountryCode(CountryPhone("", "+7", CountryFlags.RU))
        viewModel.isCountryPhoneSet.observe(viewLifecycleOwner)
        { countryPhone ->
            setTilPhoneCountryCode(countryPhone)
        }

        userProfileViewModel.getUserProfile(UserProfileFragment.ProfileType.MY)
        userProfileViewModel.user.observe(viewLifecycleOwner) {
            it.on(
                success = {
                    with(binding.socialNetworkGroup) {
                        if (it.socialNetworks.isNotEmpty()) {
                            it.socialNetworks.forEach { socialNetwork ->
                                when (socialNetwork.name) {
                                    SocialNetworkName.INSTAGRAM -> workToSocialNetwork(
                                        socialNetwork,
                                        SocialNetworkName.INSTAGRAM,
                                        insta,
                                        ivInsta
                                    )
                                    SocialNetworkName.FACEBOOK -> workToSocialNetwork(
                                        socialNetwork,
                                        SocialNetworkName.FACEBOOK,
                                        facebook,
                                        ivFacebook
                                    )
                                    SocialNetworkName.TELEGRAM -> workToSocialNetwork(
                                        socialNetwork,
                                        SocialNetworkName.TELEGRAM,
                                        telegram,
                                        ivTelegram
                                    )
                                    SocialNetworkName.TWITTER -> workToSocialNetwork(
                                        socialNetwork,
                                        SocialNetworkName.TWITTER,
                                        twitter,
                                        ivTwitter
                                    )
                                    SocialNetworkName.VK -> workToSocialNetwork(socialNetwork, SocialNetworkName.VK, vk, ivVk)
                                    SocialNetworkName.YOUTUBE -> workToSocialNetwork(
                                        socialNetwork,
                                        SocialNetworkName.YOUTUBE,
                                        youtube,
                                        ivYoutube
                                    )
                                }
                            }
                        }
                    }
                    it.phone?.run {
                        //setCountryCode(binding.tvPhoneCountryCode, this)
                    }

                },
                error = {}
            )
        }

    }

    override fun onDestroy() {
        compositeDisposable.clear()
        super.onDestroy()
    }

    private fun workToSocialNetwork(
        socialNetwork: SocialNetwork,
        socialNetworkName: SocialNetworkName,
        element: MaterialCardView,
        image: ImageView
    ) {
        if (socialNetwork.link != null && socialNetwork.link != "") {
            element.apply {
                isEnabled = true
                setOnClickListener {
                    showSocialNetworkDialog(SocialNetwork(socialNetworkName, socialNetwork.link))
                }
            }
        } else {
            element.isEnabled = false
            image.setColorFilter(resources.getColor(R.color.gray_40, null))
        }
    }

    private fun setTilPhoneCountryCode(countryPhone: CountryPhone) =
        setCountryCode(binding.tvPhoneCountryCode, countryPhone)

    private fun showSocialNetworkDialog(socialNetwork: SocialNetwork) {
        findNavController().navigate(
            R.id.action_sendRequestMasterSubmissionFragment_to_socialNetworkBottomSheet,
            bundleOf("socialNetwork" to socialNetwork)
        )

        setFragmentResultListener(SocialNetworkBottomSheet.LINK_RESULT_KEY) { _, bundle ->
            bundle.getString(SocialNetworkBottomSheet.LINK_BUNDLE_KEY)?.let {
                socialNetworkList.add(it)
            }
        }
    }

//    private fun setDisabledIconForDesign() {
//        with(binding.socialNetworkGroup) {
//            ivFacebook.setColorFilter(resources.getColor(R.color.gray_40, null))
//            facebook.isEnabled = false
//            ivTwitter.setColorFilter(resources.getColor(R.color.gray_40, null))
//            twitter.isEnabled = false
//            ivYoutube.setImageResource(R.drawable.ic_youtube_disabled)
//            youtube.isEnabled = false
//        }
//    }

    private fun checkMessageSendingStatus(
        requestMasterStatus: RequestMasterStatus,
    ) {
        if (requestMasterStatus.isSend) {
            with(binding) {
                requestMasterStatus.imageUrl?.let { url ->
                    loadImageFromOurApi(
                        imageView = ivMaster,
                        imageUrl = url
                    )
                }
                socialNetworkGroup.apply {
                    insta.isClickable = false
                    ivInsta.isClickable = false
                    ivVk.isClickable = false
                    vk.isClickable = false
                    ivTelegram.isClickable = false
                    telegram.isClickable = false
                }
                clChooseMaster.isEnabled = false
                tvMasterName.isEnabled = false
                tvPhoneCountryCode.isEnabled = false
                tvMasterName.text = requestMasterStatus.invitedMaster
                with(ContextCompat.getColor(requireContext(), R.color.gray_70)) {
                    tvMasterName.setTextColor(this)
                    etFeedback.setTextColor(this)
                    etInputPhoneNum.setTextColor(this)
                }
                etFeedback.isEnabled = false
                etFeedback.setText(requestMasterStatus.message)
                etInputPhoneNum.isEnabled = false
                etInputPhoneNum.setText(requestMasterStatus.phone)
                sendButton.visibility = View.GONE
                cancelButton.visibility = View.VISIBLE
                chipMessage.visibility = View.VISIBLE
                ivChooseMaster.setColorFilter(
                    resources.getColor(R.color.gray_70, null),
                    PorterDuff.Mode.SRC_IN
                )
            }
        }
    }

    private fun showToast() {
        Toast.makeText(
            requireContext(),
            "Введите все данные формы!",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun sendMessage() {
        viewModel.sendMessage(
            SendMessageModelUi(
                binding.etFeedback.text.toString(),
                binding.tvMasterName.text.toString(),
                "Меня зовут ${binding.tvMasterName.text}, мой номер: ${
                    binding.tvPhoneCountryCode.text.toString().substringAfterLast(' ')
                }${binding.etInputPhoneNum.text}, меня сюда пригласил ${binding.tvMasterName.text}, мои соц. сети: $socialNetworkList",
                "Стать мастером",
            )
        )
    }

    private fun getChosenMasterInfoBundle() {
        parentFragmentManager.setFragmentResultListener(
            ChooseMasterFragment.SELECTED_MASTER_KEY,
            viewLifecycleOwner
        ) { _, data ->
            binding.tvMasterName.text = data.getString(ChooseMasterFragment.SELECTED_MASTER_NAME)
            data.getString(ChooseMasterFragment.SELECTED_MASTER_AVATAR)
                ?.let {
                    loadImageFromOurApi(binding.ivMaster, it)
                    chosenAvatarUrl = it
                }
        }
    }

    private fun sendCancelRequest() {
        parentFragmentManager.setFragmentResult(
            SEND_STATUS_KEY, bundleOf(SEND_STATUS_DELETE to true)
        )
    }

    private fun sendUserInfoBundle() {
        parentFragmentManager.setFragmentResult(
            SEND_STATUS_KEY, bundleOf(
                SEND_STATUS_USER_ID to userId,
                SEND_STATUS_VALUE to true,
                SEND_STATUS_INVITED_MASTER_NAME to binding.tvMasterName.text.toString(),
                SEND_STATUS_MESSAGE to binding.etFeedback.text.toString(),
                SEND_STATUS_PHONE to binding.etInputPhoneNum.text.toString(),
                SEND_STATUS_PHONE_CODE to binding.tvPhoneCountryCode.text.toString().substringAfterLast(' '),
                SEND_STATUS_IMAGE_URL to chosenAvatarUrl,
                SEND_STATUS_SOCIAL_NETWORKS to socialNetworkList.toString()
            )
        )
    }

    companion object {
        const val SEND_STATUS_DELETE = "SEND_STATUS_DELETE"
        const val SEND_STATUS_KEY = "SEND STATUS KEY"
        const val SEND_STATUS_USER_ID = "SEND_STATUS_USER_ID"
        const val SEND_STATUS_VALUE = "SEND_STATUS_VALUE"
        const val SEND_STATUS_INVITED_MASTER_NAME = "SEND_STATUS_INVITED_MASTER_NAME"
        const val SEND_STATUS_MESSAGE = "SEND_STATUS_MESSAGE"
        const val SEND_STATUS_PHONE = "SEND_STATUS_PHONE"
        const val SEND_STATUS_PHONE_CODE = "SEND_STATUS_PHONE_CODE"
        const val SEND_STATUS_IMAGE_URL = "SEND_STATUS_IMAGE_URL"
        const val SEND_STATUS_SOCIAL_NETWORKS = "SEND_STATUS_SOCIAL_NETWORKS"
    }
}