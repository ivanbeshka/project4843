package ru.minegoat.oversees.modules.user_profile.presentation


import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.core.os.bundleOf
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.BottomSheetRenameDocumentBinding

class BottomSheetRenameDocument : BottomSheetDialogFragment(R.layout.bottom_sheet_rename_document) {

    private val binding by viewBinding(BottomSheetRenameDocumentBinding::bind)

    private var editText: EditText? = null

    private val sentName: String by lazy {
        this.arguments?.getString(SEND_NAME, "") ?: ""
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        editText = binding.etRenameDocument.apply {
            if(text.isNullOrEmpty()){
                setText(sentName)
            }
        }

        binding.btnSaveDocument.setOnClickListener {
            setResultAndExit(BottomSheetDocumentInfo.FragmentAction.RENAMED, editText?.text.toString())
        }
    }

    private fun setResultAndExit(resultAction: BottomSheetDocumentInfo.FragmentAction, newName: String) {
        setFragmentResult(
            BottomSheetDocumentInfo.REQUEST_ACTION_KEY,
            bundleOf(
                BottomSheetDocumentInfo.ACTION_BUNDLE_KEY to resultAction.ordinal,
                BottomSheetDocumentInfo.ACTION_NAME_KEY to newName
            )
        )
        findNavController().navigateUp()
    }

    companion object {
        const val SEND_NAME = "name"
    }
}