package ru.minegoat.oversees.modules.chat.network

import io.github.centrifugal.centrifuge.*
import io.reactivex.*
import ru.minegoat.oversees.data.network.chat.model.ChatResponse
import ru.minegoat.oversees.modules.chat.network.responses.MessageResponse

class ChatApiImpl : ChatApi {
    private lateinit var client: Client
    override fun getChat(chatId: String): Maybe<ChatResponse> {
        TODO("Not yet implemented")
    }

    override fun getAllMessages(chatId: String): Single<List<MessageResponse>> {
        TODO("Not yet implemented")
    }



    override fun readMessage(messageId: String, userId: String): Completable {
        TODO("Not yet implemented")
    }

}