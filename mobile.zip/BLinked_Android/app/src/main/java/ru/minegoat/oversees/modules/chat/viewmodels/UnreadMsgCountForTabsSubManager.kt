package ru.minegoat.oversees.modules.chat.viewmodels

import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import ru.minegoat.oversees.modules.chat.model.UnreadMsgCountForTabs.UnreadMsgCountTabUi

class UnreadMsgCountForTabsSubManager {

    private val publishSub = PublishSubject.create<UnreadMsgCountTabUi>()

    fun onNext(unreadMsgCountTab: UnreadMsgCountTabUi) =
        publishSub.onNext(unreadMsgCountTab)

    fun get(): Observable<UnreadMsgCountTabUi> =
        publishSub
}