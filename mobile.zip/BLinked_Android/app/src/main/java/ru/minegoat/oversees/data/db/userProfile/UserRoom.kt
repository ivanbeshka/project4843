package ru.minegoat.oversees.data.db.userProfile

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import ru.minegoat.oversees.domain.karma.Karma
import ru.minegoat.oversees.domain.auth.Phone
import ru.minegoat.oversees.domain.user.*

@Entity(tableName = "users")
data class UserRoom(
    @PrimaryKey
    val userId: String,
    @ColumnInfo(name = "name")
    val name: String? = null,
    @ColumnInfo(name = "soname")
    val soname: String? = null,
    @ColumnInfo(name = "role")
    val role: String? = null,
    @ColumnInfo(name = "avatar")
    val avatar: String? = null,
    @ColumnInfo(name = "phone")
    val phone: String? = null,
    @ColumnInfo(name = "description")
    val description: String? = null,
    @ColumnInfo(name = "isGuide")
    val isGuide: Boolean? = null,
    @ColumnInfo(name = "isCustomer")
    val isCustomer: Boolean = false,
    @ColumnInfo(name = "isMaster")
    val isMaster: Boolean? = null,
    @ColumnInfo(name = "avatar_url")
    val avatarUrl: String? = null,
    @ColumnInfo(name = "guid")
    val guid: String? = null,
    @ColumnInfo(name = "home_location_id")
    val homeLocationId: String? = null,
    @ColumnInfo(name = "sex")
    val sex: Sex? = null,
    @ColumnInfo(name = "social_networks")
    val socialNetworks: MutableList<SocialNetwork>? = arrayListOf(),
    @ColumnInfo(name = "skills_ids")
    val skills: MutableList<MasterSkill>? = arrayListOf(),
    @ColumnInfo(name = "user_rating")
    val rating: UserRating? = null,
    @ColumnInfo(name = "karma")
    val karma : Karma? = null
)

fun UserRoom.toUser(): User {
    return User(
        userId = userId,
//        role = role,
        name = name,
        soname = soname,
        avatar = avatar,
        phone = phone?.let { Phone.fromSplitString(it) },
        description = description,
        isGuide = isGuide,
        isCustomer = isCustomer,
        isMaster = isMaster,
        avatarUrl = avatarUrl,
        guid = guid,
        homeLocationId = homeLocationId,
        sex = sex,
        socialNetworks = socialNetworks?.toList() ?: emptyList(),
        skills = skills?.toList() ?: emptyList(),
        userRating = rating,
        karma = karma
    )
}

