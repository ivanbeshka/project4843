package ru.minegoat.oversees.base.di.modules

import dagger.Module
import dagger.Provides
import retrofit2.Retrofit
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import ru.minegoat.oversees.data.network.skill.SkillApi
import ru.minegoat.oversees.data.network.user.UserApi
import ru.minegoat.oversees.data.repository.skill.SkillRepository
import ru.minegoat.oversees.data.repository.user.UserRepository
import ru.minegoat.oversees.modules.master_profile.repository.MasterInfoRepository
import javax.inject.Singleton

@Module
class UserModule {
    @Singleton
    @Provides
    fun provideUserApi(retrofit: Retrofit) : UserApi =
        retrofit.create(UserApi::class.java)

    @Singleton
    @Provides
    fun provideUserRepository(userApi: UserApi, realm: RealmDataStorage): UserRepository =
        UserRepository(userApi, realm)

    @Singleton
    @Provides
    fun provideSkillApi(retrofit: Retrofit) : SkillApi =
        retrofit.create(SkillApi::class.java)

    @Singleton
    @Provides
    fun provideSkillRepository(skillApi: SkillApi,ds: RealmDataStorage): SkillRepository =
        SkillRepository(skillApi, ds)

    @Singleton
    @Provides
    fun provideMasterInfoRepository(ds: RealmDataStorage):MasterInfoRepository =
        MasterInfoRepository(ds)
}