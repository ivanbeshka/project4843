package ru.minegoat.oversees.modules.user_profile.network

import io.reactivex.Completable
import io.reactivex.Single
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import ru.minegoat.oversees.modules.user_profile.network.model.RequestUserProfile
import ru.minegoat.oversees.data.network.user.model.ResponseUserProfile
import ru.minegoat.oversees.modules.user_profile.network.model.RequestMasterInfo

interface UserProfileApi {
    @GET("user/profile")
    fun getUserProfile(@Query("id") objId: String): Single<ResponseUserProfile>

    @POST("user/profile/update")
    fun updateUserProfile(@Body user: RequestUserProfile): Completable

    @GET("user/profile/delete")
    fun deleteUserProfile(): Completable

    @POST("user/profile/masterinfo")
    fun updateMasterInfo(@Body masterInfo: RequestMasterInfo): Completable
}