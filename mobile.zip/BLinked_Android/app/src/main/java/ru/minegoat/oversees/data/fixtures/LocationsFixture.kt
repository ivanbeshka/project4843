package ru.minegoat.oversees.data.fixtures

import com.google.android.gms.maps.model.LatLng
import ru.minegoat.oversees.domain.location.Location
import ru.minegoat.oversees.domain.location.LocationType
import java.util.*

object LocationsFixture {
    val country = Location(
        objID = "62e87f16a1790031b2db3fbb",
        name = "Россия",
        internationalName = "Russia",
        latLng = LatLng(61.52401, 105.318756),
        type = LocationType.COUNTRY,
        website = "http://www.gov.ru/",
        address = "Россия",
        timeZone = TimeZone.getTimeZone("Asia/Krasnoyarsk"),
        countryCode = "RU",
        externalID = "ChIJ-yRniZpWPEURE_YRZvj9CRQ",
        internationalAddress = "Russia",
        isUsing = false
    )

    val cityKhabarovsk = Location(
        objID = "62eb611ee7f7e7a1ec7596a1",
        name = "Хабаровск",
        internationalName = "Khabarovsk",
        latLng = LatLng(48.4814433, 135.0720667),
        type = LocationType.CITY,
        countryLocation = country,
        timeZone = TimeZone.getTimeZone("Asia/Vladivostok"),
        codeIATA = "KHV",
        address = "Хабаровск, Хабаровский край, Россия",
        countryCode = "RU",
        externalID = "ChIJyYo2sMbp-l4RUH-6Xw68l_o",
        internationalAddress = "Khabarovsk, Khabarovsk Krai, Russia",
        isUsing = true
    )

    val cityMoscow = Location(
        objID = "62eafe1b718720db52a6b8e0",
        name = "Москва",
        internationalName = "Moscow",
        latLng = LatLng(55.755826, 37.6173),
        type = LocationType.CITY,
        address = "Москва, Россия",
        timeZone = TimeZone.getTimeZone("Europe/Moscow"),
        countryCode = "RU",
        externalID = "ChIJybDUc_xKtUYRTM9XV8zWRD0",
        countryLocation = country,
        internationalAddress = "Moscow, Russia",
        isUsing = true
    )

    val cityMagadan = Location(
        objID = "62eb62aecbfef9257668909e",
        name = "Магадан",
        website = "http://www.magadangorod.ru/",
        latLng = LatLng(59.5594397, 150.8127537),
        address = "Магадан, Магаданская обл., Россия",
        timeZone = TimeZone.getTimeZone("Asia/Magadan"),
        countryCode = "RU",
        externalID = "ChIJ6UpSLYGEaVkRWwac4edMyTk",
        type = LocationType.CITY,
        internationalName = "Magadan",
        internationalAddress = "Magadan, Magadan Oblast, Russia",
        isUsing = true
    )

    val cityBylym = Location(
        objID = "630f49c20b8400407a342ede",
        name = "Былым",
        latLng = LatLng(43.4627537, 43.0377128),
        address = "Былым, Кабардино-Балкарская Респ., Россия, 361606",
        timeZone = TimeZone.getTimeZone("Europe/Moscow"),
        countryLocation = country,
        countryCode = "RU",
        externalID = "ChIJRTUacDONWUARk5Cqsg-Z2IY",
        type = LocationType.CITY,
        internationalName = "Bylym",
        internationalAddress = "Bylym, Kabardino-Balkarian Republic, Russia, 361606",
        isUsing = true
    )

    val locations = listOf(
        Location(
            objID = "62eb41df6363313a26491648",
            name = "Шереметьево - аэропорт имени А.С. Пушкина",
            internationalName = "Sheremetyevo - A.S. Pushkin international airport",
            latLng = LatLng(55.9736482, 37.4125029),
            type = LocationType.AIRPORT,
            cityLocation = cityMoscow,
            countryLocation = country,
            timeZone = TimeZone.getTimeZone("Europe/Moscow"),
            codeIATA = "SVO",
            address = "Химки, Московская обл., Россия, 141400",
            internationalAddress = "Khimki, Moscow Oblast, Russia, 141400",
            phoneNumber = "+7 495 578-65-65",
            website = "http://www.svo.aero/",
            countryCode = "RU",
            externalID = "ChIJSXFOwiA8tUYRB-0DtHp2SV8",
            isUsing = true
        ),
        Location(
            objID = "62eb67bcbcdf47cc43bde6ce",
            name = "Международный аэропорт Хабаровск (Новый)",
            internationalName = "Khabarovskiy Aeroport",
            latLng = LatLng(48.5258817, 135.1704731),
            type = LocationType.AIRPORT,
            phoneNumber = "+7 421 226-20-06",
            countryLocation = country,
            cityLocation = cityKhabarovsk,
            internationalAddress = "Matveyevskoye Shosse, 26а, Khabarovsk, Khabarovskiy kray, Russia, 680031",
            address = "Матвеевское ш., 26а, Хабаровск, Хабаровский край, Россия, 680031",
            timeZone = TimeZone.getTimeZone("Asia/Vladivostok"),
            codeIATA = "KHV",
            countryCode = "RU",
            externalID = "ChIJ30JqdWLB-l4RXRJviTjtYDA",
            isUsing = true
        ),
        Location(
            phoneNumber = "+7 924 858-25-21",
            objID = "62eee5894fdd1304985c420f",
            name = "Бар \"Аляска\"",
            latLng = LatLng(59.5656361, 150.7965582),
            cityLocation = cityMagadan,
            countryLocation = country,
            address = "2, ул. Дзержинского, 26, Магадан, Магаданская обл., Россия, 685000",
            timeZone = TimeZone.getTimeZone("Asia/Magadan"),
            countryCode = "RU",
            externalID = "ChIJcZOoJGuIaVkRDOqQC8r0lGw",
            type = LocationType.RESTAURANT,
            internationalName = "Alaska Bar",
            internationalAddress = "2, Ulitsa Dzerzhinskogo, 26, Magadan, Magadanskaya oblast', Russia, 685000",
            isUsing = true
        ),
        Location(
            objID = "630f49c20b8400407a342edf",
            name = "о. Уллу Гижгит (шикарная видовая)",
            latLng = LatLng(43.46643, 42.98877),
            address = "FX8Q+HGC Былым, Кабардино-Балкарская Республика, Россия",
            timeZone = TimeZone.getTimeZone("Europe/Moscow"),
            countryLocation = country,
            cityLocation = cityBylym,
            countryCode = "RU",
            type = LocationType.SPOT,
            internationalName = "FX8Q+HG Bylym",
            internationalAddress = "FX8Q+HGC Bylym, Kabardino-Balkarian Republic, Russia",
            isUsing = true
        ),
        cityMoscow,
        cityKhabarovsk,
        cityMagadan,
        cityBylym,
        country
    )
}


