package ru.minegoat.oversees.modules.main.repository

import io.reactivex.Completable
import ru.minegoat.oversees.domain.location.Location
import ru.minegoat.oversees.modules.main.di.fixture.FixtureScope
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import ru.minegoat.oversees.domain.location.toLocationRealm
import javax.inject.Inject

@FixtureScope
class LocationsFixtureRepository @Inject constructor(private val ds: RealmDataStorage) {

    fun saveLocationsFixture(locations: List<Location>): Completable {
        val realmLocations = locations.map { it.toLocationRealm() }
        return ds.saveAll(realmLocations)
    }
}