package ru.minegoat.oversees.base.helpers.syncer

import android.util.Log
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.data.network.location.LocationNetwork
import ru.minegoat.oversees.data.network.location.createLocations
import ru.minegoat.oversees.data.network.masterinfo.MasterInfoNetwork
import ru.minegoat.oversees.data.network.masterinfo.toMasterInfoRealm
import ru.minegoat.oversees.data.network.mastertype.MasterTypeNetwork
import ru.minegoat.oversees.data.network.mastertype.toMasterTypeRealm
import ru.minegoat.oversees.data.network.skill.responses.ResponseSkillItem
import ru.minegoat.oversees.data.network.skill.responses.toBusiness
import ru.minegoat.oversees.data.network.syncer.SyncerNetwork
import ru.minegoat.oversees.data.network.syncer.model.SyncItemResponse
import ru.minegoat.oversees.data.repository.syncer.SyncerRepository
import ru.minegoat.oversees.data.sharedpref.SyncerSharedPref
import ru.minegoat.oversees.domain.location.toLocationRealm
import ru.minegoat.oversees.domain.user.toSkillRealm
import java.util.*
import javax.inject.Inject
import kotlin.concurrent.fixedRateTimer

class Syncer @Inject constructor(
    private val pref: SyncerSharedPref,
    private val network: SyncerNetwork,
    private val repository: SyncerRepository
) {
    private val compositeDisposable = CompositeDisposable()
    private var timerTask: TimerTask? = null
    private var isTimerTaskStarted = false

    //TODO
    private var status: SyncerStatus
        get() = pref.syncerStatus
        set(value) {
            pref.syncerStatus = value
        }

    private var currentSession: UUID?
        get() = pref.currentSession
        set(value) {
            pref.currentSession = value
        }

    //TODO
    private var sessionStatus: SyncSessionStatus?
        get() = pref.sessionStatus
        set(value) {
            pref.sessionStatus = value
        }

    private var sessionDate: Date
        get() = pref.sessionDate
        set(value) {
            pref.sessionDate = value
        }

    private var sessionCounter: Int
        get() = pref.sessionCounter
        set(value) {
            pref.sessionCounter = value
        }

    //MAIN
    init {
        //if first launch
        if (currentSession == null) {
            currentSession = UUID.randomUUID()
        }

        startSync()
    }

    fun onResume() {
        if (!isTimerTaskStarted) {
            startSync()
        }
    }

    fun onPause() {
        compositeDisposable.clear()
        network.clearDisposable()
        timerTask?.cancel()
        isTimerTaskStarted = false
    }

    //TODO
//    fun setSyncerStatus(syncerStatus: SyncerStatus) {
//        status = syncerStatus
//    }

    private fun startSync() {
        isTimerTaskStarted = true
        fixedRateTimer("syncer_timer", false, period = PERIOD) {
            timerTask = this

            network.sync(currentSession!!, sessionDate) { objs ->

                //sync is successful
                sessionDate = Date()
                sessionCounter++

                saveObjs(objs)
            }
        }
    }

    private fun saveObjs(objs: List<Any?>) {
        val locations = mutableListOf<LocationNetwork>()
        val skills = mutableListOf<ResponseSkillItem>()
        val masterTypes = mutableListOf<MasterTypeNetwork>()
        val masterInfo = mutableListOf<MasterInfoNetwork>()

        //TODO add other types
        objs.forEach {
            when (it) {
                is LocationNetwork -> {
                    locations.add(it)
                }
                is ResponseSkillItem -> {
                    skills.add(it)
                }
                is MasterTypeNetwork -> {
                    masterTypes.add(it)
                }
                is MasterInfoNetwork -> {
                    masterInfo.add(it)
                }

            }
        }

        if (locations.isNotEmpty()) saveLocations(locations)
        if (skills.isNotEmpty()) saveSkills(skills)
        if (masterTypes.isNotEmpty()) saveMasterTypes(masterTypes)
        if (masterInfo.isNotEmpty()) saveMasterInfo(masterInfo)
    }

    private fun saveLocations(locations: MutableList<LocationNetwork>) {
        val locationsRealm = createLocations(locations).map { it.toLocationRealm() }
        compositeDisposable.add(repository.save(locationsRealm)
            .observeOn(Schedulers.io())
            .subscribeBy(
                onComplete = {
                    Log.d("Syncer", "onSaveLocations: ok")
                },
                onError = {
                    Log.d("Syncer", "onSaveLocations: ${it.message}")
                }
            )
        )
    }

    private fun saveMasterTypes(masterTypes: MutableList<MasterTypeNetwork>) {
        val masterTypeRealm = masterTypes.map {
            it.toMasterTypeRealm()
        }
        compositeDisposable.add(repository.save(masterTypeRealm)
            .observeOn(Schedulers.io())
            .subscribeBy(
                onComplete = {
                    Log.d("Syncer", "onSaveMasterType: ok")
                },
                onError = {
                    Log.d("Syncer", "onSaveMasterType: ${it.message}")
                }
            )
        )
    }

    private fun saveMasterInfo(masterInfo: MutableList<MasterInfoNetwork>) {
        val masterInfoRealm = masterInfo.map {
            it.toMasterInfoRealm()
        }
        compositeDisposable.add(repository.save(masterInfoRealm)
            .observeOn(Schedulers.io())
            .subscribeBy(
                onComplete = {
                    Log.d("Syncer", "onSaveMasterInfo: ok")
                },
                onError = {
                    Log.d("Syncer", "onSaveMasterInfo: ${it.message}")
                }
            )
        )
    }


    private fun saveSkills(skills: MutableList<ResponseSkillItem>) {
        val skillsRealm = skills.map { it.toBusiness().toSkillRealm() }
        compositeDisposable.add(repository.save(skillsRealm)
            .observeOn(Schedulers.io())
            .subscribeBy(
                onComplete = {
                    Log.d("Syncer", "onSaveSkills: ok")
                },
                onError = {
                    Log.d("Syncer", "onSaveSkills: ${it.message}")
                }
            )
        )
    }



    companion object {
        //30 sec
        private const val PERIOD = 30000L

        const val SYNC_ALL_DATE = 1000L
    }
}