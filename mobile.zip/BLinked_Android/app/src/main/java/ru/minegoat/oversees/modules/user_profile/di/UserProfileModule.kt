package ru.minegoat.oversees.modules.user_profile.di

import dagger.Module
import dagger.Provides
import retrofit2.Retrofit
import ru.minegoat.oversees.base.db.room.RoomDB
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import ru.minegoat.oversees.modules.master_profile.di.MasterScope
import ru.minegoat.oversees.modules.user_profile.network.UserProfileApi
import ru.minegoat.oversees.modules.user_profile.repository.UserProfileRepository

@Module
class UserProfileModule {

    @UserProfileScope
    @Provides
    fun provideUserProfileRepository(
        api: UserProfileApi,
        roomDB: RoomDB,
        authSharedPref: AuthSharedPref
    ): UserProfileRepository =
        UserProfileRepository(api, roomDB.userDao(), authSharedPref)

    @UserProfileScope
    @Provides
    fun provideUserProfileApi(retrofit: Retrofit): UserProfileApi =
        retrofit.create(UserProfileApi::class.java)

}