package ru.minegoat.oversees.modules.chat.utils

object UnreadMsgCountUtils {

    private const val MSG_COUNT_K_POSTFIX = "k"
    private const val ONE_K = 1000
    private const val REMAINDER_K = 100

    fun unreadMsgCountToString(unreadMsgCount: Int): String {
        val msgCountInK = unreadMsgCount / ONE_K
        val remainder = unreadMsgCount % ONE_K / REMAINDER_K

        val msgCountString = if (msgCountInK >= 1) {
            if (remainder == 0) {
                "$msgCountInK $MSG_COUNT_K_POSTFIX"
            } else {
                "$msgCountInK,$remainder $MSG_COUNT_K_POSTFIX"
            }
        } else {
            "$unreadMsgCount"
        }

        return msgCountString
    }
}