package ru.minegoat.oversees.modules.map.di

import dagger.Component
import ru.minegoat.oversees.modules.map.viewmodels.LocationViewModel
import ru.minegoat.oversees.modules.map.viewmodels.SearchLocationsViewModel
import ru.minegoat.oversees.base.utils.LocationUtils
import ru.minegoat.oversees.base.di.AppComponent
import ru.minegoat.oversees.base.di.components.DiComponent

@MapScope
@Component(dependencies = [AppComponent::class], modules = [MapModule::class])
interface MapComponent : DiComponent {

    fun locationUtils(): LocationUtils
    fun locationViewModel(): LocationViewModel.Factory
    fun searchViewModel(): SearchLocationsViewModel.Factory
}