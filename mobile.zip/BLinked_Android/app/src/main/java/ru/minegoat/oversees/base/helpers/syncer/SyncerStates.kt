package ru.minegoat.oversees.base.helpers.syncer

enum class SyncAction {
    INSERT,
    UPDATE,
    DELETE
}

enum class SyncStatus {
    NEED_SYNC,
    DOES_SYNC,
    DID_SYNC
}

enum class SyncerStatus {
    VACANT,
    SENT,
    SENDING,
    RECEIVED,
    CLOSING
}

enum class SyncSessionStatus {
    SYNC_REQUEST_SENT,
    SYNC_REQUEST_SUCCESS,
    SYNC_RESPONSE_RECEIVED,
    SYNC_REQUEST_REJECTED,
    SYNC_RESPONSE_SUCCESS,
    SYNC_RESPONSE_REJECTED,
    SYNC_COMMIT_SENT,
    SYNC_COMMIT_SUCCESS
}