package ru.minegoat.oversees.modules.master_profile.viewmodels

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.base.viewmodels.*
import ru.minegoat.oversees.data.repository.skill.SkillRepository
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import ru.minegoat.oversees.domain.user.Skill

class SkillsViewModel @AssistedInject constructor(
    private val skillRepository: SkillRepository,
    private val authSharedPref: AuthSharedPref
) : RxViewModel() {

    private val skillLiveData = MutableLiveData<ScreenState<Skill>>()
    val skill: LiveData<ScreenState<Skill>> = skillLiveData

    private val skillListLiveData = MutableLiveData<ScreenState<List<Skill>>>()

    private val masterSkillListLiveData = MutableLiveData<ScreenState<List<Skill>>>()
    val masterSkillList: LiveData<ScreenState<List<Skill>>> = masterSkillListLiveData

    val userId get()= authSharedPref.userId


    fun getSkillById(objId: String): LiveData<ScreenState<Skill>> {
        skillRepository.getSkillById(objId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { skillLiveData.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    skillLiveData.value = SuccessScreenState(it)
                },
                onError = {
                    skillLiveData.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()

        return skillLiveData
    }

    fun getUserSkills(skillsIds: List<String>): LiveData<ScreenState<List<Skill>>> {
        skillRepository.getSkillsBySkillsIds(skillsIds)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { masterSkillListLiveData.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    masterSkillListLiveData.value = SuccessScreenState(it)
                },
                onError = {
                    masterSkillListLiveData.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()

        return masterSkillListLiveData
    }

    fun getSkillsWithPredicate(predicate: String): LiveData<ScreenState<List<Skill>>> {
        skillRepository.getSkillsWithPredicate(predicate)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { skillListLiveData.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    skillListLiveData.value = SuccessScreenState(it)
                },
                onError = {
                    Log.d("search skills", "getSkillsWithPredicate ERROR = $it")
                    skillListLiveData.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()

        return skillListLiveData
    }


    @AssistedFactory
    interface Factory {
        fun create(): SkillsViewModel
    }
}