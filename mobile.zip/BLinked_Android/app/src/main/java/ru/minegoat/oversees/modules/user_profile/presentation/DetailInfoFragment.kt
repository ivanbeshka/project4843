package ru.minegoat.oversees.modules.user_profile.presentation

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.navigation.fragment.findNavController
import androidx.viewpager2.adapter.FragmentStateAdapter
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.tabs.TabLayoutMediator
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.FragmentDetailInfoBinding
import ru.minegoat.oversees.modules.user_profile.model.DetailType

class DetailInfoFragment : Fragment(R.layout.fragment_detail_info) {
    private val binding by viewBinding(FragmentDetailInfoBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener {
            findNavController().popBackStack()
        }
        initViewPager()
        initTabLayout()

    }

    private fun initViewPager(){
        binding.vpDetail.adapter = DetailInfoViewAdapter(
            childFragmentManager,
            lifecycle
        )
    }

    private fun initTabLayout(){
        TabLayoutMediator(binding.tabDetail, binding.vpDetail){
            tab, position ->
            when(position){
                0->tab.text = getString(R.string.events)
                1 -> tab.text = getString(R.string.masters)
                2 -> tab.text = getString(R.string.skill)
            }
        }.attach()
    }

    private class DetailInfoViewAdapter(manager : FragmentManager, lifecycle: Lifecycle):
            FragmentStateAdapter(manager, lifecycle){
        override fun getItemCount(): Int {
            return DetailType.values().size
        }

        override fun createFragment(position: Int): Fragment {
                    return DetailInfoItemFragment.newInstance(DetailType.values()[position])

            }
        }

    }


