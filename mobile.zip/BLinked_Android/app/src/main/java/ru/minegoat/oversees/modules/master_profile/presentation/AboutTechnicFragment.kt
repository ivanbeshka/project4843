package ru.minegoat.oversees.modules.master_profile.presentation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.tabs.TabLayoutMediator
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.FragmentAboutTechnicBinding

class AboutTechnicFragment : Fragment(R.layout.fragment_about_technic) {

    private val binding by viewBinding(FragmentAboutTechnicBinding::bind)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val pagerAdapter = PagerAdapter(childFragmentManager, lifecycle)
        binding.vpTechnic.adapter = pagerAdapter

        TabLayoutMediator(binding.tlTechnic, binding.vpTechnic) { tab, position ->
            when (position) {
                0 -> tab.text = getString(R.string.description)
                1 -> tab.text = getString(R.string.masters)
                2 -> tab.text = getString(R.string.events_technic)
            }
        }.attach()
    }

}