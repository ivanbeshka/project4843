package ru.minegoat.oversees.modules.user_profile.presentation

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.net.toFile
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResultListener
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import by.kirich1409.viewbindingdelegate.viewBinding
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.internal.util.HalfSerializer
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.App
import ru.minegoat.oversees.BuildConfig
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.OpenFileUtils
import ru.minegoat.oversees.base.utils.image.TakePictureWithUriReturnContract
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.base.utils.ui.fragment.showSpecialToast
import ru.minegoat.oversees.base.utils.ui.fragment.showToast
import ru.minegoat.oversees.base.utils.ui.loadImageFromOurApi
import ru.minegoat.oversees.base.viewmodels.ErrorScreenState
import ru.minegoat.oversees.base.viewmodels.SuccessScreenState
import ru.minegoat.oversees.databinding.FragmentUserAccountBinding
import ru.minegoat.oversees.domain.document.Document
import ru.minegoat.oversees.domain.user.RequestMasterStatus
import ru.minegoat.oversees.modules.base.presentation.ConnectUsFragment
import ru.minegoat.oversees.modules.main.di.auth.AuthComponentHolder
import ru.minegoat.oversees.modules.user_profile.di.UserProfileComponentHolder

class UserAccountFragment : Fragment(R.layout.fragment_user_account) {

    private var isGuest = false
    private var isMaster = false

    private var isProfileFilled = true

    private val authSharedPref = App.component.tokenPref()

    private val userId = App.component.tokenPref().userId

    private val binding by viewBinding(FragmentUserAccountBinding::bind)

    private val authComponent by featureComponent(AuthComponentHolder)

    private val authViewModel by lazyViewModel {
        authComponent.authViewModel().create()
    }

    private val component by featureComponent(UserProfileComponentHolder)

    private val userDocViewModel by lazyViewModel {
        component.userDocViewModel().create()
    }

    private val viewModel by lazyViewModel {
        component.accountViewModel().create()
    }

    private val compositeDisposable = CompositeDisposable()

    private lateinit var photoContract: ActivityResultLauncher<Uri>

    private lateinit var docContract: ActivityResultLauncher<Array<String>>

    private val adapter = DocumentsAdapter(
        object : DocumentsRecyclerLongClickListener {
            override fun onClick(v: View, position: Int, document: Document) {
                OpenFileUtils.showFile(document.uri, requireContext())
            }

            override fun onLongClick(v: View, position: Int, document: Document) {
                userDocViewModel.currentDoc = document
                findNavController().navigate(
                    R.id.action_userAccountFragment_to_bottomSheetDocumentInfo,
                    bundleOf(
                        BottomSheetRenameDocument.SEND_NAME to document.userFileName
                    )
                )
            }
        }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


//        val args: UserAccountFragmentArgs by navArgs()
//        args.let {
//            isMaster = it.isMaster
//            isGuest = it.isGuest
//        }

        setFragmentResultListener(REQUEST_ACTION_KEY) { _, bundle ->

            val action = bundle.getInt(ACTION_BUNDLE_KEY)
            when (FragmentAction.values()[action]) {

                FragmentAction.TAKE_PHOTO ->
                    userDocViewModel.getPhotoUri()

                FragmentAction.CHOOSE_DOC ->
                    docContract.launch(mimeArray)

                FragmentAction.RENAMED -> {
                    val newName = bundle.getString(ACTION_NAME_KEY, "")
                    if (newName.isNotEmpty() && userDocViewModel.currentDoc.userFileName.isNotEmpty())
                        userDocViewModel.renameDoc(
                            userDocViewModel.currentDoc.userFileName,
                            newName
                        )
                }

                FragmentAction.DELETE_DOC ->
                    userDocViewModel.deleteDoc(userDocViewModel.currentDoc.storageFileName)

                FragmentAction.NEED_LOGOUT -> {
                    userId?.let {
                        compositeDisposable.add(viewModel.logout()
                            .subscribeOn(Schedulers.io())
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribeBy(
                            onComplete = {
                                authSharedPref.clear()
                                authViewModel.register()
                                authViewModel.getIsRegister().observe(viewLifecycleOwner){
                                    if (it is SuccessScreenState){
                                        requireActivity().recreate()
                                    }
                                }
                            },
                            onError = {
                                showToast(R.string.account_logout_error)
                            }
                        )
                        )
                    }
                }
                FragmentAction.SHARE_DOCUMENT -> {
                    shareDocument(userDocViewModel.currentDoc)
                }

                else -> {}
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        photoContract =
            registerForActivityResult(TakePictureWithUriReturnContract()) { (success, imageUri) ->
                if (success) {
                    imageUri.let {
                        userDocViewModel.addDocs(listOf(it))
                    }
                }
            }

        docContract = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
            it?.let {
                userDocViewModel.addDocs(it)
            }
        }

        userDocViewModel.documentList.observe(viewLifecycleOwner) {
            val newList = mutableListOf<Document>()
            it.forEach { doc ->
                newList.add(doc.copy())
            }
            adapter.data = newList.toList()
            setLoadDocCount(it.size)

            binding.rcDocuments.visibility = if (it.isNotEmpty()) View.VISIBLE else View.GONE
        }

        userDocViewModel.photoUri.observe(viewLifecycleOwner) {
            photoContract.launch(it)
        }

        userDocViewModel.addResult.observe(viewLifecycleOwner) { state ->
            state.on(
                success = {},
                error = {
                    showToast(R.string.document_save_error)
                }
            )
        }

        userDocViewModel.renameResult.observe(viewLifecycleOwner) { state ->
            state.on(
                loading = {},
                success = {
                    when (it) {
                        true -> {
                            showToast(R.string.document_renamed)
                        }
                        false -> {
                            showToast(R.string.document_not_found)
                        }
                    }
                },
                error = {
                    showToast(R.string.document_renamed_error)
                }
            )
        }

        userDocViewModel.deleteResult.observe(viewLifecycleOwner) { state ->
            state.on(
                loading = {},
                success = {
                    when (it) {
                        true -> {
                            showToast(R.string.document_deleted)
                        }
                        false -> {
                            showToast(R.string.document_not_found)
                        }
                    }
                },
                error = {
                    showToast(R.string.document_deleted_error)
                }
            )
        }

        binding.apply {

            checkUserUiStatus()

            btnAddDocument.setOnClickListener {
                findNavController().navigate(R.id.action_userAccountFragment_to_selectFileDirectoryFragment)
            }

            connectUsButton.setOnClickListener() {
                findNavController().navigate(R.id.action_userAccountFragment_to_connectUsFragment)
            }

            saveUserStatusBundle()
            getConnectUsThemeBundle()

            btnAddDocument.setOnClickListener() {
                findNavController().navigate(R.id.action_userAccountFragment_to_selectFileDirectoryFragment)
            }

            logoutButton.setOnClickListener {
                findNavController().navigate(R.id.dialogLogoutFragment)
            }

            cardGoToProfile.setOnClickListener {
                if (isProfileFilled)
                    findNavController().navigate(R.id.action_userAccountFragment_to_userProfileFragment)
                else
                    findNavController().navigate(R.id.action_userAccountFragment_to_editUserProfileFragment)
            }

            becomeMasterButton.setOnClickListener {
                findNavController().navigate(
                    R.id.action_userAccountFragment_to_sendRequestMasterSubmissionFragment,
                    bundleOf("userId" to userId)
                )
            }

            btnAlreadyHaveAccount.setOnClickListener {
                findNavController().navigate(
                    R.id.action_userAccountFragment_to_checkPhoneNumFragment,
                    bundleOf("isRecoverAcc" to true)
                )
            }

            viewModel.user.observe(viewLifecycleOwner) { state ->
                if (!isGuest) {
                    state.on(
                        loading = {
                            binding.apply {
                                body.visibility = View.GONE
                                loading.visibility = View.VISIBLE
                            }
                        },
                        success = { user ->
                            if (!user.name.isNullOrEmpty() && !user.phone.isNullOrEmpty())
                                isProfileFilled = true
                            user.isMaster?.let {
                                isMaster = it
                            }
                            user.name?.let {
                                binding.tvUserAvatar.text = it
                            }
                            user.avatar?.let {
                                loadImageFromOurApi(
                                    binding.ivUserAvatar,
                                    it
                                )
                            }
                            checkUserUiStatus()
                            binding.body.visibility = View.VISIBLE
                            binding.loading.visibility = View.GONE
                        },
                        error = {
                            binding.body.visibility = View.GONE
                            binding.loading.visibility = View.GONE
                            showToast(R.string.connection_error)
                        }
                    )
                }
            }




            viewModel.status.observe(viewLifecycleOwner) { state ->
                state.on(
                    success = {
                        binding.chipPro.text = if (it.isSend) getString(R.string.message_sending) else getString(R.string.pro_chip)
                    },
                    error = {
                        Log.d("VVVVV", "viewModel.status.observe(viewLifecycleOwner): ${it.message}")
                    }
                )
            }

            viewModel.logout.observe(viewLifecycleOwner) { state ->
                state.on(
                    success = {
                        viewModel.logout().doOnComplete {

                        }
                    },
                    error = {
                        showToast(R.string.logout_error)
                    }
                )
            }
        }
    }

    override fun onResume() {
        userId?.let {
            with(viewModel) {
                getUserInfo(it)
                getUserStatus(it)
                checkUserUiStatus()
            }
        }
        super.onResume()
    }

    private fun shareDocument(doc: Document) {
        val providerUri = FileProvider.getUriForFile(requireContext(), "${BuildConfig.APPLICATION_ID}.provider", doc.uri.toFile())
        val intent = Intent(Intent.ACTION_SEND).apply {
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            putExtra(Intent.EXTRA_STREAM, providerUri)
            putExtra(Intent.EXTRA_TEXT, doc.userFileName)
            putExtra(Intent.EXTRA_SUBJECT, getString(R.string.share_extra))
            type = OpenFileUtils.getMimeType(providerUri.toString())
        }
        requireContext().startActivity(Intent.createChooser(intent, getString(R.string.share_to)))
    }

    private fun showToast(type: ToastType, masterTheme: Boolean = false) {

        when (type) {
            ToastType.CONNECT_US -> {
                showSpecialToast(
                    header = getString(R.string.message_sending),
                    message = if (masterTheme) {
                        getString(R.string.we_get_master_type)
                    } else {
                        getString(R.string.soon_read_your_message)
                    }
                )
            }
            ToastType.REQUEST_MASTER -> {
                showSpecialToast(
                    header = getString(R.string.thanks_for_connect),
                    message = getString(R.string.soon_read_your_message)
                )
            }
            ToastType.REQUEST_CANCELLED -> {
                showSpecialToast(
                    header = getString(R.string.request_cancelled_title),
                    message = getString(R.string.request_cancelled_text)
                )
            }
        }
    }

    private fun checkUserUiStatus() {
        if (isGuest) {
            showGuestUi()
        } else {
            binding.rcDocuments.adapter = adapter
            setLoadDocCount(adapter.data.size)
            if (!isMaster) {
                showOrdinaryUserUi()
            } else {
                showMasterUserUi()
            }
        }
    }

    private fun showGuestUi() {
        with(binding) {
            logoutButton.visibility = View.GONE
            clCreateAccount.visibility = View.VISIBLE
            clEnterAccount.visibility = View.GONE
            chipMaster.visibility = View.GONE
            ivProfileEllipse.visibility = View.GONE
            becomeMasterButton.visibility = View.GONE
            groupTripsButton.visibility = View.GONE
            tvUserProfile.apply {
                text = getString(R.string.create_account)
                setTextColor(ContextCompat.getColor(context, R.color.gray_70))
            }
            btnAlreadyHaveAccount.visibility = View.VISIBLE
            tvLoadDocsCount.visibility = View.GONE
            ivUserAvatar.setImageResource(R.drawable.ic_guest_avatar)
            btnAddDocument.visibility = View.GONE
            rcDocuments.visibility = View.GONE
            tvLoadDocsCount.visibility = View.GONE
        }
    }

    private fun showOrdinaryUserUi() {
        with(binding) {

            subscriptionButton.visibility = View.VISIBLE
            chipMaster.visibility = View.GONE
            ivProfileEllipse.visibility = View.GONE
            if (isProfileFilled) {
                clCreateAccount.visibility = View.GONE
                clEnterAccount.visibility = View.VISIBLE
                becomeMasterButton.visibility = View.VISIBLE
                groupTripsButton.visibility = View.VISIBLE
                tvLoadDocsCount.visibility = View.VISIBLE
                btnAddDocument.visibility = View.VISIBLE
                rcDocuments.visibility = View.VISIBLE
                btnAlreadyHaveAccount.visibility = View.GONE
            } else {
                clCreateAccount.visibility = View.VISIBLE
                clEnterAccount.visibility = View.GONE
                becomeMasterButton.visibility = View.GONE
                groupTripsButton.visibility = View.GONE
                tvLoadDocsCount.visibility = View.GONE
                btnAddDocument.visibility = View.GONE
                rcDocuments.visibility = View.GONE
                btnAlreadyHaveAccount.visibility = View.VISIBLE
            }
        }
    }

    private fun setLoadDocCount(count: Int) {
        val text = "${getString(R.string.load_documents_count)} ($count)"
        binding.tvLoadDocsCount.text = text
    }

    private fun showMasterUserUi() {
        with(binding) {
            clCreateAccount.visibility = View.GONE
            clEnterAccount.visibility = View.VISIBLE
            chipMaster.visibility = View.VISIBLE
            ivProfileEllipse.visibility = View.VISIBLE
            subscriptionButton.visibility = View.GONE
            btnAlreadyHaveAccount.visibility = View.GONE
            becomeMasterButton.visibility = View.GONE
            groupTripsButton.visibility = View.GONE
            tvLoadDocsCount.visibility = View.VISIBLE
            btnAddDocument.visibility = View.VISIBLE
            rcDocuments.visibility = View.VISIBLE
        }
    }

    private fun saveUserStatusBundle() {
        parentFragmentManager.setFragmentResultListener(
            SendRequestMasterSubmissionFragment.SEND_STATUS_KEY, viewLifecycleOwner
        ) { _, data ->

            if (data.getBoolean(SendRequestMasterSubmissionFragment.SEND_STATUS_DELETE)) {
                showToast(ToastType.REQUEST_CANCELLED)
            } else {
                viewModel.saveUserStatus(
                    RequestMasterStatus(
                        userId = data.getString(SendRequestMasterSubmissionFragment.SEND_STATUS_USER_ID)!!,
                        isSend = data.getBoolean(SendRequestMasterSubmissionFragment.SEND_STATUS_VALUE),
                        invitedMaster = data.getString(SendRequestMasterSubmissionFragment.SEND_STATUS_INVITED_MASTER_NAME),
                        message = data.getString(SendRequestMasterSubmissionFragment.SEND_STATUS_MESSAGE),
                        phone = data.getString(SendRequestMasterSubmissionFragment.SEND_STATUS_PHONE),
                        phoneCode = data.getString(SendRequestMasterSubmissionFragment.SEND_STATUS_PHONE_CODE),
                        imageUrl = data.getString(SendRequestMasterSubmissionFragment.SEND_STATUS_IMAGE_URL),
                        socialNetworks = data.getString(SendRequestMasterSubmissionFragment.SEND_STATUS_SOCIAL_NETWORKS)
                    )
                )
                showToast(ToastType.REQUEST_MASTER)
            }
        }
    }

    private fun getConnectUsThemeBundle() {
        parentFragmentManager.setFragmentResultListener(
            ConnectUsFragment.SEND_CONNECT_US_STATUS,
            viewLifecycleOwner
        ) { _, data ->
            if (data.getBoolean(ConnectUsFragment.SEND_CONNECT_US_STATUS_VALUE)) {
                if (data.getString(ConnectUsFragment.SEND_CONNECT_US_STATUS_THEME) == getString(
                        R.string.master_new_type
                    )
                ) {
                    showToast(ToastType.CONNECT_US, true)
                } else {
                    showToast(ToastType.CONNECT_US)
                }
            }
        }
    }

    override fun onDestroyView() {
        compositeDisposable.clear()
        super.onDestroyView()
    }

    enum class ToastType {
        CONNECT_US,
        REQUEST_MASTER,
        REQUEST_CANCELLED
    }

    companion object {
        const val REQUEST_ACTION_KEY = "UserAccountFragment_request_action"
        const val ACTION_BUNDLE_KEY = "UserAccountFragment_action_bundle_key"
        const val ACTION_NAME_KEY = "UserAccountFragment_action_name_key"

        private val mimeArray = arrayOf(
            OpenFileUtils.mimePDF, OpenFileUtils.mimeDOC, OpenFileUtils.mimeJPG,
            OpenFileUtils.mimeTIF, OpenFileUtils.mimePNG, OpenFileUtils.mimeMP4,
            OpenFileUtils.mimeAVI
        )
    }

    enum class FragmentAction {
        TAKE_PHOTO,
        CHOOSE_DOC,
        RENAME_DOC,
        RENAMED,
        DELETE_DOC,
        NEED_LOGOUT,
        SHARE_DOCUMENT
    }
}