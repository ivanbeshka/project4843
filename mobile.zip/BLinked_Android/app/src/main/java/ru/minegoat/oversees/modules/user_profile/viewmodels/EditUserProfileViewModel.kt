package ru.minegoat.oversees.modules.user_profile.viewmodels

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.base.viewmodels.*
import ru.minegoat.oversees.domain.auth.Phone
import ru.minegoat.oversees.domain.user.Sex
import ru.minegoat.oversees.domain.user.User
import ru.minegoat.oversees.domain.user.MasterSkill
import ru.minegoat.oversees.modules.user_profile.model.ImageData
import ru.minegoat.oversees.domain.user.SocialNetwork
import ru.minegoat.oversees.modules.user_profile.repository.UserProfileRepository

class EditUserProfileViewModel @AssistedInject constructor(
    private val userProfileRepo: UserProfileRepository
) : RxViewModel() {

    private val _user = MutableLiveData<User>()
    val user: LiveData<User> get() = _user

    private val _isUserSaved = MutableLiveData<ScreenState<Boolean>>()
    val isUserSaved: LiveData<ScreenState<Boolean>> get() = _isUserSaved

    fun setUser(user: User) {
        if (_user.value == null) {
            Log.d("save new user data", "newUser = NULL user = $user")
            _user.value = user
        }
    }

    fun setUser(
        name: String? = null,
        aboutMe: String? = null,
        sex: Sex? = null,
        homeLocationId: String? = null,
        phone: Phone? = null,
        isDeleteAva: Boolean = false,
        socialNetworks: List<SocialNetwork>? = null,
        skills: List<MasterSkill>? = null
    ) {
        val userCopy = user.value
        userCopy?.copy(
            name = name ?: userCopy.name,
            description = aboutMe ?: userCopy.description,
            sex = sex ?: userCopy.sex,
            homeLocationId = homeLocationId ?: userCopy.homeLocationId,
            phone = phone ?: userCopy.phone,
            avatarUrl = if (isDeleteAva) {
                null
            } else {
                userCopy.avatarUrl
            },
            // Установить isMaster = true или false для запуска в режиме мастера или юзера и сохранить.
            isMaster = false,//userCopy.isMaster ,
            socialNetworks = socialNetworks ?: userCopy.socialNetworks,
            skills = skills ?: userCopy.skills
        )?.let {
            _user.value = it
        }
    }

    fun saveUser(imageToImageData: () -> ImageData) {
        user.value?.let { user ->
            userProfileRepo.saveUserProfile(user, imageToImageData)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe { _isUserSaved.value = LoadingScreenState() }
                .subscribeBy(
                    onComplete = {
                        _isUserSaved.value = SuccessScreenState(true)
                    },
                    onError = {
                        _isUserSaved.value = ErrorScreenState(it)
                    }
                )
                .disposeOnFinish()
        }
    }

    fun saveUserProfileForSkills() {
        user.value?.let { user ->
            userProfileRepo.saveUserProfileForSkills(user)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe { _isUserSaved.value = LoadingScreenState() }
                .subscribeBy(
                    onComplete = {
                        _isUserSaved.value = SuccessScreenState(true)
                    },
                    onError = {
                        _isUserSaved.value = ErrorScreenState(it)
                    }
                )
                .disposeOnFinish()
        }
    }

    @AssistedFactory
    interface Factory {
        fun create(): EditUserProfileViewModel
    }
}