package ru.minegoat.oversees.domain.feedback

enum class CommentType {
    NOTE,
    REVIEW
}

val Int.toCommentType
    get() =
        if (this == CommentType.NOTE.ordinal) CommentType.NOTE
        else CommentType.REVIEW