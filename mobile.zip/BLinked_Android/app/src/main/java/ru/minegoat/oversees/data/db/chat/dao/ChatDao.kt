package ru.minegoat.oversees.data.db.chat.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.Single
import ru.minegoat.oversees.data.db.chat.ChatRoom

@Dao
interface ChatDao {

    @Query("SELECT * FROM chats")
    fun getAll(): Single<List<ChatRoom>>

    @Query("SELECT * FROM chats WHERE objID=:id")
    fun getById(id: String): Maybe<ChatRoom>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(vararg chats: ChatRoom): Completable
}