package ru.minegoat.oversees.data.network.user.model

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.user.UserRatingLevel

data class ResponseRatingLevel(
    @SerializedName("type")
    val type: ResponseRatingType,

    @SerializedName("points")
    val points: Int,

    @SerializedName("scale")
    val scale: Int,

    @SerializedName("name")
    val name : String
)

fun ResponseRatingLevel.toUserRatingLevel(): UserRatingLevel{
    return UserRatingLevel(
        points = points,
        scale = scale,
        typeName = type.name
    )
}

