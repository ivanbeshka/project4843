package ru.minegoat.oversees.modules.user_profile.viewmodels

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.base.viewmodels.*
import ru.minegoat.oversees.data.repository.location.LocationRepository
import ru.minegoat.oversees.domain.master.MasterInfo
import ru.minegoat.oversees.domain.user.User
import ru.minegoat.oversees.modules.master_profile.repository.MasterInfoRepository
import ru.minegoat.oversees.modules.user_profile.model.ImageData
import ru.minegoat.oversees.modules.user_profile.network.UserProfileApi
import ru.minegoat.oversees.domain.user.UserRating
import ru.minegoat.oversees.modules.user_profile.presentation.UserProfileFragment.ProfileType
import ru.minegoat.oversees.modules.user_profile.repository.UserProfileRepository

class UserProfileViewModel @AssistedInject constructor(
    private var userProfileApi: UserProfileApi,
    private val userProfileRepo: UserProfileRepository,
    private val locationRepository: LocationRepository,
    private val masterInfoRepository: MasterInfoRepository
) : RxViewModel() {

    private val userLiveData = MutableLiveData<ScreenState<User>>()
    val user: LiveData<ScreenState<User>> = userLiveData

    private val locationName = MutableLiveData<ScreenState<String>>()
    val locationNameLiveData: LiveData<ScreenState<String>>
        get() = locationName

    private val _masterInfo = MutableLiveData<ScreenState<MasterInfo>>()
    val masterInfo: LiveData<ScreenState<MasterInfo>> get() = _masterInfo

    private val _isUserSaved = MutableLiveData<ScreenState<Boolean>>()
    val isUserSaved: LiveData<ScreenState<Boolean>> get() = _isUserSaved

    fun getUserProfile(profileType: ProfileType, otherUserId: String? = null, showLoading: Boolean = true) {
        userProfileRepo.getUserProfile(profileType, otherUserId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe {
                if (showLoading) userLiveData.postValue(LoadingScreenState()) }
            .subscribeBy(
                onSuccess = {
                    userLiveData.postValue(SuccessScreenState(it))
                },
                onError = {
                    it.printStackTrace()
                    userLiveData.postValue(ErrorScreenState(it))
                },
            )
            .disposeOnFinish()
    }

    fun getLocationById(id: String) {
        locationRepository.getLocationById(id)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { locationName.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    if (it.name != null) {
                        locationName.postValue(SuccessScreenState(it.address ?: it.name))
                    } else {
                        locationName.postValue(ErrorScreenState(NullPointerException()))
                    }
                },
                onError = {
                    locationName.postValue(ErrorScreenState(it))
                }
            )
            .disposeOnFinish()
    }

    fun getMasterTypeByUserId(userID: String) {
        masterInfoRepository.getMasterInfoByUserId(userID)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeBy(
                onSuccess = {
                    _masterInfo.postValue(SuccessScreenState(it))
                },
                onError = {
                    _masterInfo.postValue(ErrorScreenState(it))

                }
            ).disposeOnFinish()
    }

    fun saveUser(imageToImageData: () -> ImageData) {
        if (user.value is SuccessScreenState) {
            (user.value as SuccessScreenState<User>).data.let { user ->
                userProfileRepo.saveUserProfile(user, imageToImageData)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribeBy(
                        onComplete = {
                            getUserProfile(ProfileType.MY, null, false)
                        },
                        onError = {
                            _isUserSaved.postValue(ErrorScreenState(it))
                        }
                    )
                    .disposeOnFinish()
            }
        }
    }

    fun deleteProfile() = userProfileApi.deleteUserProfile()

    @AssistedFactory
    interface Factory {
        fun create(): UserProfileViewModel
    }
}