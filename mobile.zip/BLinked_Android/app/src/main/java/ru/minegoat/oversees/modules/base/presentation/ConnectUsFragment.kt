package ru.minegoat.oversees.modules.base.presentation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import android.widget.ArrayAdapter
import androidx.core.os.bundleOf
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.base.utils.ui.fragment.showToast
import ru.minegoat.oversees.databinding.FragmentConnectUsBinding
import ru.minegoat.oversees.modules.base.di.ConnectUsComponentHolder
import ru.minegoat.oversees.modules.base.model.SendMessageModelUi

class ConnectUsFragment : Fragment(R.layout.fragment_connect_us) {
    private val binding by viewBinding(FragmentConnectUsBinding::bind)

    private val component by featureComponent(ConnectUsComponentHolder)

    private val viewModel by lazyViewModel {
        component.sendConnectUsMessageViewModel().create()
    }

    private val messageType: Int by lazy { arguments?.getInt(MESSAGE_TYPE) ?: -1 }
    private val messageText: String? by lazy { arguments?.getString(MESSAGE_TEXT) }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val messageTypeList = resources.getStringArray(R.array.send_us_message_type)
        val arrayAdapter = ArrayAdapter(requireContext(), R.layout.item_dropdown, messageTypeList)
        binding.apply {
            messageTypeTextView.setAdapter(arrayAdapter)
            messageTypeTextView.setText(messageTypeList[if (messageType != -1) messageType else 3], false)
            messageText?.run {
                messageEditText.setText(messageText)
            }
        }

        binding.apply {
            sendButton.setOnClickListener {
                if (messageEditText.text.isNotBlank()) {
                    viewModel.sendMessage(
                        SendMessageModelUi(
                            "Test",
                            "TestName",
                            binding.messageEditText.text.toString(),
                            binding.messageTypeTextView.text.toString(),
                        )
                    )
                } else {
                    showToast(R.string.connect_us_enter_message)
                }
            }
            toolbar.setNavigationOnClickListener {
                findNavController().navigateUp()
            }
        }

        viewModel.isSend.observe(viewLifecycleOwner) { state ->
            state.on(
                loading = {},
                success = {
                    setResult(true, binding.messageTypeTextView.text.toString())
                },
                error = {
                    showToast(R.string.connect_us_send_error)
                }
            )
        }

    }

    private fun setResult(isSent:Boolean, message:String){
        parentFragmentManager.setFragmentResult(
            SEND_CONNECT_US_STATUS,
            bundleOf(
                SEND_CONNECT_US_STATUS_VALUE to isSent,
                SEND_CONNECT_US_STATUS_THEME to message
            )
        )
        findNavController().navigateUp()
    }

    companion object {
        const val SEND_CONNECT_US_STATUS = "SEND_CONNECT_US_STATUS"
        const val SEND_CONNECT_US_STATUS_VALUE = "SEND_CONNECT_US_STATUS_VALUE"
        const val SEND_CONNECT_US_STATUS_THEME = "SEND_CONNECT_US_STATUS_THEME"
        const val MESSAGE_TYPE = "messageType"
        const val MESSAGE_TEXT = "messageText"
    }
}