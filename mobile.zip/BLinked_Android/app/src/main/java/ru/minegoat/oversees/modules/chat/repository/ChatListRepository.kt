package ru.minegoat.oversees.modules.chat.repository

import io.reactivex.Flowable
import io.reactivex.Single
import ru.minegoat.oversees.base.db.room.RoomDB
import ru.minegoat.oversees.data.db.chat.MessageRoom
import ru.minegoat.oversees.data.db.chat.toChatItem
import ru.minegoat.oversees.data.network.chat.model.toRoom
import ru.minegoat.oversees.data.repository.user.UserRepository
import ru.minegoat.oversees.modules.chat.di.ChatScope
import ru.minegoat.oversees.modules.chat.model.ChatItemUi
import ru.minegoat.oversees.modules.chat.network.ChatListItemsApi
import ru.minegoat.oversees.modules.chat.network.responses.toChatItem
import ru.minegoat.oversees.modules.chat.network.responses.toRoom
import javax.inject.Inject

@ChatScope
class ChatListRepository @Inject constructor(
    private val roomDB: RoomDB,
    private val api: ChatListItemsApi,
    private val userRepo: UserRepository
) {

    fun getChatListItems(): Flowable<List<ChatItemUi>> {
        return getChatListItemsFromNetwork().concatWith(getChatListItemsFromDS())
    }

    private fun getChatListItemsFromNetwork(): Single<List<ChatItemUi>> {
        return api.getChatListItems()
            .doOnSuccess { list ->

                list.forEach {
                    val chat = it.chat.toRoom()
                    val message = it.lastMessage.toRoom()

                    roomDB.chatDao().insertAll(chat).subscribe()
                    roomDB.messageDao().insertAll(message).subscribe()
                }
                
            }
            .map { responseList ->
                responseList.map {
                    it.toChatItem("") //todo
                }
            }
    }

    private fun getChatListItemsFromDS(): Single<List<ChatItemUi>> {
        return roomDB.chatDao().getAll()
            .flattenAsObservable { it }
            .flatMap { chatRoom ->

                roomDB.messageDao().getById(chatRoom.messagesIds.last())
                    .defaultIfEmpty(MessageRoom.empty())
                    .map { messageRoom ->
                        chatRoom to messageRoom
                    }
                    .toObservable()

            }
            .map {
                it.first.toChatItem(it.second, "")
            }
            .toList()
    }
}