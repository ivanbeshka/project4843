package ru.minegoat.oversees.domain.user

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize
import ru.minegoat.oversees.R

@Parcelize
data class SocialNetwork(
    @SerializedName("name")
    val name: SocialNetworkName,
    @SerializedName("link")
    var link: String?
): Parcelable

@Parcelize
enum class SocialNetworkName: Parcelable {
    INSTAGRAM, FACEBOOK, TWITTER, VK, TELEGRAM, YOUTUBE;

    val res: Int
        get() {
            return when (this) {
                INSTAGRAM -> R.string.instagram
                FACEBOOK -> R.string.facebook
                TWITTER -> R.string.twitter
                VK -> R.string.vk
                TELEGRAM -> R.string.telegram
                YOUTUBE -> R.string.youtube
            }
        }
}