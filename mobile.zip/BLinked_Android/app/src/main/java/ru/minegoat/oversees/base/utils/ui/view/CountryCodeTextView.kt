package ru.minegoat.oversees.base.utils.ui.view

import android.graphics.drawable.Drawable
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ImageSpan
import android.widget.TextView
import androidx.core.content.ContextCompat
import ru.minegoat.oversees.domain.user.CountryPhone

fun setCountryCode(textView: TextView, countryPhone: CountryPhone){
    textView.apply {
        val newText = "<picto> ${countryPhone.phonePrefix}"
        val drawable =
            ContextCompat.getDrawable(textView.context, countryPhone.countryCode.resId)!!
                .apply {
                    val density = 2
                    setBounds(0, 0, 28 * density, 16 * density)
                }
        text = newText
        replaceTagWithDrawable("<picto>", { drawable })

    }
}

fun TextView.replaceTagWithDrawable(
    tag: String,
    drawableFactory: () -> Drawable,
    ignoreCase: Boolean = true
) {
    val tagPos = text.indexOf(tag, ignoreCase = ignoreCase)
    if (tagPos >= 0) {
        var spannableString = text as? SpannableString?
        if (spannableString == null) {
            spannableString = SpannableString(text)
        }
        spannableString.setSpan(
            ImageSpan(drawableFactory(), ImageSpan.ALIGN_BASELINE),
            tagPos,
            tagPos + tag.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        text = spannableString
    }
}