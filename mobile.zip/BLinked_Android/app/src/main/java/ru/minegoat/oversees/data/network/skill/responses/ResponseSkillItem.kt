package ru.minegoat.oversees.data.network.skill.responses

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.user.Skill
import kotlinx.parcelize.Parcelize

@Parcelize
data class ResponseSkillItem(
    @SerializedName("objID")
    val objId: String,
    @SerializedName("ownerID")
    val ownerId: String?,
    @SerializedName("tags")
    val tags: List<String>,
    @SerializedName("name")
    val name: String,
    @SerializedName("skillDescription")
    val skillDescription: String?,
    @SerializedName("internationalDescription")
    val internationalDescription: String?,
    @SerializedName("internationalName")
    val internationalName: String?
):Parcelable

fun ResponseSkillItem.toBusiness(): Skill {
    return Skill(
        objId = objId,
        ownerId = ownerId,
        tags = tags,
        name = name,
        skillDescription = skillDescription,
        internationalDescription = internationalDescription,
        internationalName = internationalName
    )
}
