package ru.minegoat.oversees.base.di.modules

import dagger.Module
import dagger.Provides
import retrofit2.Retrofit
import ru.minegoat.oversees.base.helpers.auth.Authenticator
import ru.minegoat.oversees.base.helpers.auth.INeedTokenUpdate
import ru.minegoat.oversees.data.network.auth.AuthApi
import ru.minegoat.oversees.data.repository.auth.AuthRepository
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import javax.inject.Singleton

@Module
class AuthModule {

    @Singleton
    @Provides
    fun provideAuthenticator(
        authSharedPref: AuthSharedPref,
        authRepository: AuthRepository
    ): Authenticator =
        Authenticator(authSharedPref, authRepository)

    @Singleton
    @Provides
    fun provideAuthApi(retrofit: Retrofit): AuthApi =
        retrofit.create(AuthApi::class.java)

    @Singleton
    @Provides
    fun provideINeedTokenUpdate(authenticator: Authenticator): INeedTokenUpdate {
        return authenticator
    }
}