package ru.minegoat.oversees.base.di.modules

import dagger.Module
import dagger.Provides
import io.github.centrifugal.centrifuge.*
import ru.minegoat.oversees.modules.chat.network.MessageTransportApi
import ru.minegoat.oversees.modules.chat.network.MessageTransportApiImpl
import java.nio.charset.StandardCharsets

@Module
class MessageTransportModule {

    @Provides
    fun provideMessageTransportApi() : MessageTransportApi {
        val listener: EventListener = object : EventListener() {
            override fun onConnected(client: Client, event: ConnectedEvent) {
                System.out.printf("connected with client id %s%n", event.client)
            }

            override fun onConnecting(client: Client, event: ConnectingEvent) {
                System.out.printf("connecting: %s%n", event.reason)
            }

            override fun onDisconnected(client: Client, event: DisconnectedEvent) {
                System.out.printf("disconnected %d %s%n", event.code, event.reason)
            }

            override fun onError(client: Client, event: ErrorEvent) {
                System.out.printf("connection error: %s%n", event.error.toString())
            }

            override fun onMessage(client: Client, event: MessageEvent) {
                val data = String(event.data, StandardCharsets.UTF_8)
                println("message received: $data")
            }

            override fun onSubscribed(client: Client, event: ServerSubscribedEvent) {
                println("server side subscribed: " + event.channel + ", recovered " + event.recovered)
            }

            override fun onSubscribing(client: Client, event: ServerSubscribingEvent) {
                println("server side subscribing: " + event.channel)
            }

            override fun onUnsubscribed(client: Client, event: ServerUnsubscribedEvent) {
                println("server side unsubscribed: " + event.channel)
            }

            override fun onPublication(client: Client, event: ServerPublicationEvent) {
                val data = String(event.data, StandardCharsets.UTF_8)
                println("server side publication: " + event.channel + ": " + data)
            }

            override fun onJoin(client: Client, event: ServerJoinEvent) {
                println("server side join: " + event.channel + " from client " + event.info.client)
            }

            override fun onLeave(client: Client, event: ServerLeaveEvent) {
                println("server side leave: " + event.channel + " from client " + event.info.client)
            }
        }
        val opts = Options()
        opts.token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzMjIifQ.T37dMzcyGODhrPN4TVwyYXnZ-OvPFy9CovGrh6V4Gvc"
        val client = Client(
            "ws://test.minegoat.ru:8000/connection/websocket?cf_protocol_version=v2",
            opts,
            listener
        )
        return MessageTransportApiImpl(client)
    }
}