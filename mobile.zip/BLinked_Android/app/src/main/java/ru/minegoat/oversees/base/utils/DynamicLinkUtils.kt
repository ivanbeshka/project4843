package ru.minegoat.oversees.base.utils

import android.net.Uri
import com.google.android.gms.tasks.Task
import com.google.firebase.dynamiclinks.DynamicLink
import com.google.firebase.dynamiclinks.FirebaseDynamicLinks
import com.google.firebase.dynamiclinks.ShortDynamicLink
import com.google.firebase.dynamiclinks.ktx.shortLinkAsync


private const val DOMAIN = "https://oversees.page.link"
private const val ANDROID_PACKAGE_NAME = "ru.minegoat.oversees"
private const val IOS_PACKAGE_NAME = "ru.minegoat.BLinked"

private fun createDynamicUri(uri: Uri): Uri {

    val dynamicLink = FirebaseDynamicLinks.getInstance()
        .createDynamicLink()
        .setLink(uri)
        .setDomainUriPrefix(DOMAIN)
        .setAndroidParameters(DynamicLink.AndroidParameters.Builder(ANDROID_PACKAGE_NAME).build())
        .setIosParameters(DynamicLink.IosParameters.Builder(IOS_PACKAGE_NAME).build())
        .buildDynamicLink()

    return dynamicLink.uri
}

fun createShortDynamicLinkTask(uri: Uri): Task<ShortDynamicLink> {


    return FirebaseDynamicLinks.getInstance().shortLinkAsync {
        longLink = createDynamicUri(uri)
    }


}
