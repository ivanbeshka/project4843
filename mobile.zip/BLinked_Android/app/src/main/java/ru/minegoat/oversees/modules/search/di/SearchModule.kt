package ru.minegoat.oversees.modules.search.di

import dagger.Module
import dagger.Provides
import retrofit2.Retrofit
import ru.minegoat.oversees.data.repository.user.UserRepository
import ru.minegoat.oversees.modules.trip.network.TripApi
import ru.minegoat.oversees.modules.trip.repository.TripRepository
import javax.inject.Singleton

@Module
class SearchModule {

    @SearchScope
    @Provides
    fun provideTripRepository(api: TripApi, userRepository: UserRepository): TripRepository =
        TripRepository(api, userRepository)

    @SearchScope
    @Provides
    fun provideTripApi(retrofit: Retrofit) : TripApi =
        retrofit.create(TripApi::class.java)


}