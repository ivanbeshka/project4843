package ru.minegoat.oversees.data.db.userProfile.converters

import androidx.room.*
import ru.minegoat.oversees.domain.karma.Karma
import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

@ProvidedTypeConverter
class KarmaTypeConverter {

    @TypeConverter
    fun fromKarma(karma: Karma?): String {
        return Gson().toJson(karma)
    }

    @TypeConverter
    fun toKarma(value: String): Karma? {
        val type = object : TypeToken<Karma>() {}.type
        return Gson().fromJson(value, type)
    }
}