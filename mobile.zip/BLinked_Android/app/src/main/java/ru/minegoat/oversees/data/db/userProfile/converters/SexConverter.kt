package ru.minegoat.oversees.data.db.userProfile.converters

import androidx.room.ProvidedTypeConverter
import androidx.room.TypeConverter
import ru.minegoat.oversees.domain.user.Sex

@ProvidedTypeConverter
class SexConverter {
    @TypeConverter
    fun fromString(sex: String?): Sex? {
        return sex?.uppercase()?.let { Sex.valueOf(it) }
    }

    @TypeConverter
    fun toString(sex: Sex?): String? {
        return sex?.name?.lowercase()
    }
}