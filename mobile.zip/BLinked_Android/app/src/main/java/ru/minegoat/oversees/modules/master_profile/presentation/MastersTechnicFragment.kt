package ru.minegoat.oversees.modules.master_profile.presentation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.FragmentMastersTechnicBinding

class MastersTechnicFragment : Fragment(R.layout.fragment_masters_technic) {

    private lateinit var recyclerview: RecyclerView
    private var adapter: RecyclerView.Adapter<MastersAdapter.MainViewHolder>? = null

    private val binding by viewBinding(FragmentMastersTechnicBinding::bind)


    override fun onViewCreated(itemView: View, savedInstanceState: Bundle?) {
        super.onViewCreated(itemView, savedInstanceState)

        val cl = R.layout.fragment_masters_technic

        binding.rvMasters.apply {
            // set a LinearLayoutManager to handle Android
            // RecyclerView behavior
            // set the custom adapter to the RecyclerView
            adapter = MastersAdapter()
        }
    }
}