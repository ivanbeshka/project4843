package ru.minegoat.oversees.modules.user_profile.presentation

import android.view.View
import ru.minegoat.oversees.domain.document.Document

interface DocumentsRecyclerLongClickListener {
    fun onClick(v: View, position: Int, document: Document)
    fun onLongClick(v: View, position: Int, document: Document)
}