package ru.minegoat.oversees.modules.search.presentation

import android.view.View
import ru.minegoat.oversees.domain.user.Skill

interface RecyclerSkillDescriptionClickListener {
    fun onClick(v: View, position: Int, item: Skill)
}