package ru.minegoat.oversees.data.sharedpref

import android.content.Context
import ru.minegoat.oversees.base.helpers.syncer.SyncSessionStatus
import ru.minegoat.oversees.base.helpers.syncer.Syncer.Companion.SYNC_ALL_DATE
import ru.minegoat.oversees.base.helpers.syncer.SyncerStatus
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SyncerSharedPref @Inject constructor(context: Context) {

    private val preferences = context.getSharedPreferences(SHARED_PREF_KEY, Context.MODE_PRIVATE)

    var syncerStatus: SyncerStatus
        get() {
            return preferences.getString(SYNCER_STATUS_KEY, SyncerStatus.VACANT.name)!!
                .let { SyncerStatus.valueOf(it) }
        }
        set(value) {
            preferences.edit()
                .putString(SYNCER_STATUS_KEY, value.name)
                .apply()
        }

    var currentSession: UUID?
        get() {
            return preferences.getString(CURRENT_SESSION_KEY, null)?.let {
                UUID.fromString(it)
            }
        }
        set(value) {
            value?.let {
                preferences.edit()
                    .putString(CURRENT_SESSION_KEY, it.toString())
                    .apply()
            }
        }

    var sessionStatus: SyncSessionStatus?
        get() {
            return preferences.getString(SESSION_STATUS_KEY, null)
                ?.let { SyncSessionStatus.valueOf(it) }
        }
        set(value) {
            value?.let {
                preferences.edit()
                    .putString(SESSION_STATUS_KEY, it.name)
                    .apply()
            }
        }

    var sessionDate: Date
        get() {
            return Date(preferences.getString(SESSION_DATE, SYNC_ALL_DATE.toString())!!.toLong())
        }
        set(value) {
            preferences.edit()
                .putString(SESSION_DATE, value.time.toString())
                .apply()
        }

    var sessionCounter: Int
        get() {
            return preferences.getInt(SESSION_COUNTER, START_SESSION_COUNT)
        }
        set(value) {
            preferences.edit()
                .putInt(SESSION_COUNTER, value)
                .apply()
        }

    private companion object {
        private const val SHARED_PREF_KEY = "syncer_shared_pref"

        private const val SYNCER_STATUS_KEY = "syncer_status"
        private const val CURRENT_SESSION_KEY = "current_session"
        private const val SESSION_STATUS_KEY = "session_status"
        private const val SESSION_DATE = "session_date"
        private const val SESSION_COUNTER = "session_counter"

        private const val START_SESSION_COUNT = 1
    }
}