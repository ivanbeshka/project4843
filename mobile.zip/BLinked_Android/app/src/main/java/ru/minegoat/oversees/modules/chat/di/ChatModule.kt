package ru.minegoat.oversees.modules.chat.di

import dagger.Module
import dagger.Provides
import ru.minegoat.oversees.modules.chat.network.ChatApi
import ru.minegoat.oversees.modules.chat.network.ChatApiImpl
import ru.minegoat.oversees.modules.chat.network.ChatListItemsApi
import ru.minegoat.oversees.modules.chat.network.ChatListItemsApiImpl
import ru.minegoat.oversees.modules.chat.viewmodels.ChatNamePredicateSubManager
import ru.minegoat.oversees.modules.chat.viewmodels.UnreadMsgCountForTabsSubManager

@Module
class ChatModule {

    @ChatScope
    @Provides
    fun provideChatApi(): ChatApi {
        return ChatApiImpl()
    }

    @ChatScope
    @Provides
    fun provideChatListItemsApi(): ChatListItemsApi {
        return ChatListItemsApiImpl()
    }

    @ChatScope
    @Provides
    fun provideChatNamePredicateSubManager(): ChatNamePredicateSubManager {
        return ChatNamePredicateSubManager()
    }

    @ChatScope
    @Provides
    fun provideUnreadMsgCountForTabsSubManager(): UnreadMsgCountForTabsSubManager {
        return UnreadMsgCountForTabsSubManager()
    }
}