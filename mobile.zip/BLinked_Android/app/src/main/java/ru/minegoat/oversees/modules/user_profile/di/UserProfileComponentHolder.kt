package ru.minegoat.oversees.modules.user_profile.di

import ru.minegoat.oversees.App
import ru.minegoat.oversees.base.di.holders.FeatureComponentHolder

object UserProfileComponentHolder : FeatureComponentHolder<UserProfileComponent>() {
    override fun build(): UserProfileComponent{
        return DaggerUserProfileComponent.builder()
            .appComponent(App.component)
            .userProfileModule(UserProfileModule())
            .build()
    }
}