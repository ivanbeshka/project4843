package ru.minegoat.oversees.data.repository.document

import io.reactivex.Completable
import io.reactivex.Observable
import io.reactivex.Single
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import ru.minegoat.oversees.data.db.document.DocumentRealm
import ru.minegoat.oversees.data.db.document.toDocument
import ru.minegoat.oversees.domain.document.Document
import ru.minegoat.oversees.domain.document.toDocumentRealm
import javax.inject.Inject

class DocumentRepository @Inject constructor(
    val ds: RealmDataStorage
) {
    private companion object {
        private const val OBJ_LINK_ID_PREDICATE = "linkedObjId ="
    }

    fun saveDocs(vararg doc: Document, linkedObjId: String): Single<List<Document>> =
        Observable
            .fromIterable(
                arrayListOf(*doc)
            )
            .map {
                it.toDocumentRealm(linkedObjId)
            }
            .map {
                it.apply {
                    ds.save(it).subscribe()
                }
            }
            .map {
                it.toDocument()
            }.toList()

    fun getDocs(linkedObjId: String): Single<List<Document>> =
        ds.fetch(
            model = DocumentRealm::class,
            predicate = "$OBJ_LINK_ID_PREDICATE \'$linkedObjId\'"
        )
            .flattenAsFlowable {
                it
            }
            .map {
                it.toDocument()
            }
            .toList()

    fun removeDoc(id: String): Completable =
        ds.delete(
            ds.getById(DocumentRealm::class, id).blockingGet()
        )

    fun updateDocName(id: String, newName: String): Completable =
        Completable.fromObservable(
            ds.getById(DocumentRealm::class, id)
                .map {
                    it.apply {
                        userFileName = newName
                    }
                }.toObservable()
        )
}