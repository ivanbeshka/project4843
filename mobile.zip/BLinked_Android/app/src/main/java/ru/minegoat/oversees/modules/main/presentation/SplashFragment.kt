package ru.minegoat.oversees.modules.main.presentation

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.modules.main.di.auth.AuthComponentHolder

class SplashFragment : Fragment(R.layout.fragment_splash) {

    private val component by featureComponent(AuthComponentHolder)

    private val viewModel by lazyViewModel {
        component.authViewModel().create()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        viewModel.getIsRegister().observe(viewLifecycleOwner) { state ->
            state.on(
                success = {
                    if (it) {
                        findNavController().navigate(R.id.action_splashFragment_to_trips)
                    } else {
                        findNavController().navigate(R.id.action_splashFragment_to_authFragment)
                    }
                },
                error = {
                    findNavController().navigate(R.id.action_splashFragment_to_authFragment)
                }
            )
        }

        viewModel.register()
    }
}