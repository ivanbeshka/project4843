package ru.minegoat.oversees.data.db.master

import io.realm.kotlin.ext.realmListOf
import io.realm.kotlin.types.ObjectId
import io.realm.kotlin.types.RealmList
import io.realm.kotlin.types.RealmObject
import io.realm.kotlin.types.annotations.Index
import io.realm.kotlin.types.annotations.PrimaryKey
import ru.minegoat.oversees.domain.master.MasterInfo
import ru.minegoat.oversees.domain.master.MasterType
import ru.minegoat.oversees.modules.user_profile.network.model.RequestMasterInfo
import ru.minegoat.oversees.modules.master_profile.repository.MasterInfoRepository

class MasterInfoRealm() : RealmObject {

    @PrimaryKey
    var id: ObjectId = ObjectId.create()
    val objID: String //(computed value)
        get() {
            return id.toString()
        }

    var masterTypesIds: RealmList<String> = realmListOf()
    var path: String = ""

    @Index
    var masterId: String = ""

    constructor(
        objID: String,
        masterTypesIds: RealmList<String>,
        path: String,
        masterId: String
    ) : this() {
        this.id = ObjectId.Companion.from(objID)
        this.masterTypesIds = masterTypesIds
        this.path = path
        this.masterId = masterId
    }

}

fun MasterInfoRealm.toMasterInfo(repo: MasterInfoRepository): MasterInfo {
    return MasterInfo(
        objId = this.objID,
        path = this.path,
        masterId = masterId,

        //TODO: ЗАМЕНИТЬ ЗАГЛУШКУ MasterType
        masterTypes = masterTypesIds.map {
            MasterType(it,"temp","")
        }
    )
}

fun MasterInfoRealm.toRequestMasterInfo() =
    RequestMasterInfo(
        objID = objID,
        masterTypes = masterTypesIds.toList(),
        path = path,
        masterId = masterId
    )