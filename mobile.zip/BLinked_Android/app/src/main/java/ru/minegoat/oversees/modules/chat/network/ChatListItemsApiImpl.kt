package ru.minegoat.oversees.modules.chat.network

import io.reactivex.Single
import ru.minegoat.oversees.modules.chat.network.responses.ChatItemResponse

class ChatListItemsApiImpl : ChatListItemsApi {
    override fun getChatListItems(): Single<List<ChatItemResponse>> {
        return Single.just(listOf())
    }
}