package ru.minegoat.oversees.modules.trip.model

import ru.minegoat.oversees.R

sealed class TripDetailTab(val name : Int, val enabled : Boolean){
    object Review: TripDetailTab(R.string.browse, false)
    object Detail: TripDetailTab(R.string.detail, false)
    object Blog: TripDetailTab(R.string.blog,true)
}
