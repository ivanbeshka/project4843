package ru.minegoat.oversees.modules.map.model

import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.clustering.ClusterItem
import ru.minegoat.oversees.domain.location.Location

class LocationClusterItem(
    private val latLng: LatLng,
    val location: Location,
    private val title: String? = null,
    private val snippet: String? = null
) : ClusterItem {

    override fun getPosition(): LatLng {
        return latLng
    }

    override fun getTitle(): String? {
        return title
    }

    override fun getSnippet(): String? {
        return snippet
    }
}
