package ru.minegoat.oversees.modules.user_profile.viewmodels

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject

class EditAvatarViewModel @AssistedInject constructor() : ViewModel() {

    private val imageUri = MutableLiveData<Uri>()
    val imageUriLiveData: LiveData<Uri>
        get() = imageUri

    fun setImageUri(uri: Uri) {
        imageUri.value = uri
    }

    @AssistedFactory
    interface Factory {
        fun create(): EditAvatarViewModel
    }
}