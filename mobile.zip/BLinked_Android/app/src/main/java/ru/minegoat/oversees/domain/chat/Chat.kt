package ru.minegoat.oversees.domain.chat

import ru.minegoat.oversees.data.db.chat.ChatRoom
import ru.minegoat.oversees.data.network.chat.model.ChatResponse

data class Chat(
    val objID: String,
    val name: String,
    val ownerId: String,
    val membersIds: List<String>,
    val linkedObj: IChatLinkedObj,
    val messagesIds: List<String> = listOf(),
    val iconUrl: String? = null
)

fun Chat.toRoom(): ChatRoom {
    return ChatRoom(
        objID = objID,
        name = name,
        linkedObj = linkedObj.toRoom(),
        ownerId = ownerId,
        membersIds = messagesIds,
        messagesIds = messagesIds,
        iconUrl = iconUrl
    )
}

fun Chat.toNetwork(): ChatResponse {
    return ChatResponse(
        objID = objID,
        name = name,
        ownerId = ownerId,
        messagesIds = messagesIds,
        membersIds = membersIds,
        linkedObj = linkedObj.toNetwork(),
        iconUrl = iconUrl
    )
}