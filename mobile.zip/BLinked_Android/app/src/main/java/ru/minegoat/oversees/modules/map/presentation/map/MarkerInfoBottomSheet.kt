package ru.minegoat.oversees.modules.map.presentation.map

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.BottomSheetMarkerInfoBinding
import ru.minegoat.oversees.modules.map.di.MapComponentHolder
import ru.minegoat.oversees.base.utils.extensions.copyToClipboard
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel

class MarkerInfoBottomSheet : BottomSheetDialogFragment(R.layout.bottom_sheet_marker_info) {

    private val component by featureComponent(MapComponentHolder)

    private val viewModel by lazyViewModel {
        component.locationViewModel().create()
    }

    private val args: MarkerInfoBottomSheetArgs by navArgs()
    private val locationID by lazy { args.locationID }

    private val binding by viewBinding(BottomSheetMarkerInfoBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.getLocationById(locationID).observe(viewLifecycleOwner) { state ->
            state.on(
                loading = {
                    //todo show load
                },
                success = {
                    binding.location = it
                },
                error = {
                    Log.d(TAG, "onGetLocationById: ${it.message}")
                }
            )
        }

        with(binding) {
            tvLocationLatLng.setOnClickListener {
                copyLatLngToClipboard(this)
            }

            ivCopyLatLng.setOnClickListener {
                copyLatLngToClipboard(this)
            }

            ibOpenFullDetails.setOnClickListener {
                location?.latLng?.let {
                    findNavController().navigate(
                        MarkerInfoBottomSheetDirections.actionMarkerInfoBottomSheetToChooseMapFragment(
                            it
                        )
                    )
                }
            }
        }
    }

    private fun copyLatLngToClipboard(binding: BottomSheetMarkerInfoBinding) {
        requireContext().copyToClipboard(binding.tvLocationLatLng.text)
        Toast.makeText(requireContext(), R.string.copied_to_clipboard, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        private const val TAG = "MarkerInfoBottomSheet"
    }
}