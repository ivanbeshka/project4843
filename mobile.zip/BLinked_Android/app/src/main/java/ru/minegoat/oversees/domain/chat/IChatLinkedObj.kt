package ru.minegoat.oversees.domain.chat

import ru.minegoat.oversees.data.db.chat.ChatLinkedObjRoom
import ru.minegoat.oversees.data.network.chat.model.ChatLinkedObjResponse

//todo edit for not only chat
interface IChatLinkedObj {
    fun getId(): String
    fun getType(): ChatLinkedObjType
    fun getChatName(): String
}

enum class ChatLinkedObjType {
    TRIP,
    SERVICE
}

fun IChatLinkedObj.toRoom(): ChatLinkedObjRoom {
    return ChatLinkedObjRoom(
        linkedObjId = getId(),
        type = getType()
    )
}

fun IChatLinkedObj.toNetwork(): ChatLinkedObjResponse {
    return ChatLinkedObjResponse(
        linkedObjId = getId(),
        type = getType().name
    )
}