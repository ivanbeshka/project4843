package ru.minegoat.oversees.modules.chat.network

import io.reactivex.Single
import ru.minegoat.oversees.modules.chat.network.responses.ChatItemResponse

interface ChatListItemsApi {
    fun getChatListItems(): Single<List<ChatItemResponse>>
}