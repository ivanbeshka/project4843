package ru.minegoat.oversees.base.utils.rx

import io.reactivex.Completable
import io.realm.kotlin.MutableRealm
import io.realm.kotlin.Realm

fun createCompletableWithBodyForRealm(realm: Realm, body: (MutableRealm) -> Unit): Completable {
    return Completable.create { emitter ->
        realm.writeBlocking {
            try {
                body(this)
                emitter.onComplete()
            } catch (e: Exception) {
                emitter.onError(e)
            }
        }
    }
}