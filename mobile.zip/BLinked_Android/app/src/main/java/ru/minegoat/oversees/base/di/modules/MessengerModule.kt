package ru.minegoat.oversees.base.di.modules

import dagger.Module
import dagger.Provides
import ru.minegoat.oversees.data.network.chat.ChatManageApi
import ru.minegoat.oversees.data.network.chat.ChatManageApiImpl
import javax.inject.Singleton

@Module
class MessengerModule {

    @Singleton
    @Provides
    fun provideChatManageApi(): ChatManageApi {
        return ChatManageApiImpl()
    }
}