package ru.minegoat.oversees.modules.master_profile.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.AutoCompleteTextView
import android.widget.EditText
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.flexbox.FlexboxLayout
import com.google.android.material.chip.Chip
import io.realm.kotlin.types.ObjectId
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.base.utils.ui.fragment.showToast
import ru.minegoat.oversees.databinding.FragmentCreateSkillBinding
import ru.minegoat.oversees.domain.user.Skill
import ru.minegoat.oversees.modules.user_profile.di.UserProfileComponentHolder

class CreateSkillFragment : Fragment(R.layout.fragment_create_skill) {

    private val component by featureComponent(UserProfileComponentHolder)

    private val createSkillViewModel by lazyViewModel {
        component.createSkillViewModel().create()
    }

    private val binding by viewBinding(FragmentCreateSkillBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        with(binding) {


            createSkillViewModel.newSkillLiveData.observe(viewLifecycleOwner) { skill ->
                skill.name?.let {
                    etSkillNameLayout.text = Editable.Factory.getInstance().newEditable(it)
                }

                skill.skillDescription?.let {
                    etSkillDescriptionLayout.text = Editable.Factory.getInstance().newEditable(it)
                }
            }

            createSkillViewModel.tagsLiveData.observe(viewLifecycleOwner) { tags ->
                Log.d("TAGS", "tagsLiveData.observe: $tags")
                addChips(tags)
                if (tags.isNotEmpty()) {
                    btnCreateSkill.isVisible =
                        etSkillNameLayout.text.isNotEmpty() && etSkillDescriptionLayout.text.isNotEmpty()
                    binding.tagsAutoCompleteTextView.hint = ""
                } else {
                    btnCreateSkill.isVisible = false
                    binding.tagsAutoCompleteTextView.hint =
                        resources.getString(R.string.enter_keyword)
                }
            }

            arguments?.getString(SKILL_NAME_BUNDLE_KEY)?.let {
                binding.etSkillNameLayout.setText(it.trim())
                createSkillViewModel.setNewSkill(
                    Skill(
                        objId = ObjectId.create().toString(),
                        name = it.trim()
                    )
                )
            }

            setOnToolbarClickListeners()
            addNewTagByEnterClick()
            setOnCreateSkillClickListener()
            setOnSaveNameListeners()
            setOnSaveDescriptionListeners()
            checkEditTextFilling(etSkillNameLayout)
            checkEditTextFilling(etSkillDescriptionLayout)
            setOnChangeFocusListeners()
        }
    }

    private fun saveSkill() {
        createSkillViewModel.newSkillLiveData.value?.let {
            createSkillViewModel.saveNewSkill()
        }
    }

    private fun setOnCreateSkillClickListener() {
        with(binding) {
            btnCreateSkill.setOnClickListener {
                saveSkill()
                findNavController().navigate(
                    R.id.action_createSkillFragment_to_addSkillExperienceFragment, bundleOf(
                        SKILL_ID_BUNDLE_KEY to createSkillViewModel.newSkillLiveData.value?.objId
                    )
                )
            }
        }
    }

    private fun setOnToolbarClickListeners() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun checkEditTextFilling(et: EditText) {
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                with(binding) {
                    createSkillViewModel.tagsLiveData.value?.let {
                        btnCreateSkill.isVisible =
                            etSkillNameLayout.text.isNotEmpty() && etSkillDescriptionLayout.text.isNotEmpty() && it.isNotEmpty()
                    }
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }
        })
    }

    private fun addNewTagByEnterClick() {
        with(binding) {
            tagsAutoCompleteTextView.setOnAddTagListener { name ->
                createSkillViewModel.addNewTag("#$name")
                createSkillViewModel.tagsLiveData.value?.let { setOnSaveTagsListeners(it) }
                tagsAutoCompleteTextView.text = null
            }
        }
    }

    private fun AutoCompleteTextView.setOnAddTagListener(callback: (name: String) -> Unit) {
        setOnItemClickListener { adapterView, _, position, _ ->
            val name = adapterView.getItemAtPosition(position) as String
            callback(name)
        }
        // ok pressed
        setOnEditorActionListener { textView, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                val name = textView.text.toString()
                callback(name)
                true
            } else false
        }
        doAfterTextChanged { text ->
            if (text != null && text.isEmpty()) {
                return@doAfterTextChanged
            }
        }
    }

    private fun addChips(tags: List<String>) {
        binding.tagsChipGroup.clearChips()
        for (tag in tags) {
            binding.tagsChipGroup.addChip(tag) {}
        }
    }

    private fun FlexboxLayout.clearChips() {
        val chipViews = (0 until childCount).mapNotNull { index ->
            val view = getChildAt(index)
            if (view is Chip) view else null
        }
        chipViews.forEach { removeView(it) }
    }

    @SuppressLint("InflateParams")
    private fun ViewGroup.addChip(text: String, removeCallback: (message: String) -> Unit) {
        val inflater = LayoutInflater.from(context)
        val chip = inflater.inflate(R.layout.item_tag_chip, null) as Chip
        chip.text = text
        chip.isCloseIconVisible = true
        chip.isClickable = true
        chip.isCheckable = false

        val layoutParams = ViewGroup.MarginLayoutParams(
            ViewGroup.MarginLayoutParams.WRAP_CONTENT,
            ViewGroup.MarginLayoutParams.WRAP_CONTENT
        )
        layoutParams.rightMargin =
            (resources.getDimensionPixelSize(R.dimen.fragment_create_skill_chip_margin))
        addView(chip as View, childCount - 1, layoutParams)

        chip.setOnCloseIconClickListener {
            removeView(chip as View)
            removeCallback(chip.text.toString())
            createSkillViewModel.removeTag(chip.text.toString())
            createSkillViewModel.tagsLiveData.value?.let { tags -> setOnSaveTagsListeners(tags) }
        }
    }

    private fun setOnSaveNameListeners() {
        binding.etSkillNameLayout.setOnFocusChangeListener { view, hasFocus ->
            val et = view as EditText
            if (!hasFocus) {
                if (!et.text.isNullOrBlank()) {
                    createSkillViewModel.setNewSkillData(name = et.text.toString().trim())
                } else {
                    showToast(R.string.user_name_not_be_empty)
                }
            }
        }
    }

    private fun setOnSaveDescriptionListeners() {
        binding.etSkillDescriptionLayout.setOnFocusChangeListener { view, hasFocus ->
            val et = view as EditText
            if (!hasFocus) {
                if (!et.text.isNullOrBlank()) {
                    createSkillViewModel.setNewSkillData(description = et.text.toString().trim())
                }
            }
        }
    }

    private fun setOnSaveTagsListeners(tags: MutableList<String>) {
        createSkillViewModel.setNewSkillData(skillTags = tags)
    }

    private fun setOnChangeFocusListeners() {
        with(binding) {
            tagsAutoCompleteTextView.setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    tagsChipGroup.setBackgroundResource(R.drawable.shape_focus_edit_text_profile)
                } else {
                    tagsChipGroup.setBackgroundResource(R.drawable.shape_edit_text_profile)
                }
            }
        }
    }

    companion object {
        const val SKILL_NAME_BUNDLE_KEY = "skill_name_bundle"
        const val SKILL_ID_BUNDLE_KEY = "skill_name_bundle"
    }
}