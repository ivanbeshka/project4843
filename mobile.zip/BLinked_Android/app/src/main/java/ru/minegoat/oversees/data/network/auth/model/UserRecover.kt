package ru.minegoat.oversees.data.network.auth.model

import com.google.gson.annotations.SerializedName

data class UserRecover(
    @SerializedName("username")
    val username: String,
    @SerializedName("password")
    val password: String,
    @SerializedName("token")
    val apiToken: String,
    @SerializedName("error")
    val error: String?
)