package ru.minegoat.oversees.modules.user_profile.presentation

import android.content.ContentResolver
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResult
import androidx.fragment.app.setFragmentResultListener
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.BuildConfig
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.image.TakePictureWithUriReturnContract
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.base.utils.ui.loadImageFromOurApi
import ru.minegoat.oversees.base.utils.ui.loadImageFromUri
import ru.minegoat.oversees.databinding.FragmentEditUserAvatarBinding
import ru.minegoat.oversees.modules.user_profile.di.UserProfileComponentHolder
import ru.minegoat.oversees.modules.user_profile.presentation.ChooseEditPhotoAction.EditPhotoAction
import java.io.File

class EditUserAvatarFragment : Fragment(R.layout.fragment_edit_user_avatar) {

    private val component by featureComponent(UserProfileComponentHolder)
    private val viewModel by lazyViewModel {
        component.editAvatarViewModel().create()
    }

    private val binding by viewBinding(FragmentEditUserAvatarBinding::bind)

    private val args: EditUserAvatarFragmentArgs by navArgs()
    private val avaUrl by lazy { args.avaUrl }
    private val avaUri by lazy { args.avaUri }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.ivBack.setOnClickListener {
            findNavController().navigateUp()
        }

        if (avaUrl == null && avaUri == null) {
            binding.editUserAvatarImage.setImageResource(R.drawable.ic_ava_default)
        } else if (avaUri != null) {
            viewModel.setImageUri(avaUri!!)
        } else {
            loadImageFromOurApi(binding.editUserAvatarImage, avaUrl!!)
        }

        viewModel.imageUriLiveData.observe(viewLifecycleOwner) { uri ->
            Log.d("", "imageUri: $uri")
            loadImageFromUri(binding.editUserAvatarImage, uri)

            setFragmentResult(
                REQUEST_EDIT_IMAGE_KEY,
                bundleOf(
                    IMAGE_URI_BUNDLE_KEY to uri.toString(),
                )
            )
        }

        val picChooserContract =
            registerForActivityResult(ActivityResultContracts.GetContent()) { imageUri ->
                imageUri?.let {
                    viewModel.setImageUri(it)
                }
            }

        val takePictureContract =
            registerForActivityResult(TakePictureWithUriReturnContract()) { (success, imageUri) ->
                if (success) {
                    imageUri.let {
                        viewModel.setImageUri(it)
                    }
                }
            }

        binding.editUserAvatarFab.setOnClickListener {
            findNavController().navigate(R.id.action_editUserAvatarFragment_to_chooseEditPhotoAction)
        }

        setFragmentResultListener(ChooseEditPhotoAction.REQUEST_EDIT_PHOTO_ACTION_KEY) {_, bundle ->
            val action = bundle.getInt(ChooseEditPhotoAction.EDIT_PHOTO_ACTION_BUNDLE_KEY)
            when(EditPhotoAction.values()[action]) {
                EditPhotoAction.CHOOSE -> {
                    picChooserContract.launch(IMAGE)
                }
                EditPhotoAction.TAKE -> {
                    takePictureContract.launch(getTmpFileUri())
                }
                EditPhotoAction.DELETE -> {
                    deleteUserAva()
                }
            }
        }
    }

    private fun deleteUserAva() {
        val imageUri = Uri.Builder()
            .scheme(ContentResolver.SCHEME_ANDROID_RESOURCE)
            .authority(resources.getResourcePackageName(R.drawable.ic_ava_default))
            .appendPath(resources.getResourceTypeName(R.drawable.ic_ava_default))
            .appendPath(resources.getResourceEntryName(R.drawable.ic_ava_default))
            .build()

        viewModel.setImageUri(imageUri)
    }

    private fun getTmpFileUri(): Uri {
        val tmpFile =
            File.createTempFile(TEMP_FILE_NAME_PREFIX, PNG, requireContext().cacheDir).apply {
                createNewFile()
                deleteOnExit()
            }

        return FileProvider.getUriForFile(
            requireContext(),
            "${BuildConfig.APPLICATION_ID}$PROVIDER",
            tmpFile
        )
    }

    companion object {
        const val IMAGE_URI_BUNDLE_KEY = "image_uri_key"
        const val REQUEST_EDIT_IMAGE_KEY = "request_edit_image_key"

        private const val IMAGE = "image/*"
        const val PNG = ".png"
        const val TEMP_FILE_NAME_PREFIX = "tmp_image_file"
        const val PROVIDER = ".provider"
    }
}
