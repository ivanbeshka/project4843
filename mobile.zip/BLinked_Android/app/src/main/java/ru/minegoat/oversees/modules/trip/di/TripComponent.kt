package ru.minegoat.oversees.modules.trip.di

import dagger.Component
import ru.minegoat.oversees.modules.trip.viewmodels.TripViewModel
import ru.minegoat.oversees.base.di.AppComponent
import ru.minegoat.oversees.base.di.components.DiComponent

@TripScope
@Component(dependencies = [AppComponent::class], modules = [TripModule::class])
interface TripComponent : DiComponent {

    fun tripViewModel(): TripViewModel.Factory
}