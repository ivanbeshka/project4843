package ru.minegoat.oversees.modules.user_profile.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResult
import androidx.fragment.app.setFragmentResultListener
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.firebase.FirebaseException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.base.utils.ui.fragment.showToast
import ru.minegoat.oversees.base.utils.ui.view.setCountryCode
import ru.minegoat.oversees.base.utils.ui.view.toNormalizedPhone
import ru.minegoat.oversees.databinding.FragmentCheckPhoneNumBinding
import ru.minegoat.oversees.domain.auth.Phone
import ru.minegoat.oversees.domain.auth.split
import ru.minegoat.oversees.domain.auth.toNormalize
import ru.minegoat.oversees.domain.user.CountryFlags
import ru.minegoat.oversees.domain.user.CountryPhone
import ru.minegoat.oversees.modules.user_profile.di.UserProfileComponentHolder
import java.util.concurrent.TimeUnit

// тестовый номер +7 999 555 55 55
// код 123456

class CheckPhoneNumFragment : Fragment(R.layout.fragment_check_phone_num) {

    private val component by featureComponent(UserProfileComponentHolder)

    private val viewModel by lazyViewModel {
        component.checkPhoneNumViewModel().create()
    }
    private val binding by viewBinding(FragmentCheckPhoneNumBinding::bind)

    private val args: CheckPhoneNumFragmentArgs by navArgs()
    private val isRecoverAcc by lazy { args.isRecoverAcc }

    private val auth by lazy {
        Firebase.auth.apply {
            useAppLanguage()
        }
    }

//    private var timer: CountDownTimer? = null

    private val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

        override fun onVerificationCompleted(credential: PhoneAuthCredential) {
            Log.d("VVVVV", "callbacks onVerificationCompleted: ${credential.toString()}")
            acceptPhone()
        }

        override fun onVerificationFailed(e: FirebaseException) {
            Log.d("VVVVV", "callbacks onVerificationFailed: ${e.message.toString()}")
            changeEditPhoneState(false)
            showToast(R.string.firebase_went_wrong)
            e.printStackTrace()
        }

        override fun onCodeSent(
            verificationId: String,
            token: PhoneAuthProvider.ForceResendingToken
        ) {
            Log.d("VVVVV", "callbacks onCodeSent: $verificationId")
            changeEditPhoneState(true)
            viewModel.verificationId = verificationId
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setFragmentResultListener(BottomSheetCheckPhoneNum.REQUEST_ACTION_KEY) { _, bundle ->
            val countryName = bundle.getString(BottomSheetCheckPhoneNum.ACTION_COUNTRY_NAME_KEY)
            val countryPhone = bundle.getString(BottomSheetCheckPhoneNum.ACTION_COUNTRY_PHONE_KEY)
            val countryCodeName = bundle.getString(BottomSheetCheckPhoneNum.ACTION_COUNTRY_CODE_KEY)
            countryName?.let { name ->
                countryPhone?.let { phone ->
                    countryCodeName?.let { code ->
                        viewModel.setCountryPhone(
                            CountryPhone(
                                name,
                                phone,
                                CountryFlags.valueOf(code)
                            )
                        )
                    }
                }
            }
        }
    }

    @SuppressLint("ResourceAsColor")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (isRecoverAcc) {
            binding.ivMinegoat.visibility = View.VISIBLE
            binding.btnConfirm.text = getString(R.string.recover)
            binding.tvSendCode.text = getString(R.string.send_code_again)

        }

        subscribeOnPhoneIsExisted()
        setPhoneNumIntroducedListener()
        setOnCodeIntroducedListener()

        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
            viewModel.timerCancel()
        }

        binding.tvSendCode.setOnClickListener {
            startTimer()
        }

        binding.etInputPhoneNum.apply {
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                    //TODO("Not yet implemented")
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    //TODO("Not yet implemented")
                }

                override fun afterTextChanged(s: Editable?) {
                    val text: String = this@apply.text.toString()
                    val textLength: Int = this@apply.text.toString().length
                    if (text.endsWith("-") || text.endsWith(" ") || text.endsWith(" ")) return
                    if (textLength == 1) {
                        if (!text.contains("(")) {
                            this@apply.setText(StringBuilder(text).insert(text.length - 1, "(").toString())
                            this@apply.setSelection(this@apply.text.toString().length)
                        }
                    } else if (textLength == 5) {
                        if (!text.contains(")")) {
                            this@apply.setText(StringBuilder(text).insert(text.length - 1, ")").toString())
                            this@apply.setSelection(this@apply.text.toString().length)
                        }
                    } else if (textLength == 6) {
                        this@apply.setText(StringBuilder(text).insert(text.length - 1, " ").toString())
                        this@apply.setSelection(this@apply.text.toString().length)
                    } else if (textLength == 10) {
                        if (!text.contains("-")) {
                            this@apply.setText(StringBuilder(text).insert(text.length - 1, "-").toString())
                            this@apply.setSelection(this@apply.text.toString().length)
                        }
                    } else if (textLength == 15) {
                        if (text.contains("-")) {
                            this@apply.setText(StringBuilder(text).insert(text.length - 1, "-").toString())
                            this@apply.setSelection(this@apply.text.toString().length)
                        }
                    } else if (textLength == 18) {
                        if (text.contains("-")) {
                            this@apply.setText(StringBuilder(text).insert(text.length - 1, "-").toString())
                            this@apply.setSelection(this@apply.text.toString().length)
                        }
                    }
                }
            })

            setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    binding.etInputPhoneNum.setBackgroundResource(R.drawable.shape_focus_phone_number)
                    binding.tvPhoneCountryCode.setBackgroundResource(R.drawable.shape_focus_country_code)
                } else {
                    binding.etInputPhoneNum.setBackgroundResource(R.drawable.shape_phone_number)
                    binding.tvPhoneCountryCode.setBackgroundResource(R.drawable.shape_country_code)
                }
            }
        }

        binding.tvPhoneCountryCode.apply {
            setCountryCode(this, CountryPhone.fromPhone(viewModel.phone))
            setOnClickListener {
                findNavController().navigate(R.id.action_checkPhoneNumFragment_to_bottomSheetCheckPhoneNum)
            }
        }

        binding.tvPhoneCountryCode.apply {
            setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    binding.etInputPhoneNum.setBackgroundResource(R.drawable.shape_focus_phone_number)
                    binding.tvPhoneCountryCode.setBackgroundResource(R.drawable.shape_focus_country_code)
                    //        findNavController().navigate(
                    //          (R.id.action_checkPhoneNumFragment_to_countryCodeFragment)
                    //    )
                } else {
                    binding.etInputPhoneNum.setBackgroundResource(R.drawable.shape_phone_number)
                    binding.tvPhoneCountryCode.setBackgroundResource(R.drawable.shape_country_code)
                }
            }
        }

        binding.etInputCode.addTextChangedListener {
            val text = it?.toString() ?: return@addTextChangedListener
            if (text.length >= 3) {
                binding.btnConfirm.setBackgroundResource(R.drawable.ripple_with_shape_8dp_primary_100)
                binding.btnConfirm.setTextColor(resources.getColor(R.color.white))
                binding.btnConfirm.isClickable = true
            } else {
                binding.btnConfirm.setBackgroundResource(R.drawable.ripple_non_clickable_button)
                binding.btnConfirm.setTextColor(R.color.gray_60)
                binding.btnConfirm.isClickable = false
            }
        }

//        binding.etInputCode.setOnFocusChangeListener { _, hasFocus ->
//            if (hasFocus) {
//                binding.etInputCode.height = R.dimen.code_field
//                binding.tilInputCode.minimumHeight = R.dimen.code_field
//            } else {
//                binding.etInputCode.height = R.dimen.button_height
//                binding.tilInputCode.minimumHeight = R.dimen.button_height
//            }
//        }
        setTilPhoneCountryCode(CountryPhone("", "+7", CountryFlags.RU))
        viewModel.isCountryPhoneSet.observe(viewLifecycleOwner)
        { countryPhone ->
            setTilPhoneCountryCode(countryPhone)
        }
    }

    private fun setTilPhoneCountryCode(countryPhone: CountryPhone) =
        setCountryCode(binding.tvPhoneCountryCode, countryPhone)

    private fun subscribeOnPhoneIsExisted() {
        viewModel.getIsPhoneExisted().observe(viewLifecycleOwner) { state ->
            state.on(
                loading = {
                    showLoading()
                },
                success = { (isExisted, phone) ->
                    Log.d("VVVVV", "getIsPhoneExisted: isExisted=$isExisted phone=$phone")
                    if (!isExisted || (isRecoverAcc && isExisted)) {
                        val options = PhoneAuthOptions.newBuilder(auth)
                            .setPhoneNumber("+${phone.toNormalize()}") // Phone number to verify
                            .setTimeout(SMS_TIMEOUT, TimeUnit.SECONDS)
                            .setActivity(requireActivity())
                            .setCallbacks(callbacks)
                            .build()

                        PhoneAuthProvider.verifyPhoneNumber(options)

                        changeEditPhoneState(true)
                    } else {
                        changeEditPhoneState(false)
                        if (isRecoverAcc) {
                            showToast(R.string.not_found_account_with_this_phone)
                        } else {
                            showToast(R.string.phone_already_existed)
                        }
                    }
//                    binding.progressBar.isVisible = false
                },
                error = {
                    Log.e("error", "$it")
                    changeEditPhoneState(false)
                    showToast(R.string.oops_something_went_wrong)
                }
            )
        }
    }

    private fun changeEditPhoneState(isCodeSent: Boolean) {
        binding.btnNext.visibility = if (!isCodeSent) View.VISIBLE else View.GONE
//        setEtIsEditable(!isCodeSent, binding.etCountryCode)
        setEtIsEditable(!isCodeSent, binding.etInputPhoneNum)
        binding.tilInputCode.visibility = if (isCodeSent) View.VISIBLE else View.GONE
        binding.btnConfirm.visibility = if (isCodeSent) View.VISIBLE else View.GONE
        binding.containerSendCode.visibility = if (isCodeSent) View.VISIBLE else View.GONE
    }

    private fun setPhoneNumIntroducedListener() {

        binding.btnNext.setOnClickListener {
            checkPhoneIsExisted()
            startTimer()
        }
    }

    private fun checkPhoneIsExisted() {
        val phoneNumber = binding.etInputPhoneNum.text?.toString()

        if (!phoneNumber.isNullOrBlank()) {
            val phone = viewModel.phone
            viewModel.phone = Phone(phone.countryCode, phone.phonePrefix, phoneNumber.toNormalizedPhone())
            viewModel.checkIsPhoneExisted(viewModel.phone)

        } else {
            showToast(R.string.check_phone_number)
        }
    }

    private fun setOnCodeIntroducedListener() {
//        binding.etInputCode.setOnEditorActionListener { _, actionId, _ ->
//            if (actionId == EditorInfo.IME_ACTION_DONE) {
//                return@setOnEditorActionListener true
//            }
//            false
//        }

        binding.btnConfirm.setOnClickListener {
            if (binding.etInputCode.text != null && binding.etInputCode.text.toString().isNotEmpty()
            ) {
                Log.d("VVVVV", "btnConfirmClick")
                val credential = PhoneAuthProvider.getCredential(
                    viewModel.verificationId,
                    binding.etInputCode.text.toString().toNormalizedPhone()
                )
                signInWithPhoneAuthCredential(credential)
            } else
                Toast.makeText(
                    requireContext(),
                    getString(R.string.empty_auth_code),
                    Toast.LENGTH_SHORT
                ).show()


        }
    }

    private fun signInWithPhoneAuthCredential(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential)
            .addOnCompleteListener(requireActivity()) { task ->
                Log.d("VVVVV", "signInWithCredential: task=${task.toString()}")
                if (task.isSuccessful) {
                    acceptPhone()
                } else {
                    Toast.makeText(
                        requireContext(),
                        getString(R.string.wrong_auth_code),
                        Toast.LENGTH_SHORT
                    ).show()
                    changeEditPhoneState(false)
                }
            }
    }

    private fun acceptPhone() {
        val phone = viewModel.phone
        if (phone.phone.isNotEmpty()) {
            val normalizedPhone = Phone(
                countryCode =  phone.countryCode,
                phonePrefix = phone.phonePrefix,
                phone = phone.phone.toNormalizedPhone()
            )
            viewModel.timerCancel()
            if (!isRecoverAcc) {
                setFragmentResult(
                    PHONE_REQUEST_KEY,
                    bundleOf(PHONE_BUNDLE to normalizedPhone.split())
                )
                findNavController().navigateUp()
            } else {
                viewModel.clearOldUserData()
                viewModel.getIsRecoverUser().observe(viewLifecycleOwner) { state ->
                    state.on(
                        success = {
                            showToast(R.string.acc_recovered)
                            findNavController().navigate(R.id.action_checkPhoneNumFragment_to_userProfileFragment)
                        }
                    )
                }
                viewModel.getIsDataCleared().observe(viewLifecycleOwner) { state ->
                    state.on(
                        success = {
                            viewModel.recoverUser(phone)
                        }
                    )
                }
            }
        } else {
            showToast(R.string.wrong_auth_code)
        }
    }

    private fun showLoading() {
        binding.btnNext.visibility = View.GONE
//        setEtIsEditable(false, binding.etCountryCode)
        setEtIsEditable(false, binding.etInputPhoneNum)
//        binding.progressBar.isVisible = true
    }

    private fun setEtIsEditable(isEditable: Boolean, et: EditText) {
        if (isEditable) {
            et.isCursorVisible = true
            et.isFocusableInTouchMode = true
            et.isFocusable = true
        } else {
            et.isCursorVisible = false
            et.isFocusable = false
        }
    }

    private fun startTimer() {
        viewModel.timerStart()
        binding.tvTimer.visibility = View.VISIBLE
        viewModel.timerTick.observe(viewLifecycleOwner) {
            if (it >= 0) {
                val secondsTotal = it
                val minutes: Long = secondsTotal / 60
                val seconds: Long = secondsTotal - minutes * 60
                binding.tvTimer.text = String.format("(%d:%02d)", minutes, seconds)
            } else {
                binding.apply {
                    tvSendCode.setTextColor(ContextCompat.getColor(requireContext(), R.color.primary_100))
                    tvSendCode.isClickable = true
                    tvTimer.visibility = View.GONE
                }
            }
        }
    }

    companion object {
        const val PHONE_REQUEST_KEY = "phone_request"
        const val PHONE_BUNDLE = "phone_bundle"
        private const val SMS_TIMEOUT = 60L
    }
}