package ru.minegoat.oversees.base.di.modules

import dagger.Module
import dagger.Provides
import retrofit2.Retrofit
import ru.minegoat.oversees.base.helpers.syncer.Syncer
import ru.minegoat.oversees.data.network.syncer.SyncerApi
import ru.minegoat.oversees.data.network.syncer.SyncerNetwork
import ru.minegoat.oversees.data.repository.syncer.SyncerRepository
import ru.minegoat.oversees.data.sharedpref.SyncerSharedPref
import javax.inject.Singleton

@Module
class SyncerModule {

    @Singleton
    @Provides
    fun provideSyncerApi(retrofit: Retrofit): SyncerApi =
        retrofit.create(SyncerApi::class.java)

    @Singleton
    @Provides
    fun provideSyncer(
        pref: SyncerSharedPref,
        network: SyncerNetwork,
        repo: SyncerRepository
    ): Syncer =
        Syncer(pref, network, repo)
}