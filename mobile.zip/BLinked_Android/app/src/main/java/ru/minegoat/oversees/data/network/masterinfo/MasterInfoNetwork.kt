package ru.minegoat.oversees.data.network.masterinfo

import android.util.Log
import com.google.gson.annotations.SerializedName
import io.realm.kotlin.ext.toRealmList
import ru.minegoat.oversees.data.db.master.MasterInfoRealm

data class MasterInfoNetwork(
    @SerializedName("syncStatusDateTime")
    val syncStatusTimeSec: Long,
    @SerializedName("objID")
    val objID: String,
    @SerializedName("masterTypes")
    val masterTypes: List<String>,
    @SerializedName("path")
    val path: String? = null,
    @SerializedName("masterId")
    val masterId: String
)

fun MasterInfoNetwork.toMasterInfoRealm() =
    MasterInfoRealm(
        objID = objID,
        masterTypesIds = masterTypes.toRealmList(),
        path = path ?: "",
        masterId=masterId
    ).apply {
        Log.d("VVVVV", "MasterInfoNetwork.toMasterInfoRealm = $this")
    }
