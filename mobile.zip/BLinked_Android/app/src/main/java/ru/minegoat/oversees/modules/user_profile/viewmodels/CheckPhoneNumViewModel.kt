package ru.minegoat.oversees.modules.user_profile.viewmodels

import android.os.CountDownTimer
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.base.helpers.auth.Authenticator
import ru.minegoat.oversees.base.viewmodels.*
import ru.minegoat.oversees.domain.auth.Phone
import ru.minegoat.oversees.domain.user.CountryPhone
import ru.minegoat.oversees.modules.user_profile.repository.AccDataRepository

class CheckPhoneNumViewModel @AssistedInject constructor(
    private val authenticator: Authenticator,
    private val accDataRepository: AccDataRepository
) : RxViewModel() {

    var verificationId: String = ""
    var phone: Phone = Phone("RU", "+7", "")

    private val isPhoneExisted = MutableLiveData<ScreenState<Pair<Boolean, Phone>>>()

    private val isRecoverUser = MutableLiveData<ScreenState<Boolean>>()

    private val isDataCleared = MutableLiveData<ScreenState<Boolean>>()

    private val _isCountryPhoneSet = MutableLiveData<CountryPhone>()
    val isCountryPhoneSet: LiveData<CountryPhone> = _isCountryPhoneSet

    private val _timerTick = MutableLiveData<Long>()
    val timerTick: LiveData<Long> get() = _timerTick
    var timerIsActive = false

    private val timer = object : CountDownTimer(90000, 1000) {
        override fun onTick(millisUntilFinished: Long) {
            timerIsActive = true
            _timerTick.postValue(millisUntilFinished / 1000)
        }

        override fun onFinish() {
            timerIsActive = false
            _timerTick.postValue(-1L)
        }
    }

    fun timerStart() {
        timer.cancel()
        timer.start()
    }

    fun timerCancel() {
        if (timerIsActive) {
            timer.cancel()
            timerIsActive = false
        }
    }

    fun getIsRecoverUser(): LiveData<ScreenState<Boolean>> =
        isRecoverUser

    fun recoverUser(phone: Phone) {
        authenticator.recoverUser(phone)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { isRecoverUser.value = LoadingScreenState() }
            .subscribeBy(
                onComplete = {
                    isRecoverUser.value = SuccessScreenState(true)
                },
                onError = {
                    isRecoverUser.value = ErrorScreenState(it)
                    it.printStackTrace()
                }
            )
            .disposeOnFinish()
    }

    fun setCountryPhone(countryPhone: CountryPhone) {
        _isCountryPhoneSet.postValue(countryPhone)
    }

    fun getIsDataCleared(): LiveData<ScreenState<Boolean>> =
        isDataCleared

    fun clearOldUserData() {
        accDataRepository.clearAllDataFromDB()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { isDataCleared.value = LoadingScreenState() }
            .subscribeBy(
                onComplete = {
                    isDataCleared.value = SuccessScreenState(true)
                },
                onError = {
                    isDataCleared.value = ErrorScreenState(it)
                    it.printStackTrace()
                }
            )
            .disposeOnFinish()
    }

    fun getIsPhoneExisted(): LiveData<ScreenState<Pair<Boolean, Phone>>> {
        return isPhoneExisted
    }

    fun checkIsPhoneExisted(phone: Phone) {
        authenticator.isUserExisted(phone)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { isPhoneExisted.postValue(LoadingScreenState()) }
            .subscribeBy(
                onSuccess = {
                    this.phone = it.second
                    isPhoneExisted.postValue(SuccessScreenState(it))
                },
                onError = {
                    isPhoneExisted.postValue(ErrorScreenState(it))
                }
            )
            .disposeOnFinish()
    }

    @AssistedFactory
    interface Factory {
        fun create(): CheckPhoneNumViewModel
    }
}