package ru.minegoat.oversees.modules.base.di

import  dagger.Module
import dagger.Provides
import retrofit2.Retrofit
import ru.minegoat.oversees.modules.base.network.SendMessageApi
import ru.minegoat.oversees.modules.base.repository.SendMessageRepository

@Module
class ConnectUsModule {

    @ConnectUsScope
    @Provides
    fun provideSendMessageRepository(
        api: SendMessageApi,
    ): SendMessageRepository =
        SendMessageRepository(api)

    @ConnectUsScope
    @Provides
    fun provideSendMessageApi(retrofit: Retrofit): SendMessageApi =
        retrofit.create(SendMessageApi::class.java)

}