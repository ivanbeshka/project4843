package ru.minegoat.oversees.modules.map.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.domain.location.Location
import ru.minegoat.oversees.data.repository.location.LocationRepository
import ru.minegoat.oversees.base.viewmodels.*

class SearchLocationsViewModel @AssistedInject constructor(
    private val repository: LocationRepository
) : RxViewModel() {

    private val locationsLiveData = MutableLiveData<ScreenState<List<Location>>>()

    fun getLocationsWithPredicate(predicate: String, isUsing: Boolean): LiveData<ScreenState<List<Location>>> {
        repository.getLocationsWithPredicate(predicate, isUsing)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { locationsLiveData.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    locationsLiveData.value = SuccessScreenState(it)
                },
                onError = {
                    locationsLiveData.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()

        return locationsLiveData
    }

    @AssistedFactory
    interface Factory {
        fun create(): SearchLocationsViewModel
    }
}