package ru.minegoat.oversees.data.network.user

import io.reactivex.Single
import retrofit2.http.GET
import retrofit2.http.Query
import ru.minegoat.oversees.data.network.user.model.ResponseShortUser
import ru.minegoat.oversees.data.network.user.model.ResponseUserProfile


interface UserApi {
    @GET("user/profile")
    fun getUser(@Query("id") objId: String): Single<ResponseShortUser>

    @GET("users/list")
    fun getUsersList(): Single<ResponseShortUser>

    @GET("user/profile")
    fun getMyUser(): Single<ResponseUserProfile>

    @GET("users/list?masters=true")
    fun getMasters(): Single<ResponseShortUser>
}