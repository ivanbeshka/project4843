package ru.minegoat.oversees.modules.user_profile.presentation

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.databinding.FragmentChooseMasterBinding
import ru.minegoat.oversees.modules.search.di.SearchComponentHolder
import ru.minegoat.oversees.modules.search.presentation.MastersAdapter
import ru.minegoat.oversees.modules.search.presentation.SearchFragmentDirections
import ru.minegoat.oversees.modules.user_profile.model.ShortMasterUi


class ChooseMasterFragment : Fragment(R.layout.fragment_choose_master) {
    private val binding by viewBinding(FragmentChooseMasterBinding::bind)

    private val component by featureComponent(SearchComponentHolder)

    private val viewModel by lazyViewModel {
        component.searchViewModel().create()
    }

    private var masterListAdapter: MasterListAdapter? = null


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        masterListAdapter = MasterListAdapter(
            object : MastersRecyclerClickListener {
                override fun onClick(v: View, position: Int, master: ShortMasterUi) {
                    parentFragmentManager.setFragmentResult(
                        SELECTED_MASTER_KEY, bundleOf(
                            SELECTED_MASTER_NAME to master.name,
                            SELECTED_MASTER_AVATAR to master.avatarUrl
                        )
                    )
                    findNavController().popBackStack()
                }

            }
        )

        binding.rvMasters.apply {
            adapter = masterListAdapter
        }
        binding.includeSearchView.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchMasters(query = s.toString())
            }
        })

    }

    private fun searchMasters(query: String) {
        viewModel.convertToShortUserUI(query).observe(viewLifecycleOwner) { state ->
            state.on(
                success = { shortUserUiList ->
                    val usersUiList = mutableListOf<ShortMasterUi>()
                    shortUserUiList.forEach {
                        usersUiList.add(it)
                    }
                    masterListAdapter?.let { adapter ->
                        adapter.masters = usersUiList.toList()
                    }
                },
                error = {
                    Log.d("Error", "onLoadingMasters ${it.message}")
                }
            )
        }
    }

    override fun onDestroyView() {
        masterListAdapter = null
        super.onDestroyView()
    }


    companion object {
        const val SELECTED_MASTER_NAME = "SELECTED_MASTER_NAME"
        const val SELECTED_MASTER_AVATAR = "SELECTED_MASTER_AVATAR"
        const val SELECTED_MASTER_KEY = "SELECTED_MASTER_REQUEST"
    }
}