package ru.minegoat.oversees.base.exceptions

class UserNotAuthorizedException : AuthException(MESSAGE) {

    private companion object {
        private const val MESSAGE = "User in not authorized"
    }
}