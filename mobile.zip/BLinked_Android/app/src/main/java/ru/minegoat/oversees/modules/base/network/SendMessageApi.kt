package ru.minegoat.oversees.modules.base.network

import io.reactivex.Completable
import retrofit2.http.Body
import retrofit2.http.POST
import ru.minegoat.oversees.modules.base.network.model.SendConnectUs

interface SendMessageApi {
    @POST("epicker")
    fun sendMessage(@Body message: SendConnectUs): Completable
}
