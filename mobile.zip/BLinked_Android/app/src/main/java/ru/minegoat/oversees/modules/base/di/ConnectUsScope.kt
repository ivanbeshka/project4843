package ru.minegoat.oversees.modules.base.di

import javax.inject.Scope

@Scope
annotation class ConnectUsScope
