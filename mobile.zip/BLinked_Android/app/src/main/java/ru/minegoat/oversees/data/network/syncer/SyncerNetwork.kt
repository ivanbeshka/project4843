package ru.minegoat.oversees.data.network.syncer

import android.util.Log
import com.google.gson.Gson
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import org.json.JSONException
import ru.minegoat.oversees.data.network.location.LocationNetwork
import ru.minegoat.oversees.data.network.syncer.model.SyncItemResponse
import ru.minegoat.oversees.data.network.syncer.model.SyncItemObjRequest
import ru.minegoat.oversees.data.network.syncer.model.SyncItemRequest
import ru.minegoat.oversees.data.network.syncer.model.SyncRequest
import ru.minegoat.oversees.base.utils.extensions.milsToSec
import ru.minegoat.oversees.data.network.masterinfo.MasterInfoNetwork
import ru.minegoat.oversees.data.network.mastertype.MasterTypeNetwork
import ru.minegoat.oversees.data.network.skill.responses.ResponseSkillItem
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SyncerNetwork @Inject constructor(private val api: SyncerApi) {

    private val compositeDisposable = CompositeDisposable()
    private val gson = Gson()

    fun sync(currentSession: UUID, lastSync: Date, doWithData: (data: List<Any?>) -> Unit) {
        val syncItemObj = SyncItemObjRequest(
            currentSession.toString().uppercase(),
            lastSync.time.milsToSec()
        )
        val syncItemRequest = SyncItemRequest(SYNCER_TYPE, syncItemObj)
        val syncRequest = SyncRequest(listOf(syncItemRequest))

        val disposable = api.sync(syncRequest)
            .subscribeOn(Schedulers.io())
            .subscribeBy(
                onSuccess = {
                    doWithData(parseSyncResponse(it.items))
                },
                onError = {
                    it.printStackTrace()
                    Log.d(TAG, "sync: ${it.message}")
                }
            )
        compositeDisposable.add(disposable)
    }

    fun clearDisposable() = compositeDisposable.clear()

    private fun parseSyncResponse(items: List<SyncItemResponse>?): List<Any?> {
        try {
            Log.d(TAG, "parseSyncResponse: $items")
            items?.let {

                val typedObjects = mutableListOf<Any?>()
                for (obj in it) {
                    typedObjects.add(parseJsonObject(obj))
                }

                return typedObjects
            }
        } catch (e: JSONException) {
            e.printStackTrace()
            Log.d(TAG, "parseSyncResponse: ${e.message}")
        }
        return emptyList()
    }

    private fun parseJsonObject(item: SyncItemResponse): Any? =
        when (item.type) {
            //TODO add other types
            "Location" -> {
                val locationJson = item.obj
                gson.fromJson(locationJson.toString(), LocationNetwork::class.java)
            }
            "Skill" -> {
                val skillJson = item.obj
                gson.fromJson(skillJson.toString(), ResponseSkillItem::class.java)
            }
            "MasterType" -> {
                val masterTypeJson = item.obj
                gson.fromJson(masterTypeJson.toString(), MasterTypeNetwork::class.java)
            }
            "MasterInfo" -> {
                val masterInfoJson = item.obj
                gson.fromJson(masterInfoJson.toString(), MasterInfoNetwork::class.java)
            }
            else -> null
        }

    private companion object {
        private const val SYNCER_TYPE = "Syncer"

        private const val TAG = "SYNCER_NETWORK"
    }
}