package ru.minegoat.oversees.modules.trip.network.responses

import com.google.gson.annotations.SerializedName

data class ResponseShortTrip(
    @SerializedName("items")
    val items: List<ResponseShortTripItem>
)