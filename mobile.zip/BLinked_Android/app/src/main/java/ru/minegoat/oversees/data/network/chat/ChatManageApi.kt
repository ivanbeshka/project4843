package ru.minegoat.oversees.data.network.chat

import io.reactivex.Completable
import ru.minegoat.oversees.data.network.chat.model.ChatResponse

interface ChatManageApi {
    fun createChat(chatNetwork: ChatResponse): Completable
    fun addToChat(chatId: String, userId: String): Completable
    fun removeFromChat(chatId: String, userId: String): Completable
}