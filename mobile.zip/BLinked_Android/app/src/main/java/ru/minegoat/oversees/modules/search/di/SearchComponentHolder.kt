package ru.minegoat.oversees.modules.search.di

import ru.minegoat.oversees.App
import ru.minegoat.oversees.base.di.holders.FeatureComponentHolder

object SearchComponentHolder : FeatureComponentHolder<SearchComponent>() {
    override fun build(): SearchComponent {
        return DaggerSearchComponent.builder()
            .appComponent(App.component)
            .searchModule(SearchModule())
            .build()
    }
}