package ru.minegoat.oversees.base.utils.extensions

fun Long.milsToSec(): Long =
    this / 1000

fun Long.secToMils(): Long =
    this * 1000
