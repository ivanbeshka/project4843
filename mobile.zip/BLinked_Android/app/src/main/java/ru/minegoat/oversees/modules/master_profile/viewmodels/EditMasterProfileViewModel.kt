package ru.minegoat.oversees.modules.master_profile.viewmodels

import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import ru.minegoat.oversees.base.helpers.syncer.Syncer
import ru.minegoat.oversees.base.viewmodels.RxViewModel
import ru.minegoat.oversees.modules.user_profile.network.UserProfileApi

class EditMasterProfileViewModel @AssistedInject constructor(
    private var userProfileApi: UserProfileApi,
    private val syncer: Syncer
):RxViewModel() {

    init {
        syncer.onResume()
    }
    fun deleteProfile() = userProfileApi.deleteUserProfile()


    @AssistedFactory
    interface Factory {
        fun create(): EditMasterProfileViewModel
    }
}