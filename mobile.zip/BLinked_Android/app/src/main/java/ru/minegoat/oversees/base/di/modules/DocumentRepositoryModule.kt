package ru.minegoat.oversees.base.di.modules

import dagger.Module
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import ru.minegoat.oversees.data.repository.document.DocumentRepository

@Module
class DocumentRepositoryModule {
    fun provideDocumentRepository(ds: RealmDataStorage):DocumentRepository = DocumentRepository(ds)
}