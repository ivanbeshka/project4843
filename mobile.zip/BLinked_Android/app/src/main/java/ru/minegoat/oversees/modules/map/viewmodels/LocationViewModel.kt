package ru.minegoat.oversees.modules.map.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.domain.location.Location
import ru.minegoat.oversees.data.repository.location.LocationRepository
import ru.minegoat.oversees.base.viewmodels.*

class LocationViewModel @AssistedInject constructor(
    private val repository: LocationRepository
) : RxViewModel() {

    private val getUsedLocationLiveData = MutableLiveData<ScreenState<List<Location>>>()
    private val getLocationByIdLiveData = MutableLiveData<ScreenState<Location>>()

    fun getUsedLocations(): LiveData<ScreenState<List<Location>>> {
        repository.getUsedLocations()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { getUsedLocationLiveData.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    getUsedLocationLiveData.value = SuccessScreenState(it)
                },
                onError = {
                    getUsedLocationLiveData.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()

        return getUsedLocationLiveData
    }

    fun getLocationById(objID: String): LiveData<ScreenState<Location>> {
        repository.getLocationById(objID)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { getLocationByIdLiveData.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    getLocationByIdLiveData.value = SuccessScreenState(it)
                },
                onError = {
                    getLocationByIdLiveData.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()

        return getLocationByIdLiveData
    }

    @AssistedFactory
    interface Factory {
        fun create(): LocationViewModel
    }
}