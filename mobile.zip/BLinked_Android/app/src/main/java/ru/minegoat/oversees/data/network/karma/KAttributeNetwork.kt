package ru.minegoat.oversees.data.network.karma

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.karma.KAttribute
import ru.minegoat.oversees.domain.karma.KAttributeType

data class KAttributeNetwork(
    @SerializedName("type")
    val type: String,
    @SerializedName("sum")
    val sum: Int,
)

fun KAttributeNetwork.toKAttribute(): KAttribute {
    val type = when(type.uppercase()) {
        KAttributeTypeNetwork.LIKES.name -> "Лайки"
        KAttributeTypeNetwork.PROFILEFULLNESS.name -> "Заполнен профиль"
        KAttributeTypeNetwork.OTHER.name -> "Другое"
        else -> ""
    }
    val kAttributeType = KAttributeType(
        type,
        ""
    )
    return KAttribute(
        kAttributeType,
        sum
    )
}

enum class KAttributeTypeNetwork {
    LIKES,
    PROFILEFULLNESS,
    OTHER
}




