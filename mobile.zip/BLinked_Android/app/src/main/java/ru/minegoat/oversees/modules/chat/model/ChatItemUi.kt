package ru.minegoat.oversees.modules.chat.model

data class ChatItemUi(
    val chat: ShortChatUi,
    val lastMessage: MessageUi,
    var unreadMessagesCount: Int
)