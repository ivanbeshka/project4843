package ru.minegoat.oversees.modules.chat.presentation

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.SpaceDividerItemDecoration
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.databinding.FragmentChatListViewPagerItemBinding
import ru.minegoat.oversees.modules.chat.di.ChatComponentHolder

class ChatListVPItemFragment : Fragment(R.layout.fragment_chat_list_view_pager_item) {

    private val component by featureComponent(ChatComponentHolder)

    private val viewModel by lazyViewModel {
        component.chatListVPItemViewModel().create()
    }

    private val type by lazy {
        val intType = arguments?.getInt(TYPE, ChatListType.ALL.ordinal) ?: ChatListType.ALL.ordinal
        ChatListType.values()[intType]
    }

    private val binding by viewBinding(FragmentChatListViewPagerItemBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initChatList()

        subscribeOnGetChatListItems()
    }

    private fun subscribeOnGetChatListItems() {
        viewModel.getChatListItems(type).observe(viewLifecycleOwner) { state ->
            state.on(
                success = {
                    (binding.rvChatList.adapter as ChatListAdapter).data = it
                },
                loading = {
                    //todo
                },
                error = {
                    Log.d("ChatListFragment", "getChatListItems: ${it.message}")
                }
            )
        }
    }

    private fun initChatList() {
        val adapter = ChatListAdapter { chatId ->
            findNavController().navigate(
                ChatListFragmentDirections.actionChatListFragmentToChatFragment(
                    chatId
                )
            )
        }

        binding.rvChatList.adapter = adapter
        binding.rvChatList.addItemDecoration(
            SpaceDividerItemDecoration(
                resources.getDimensionPixelSize(R.dimen.space_divider_8dp),
                LinearLayout.VERTICAL,
                resources.getDimensionPixelSize(R.dimen.space_divider_12dp)
            )
        )
    }

    enum class ChatListType { //don't change order
        ALL,
        PRIVATE,
        GROUPS
    }

    companion object {
        private const val TYPE = "chat_list_type"

        fun newInstance(
            type: ChatListType
        ) = ChatListVPItemFragment().apply {
            arguments = bundleOf(
                TYPE to type.ordinal
            )
        }
    }
}