package ru.minegoat.oversees.modules.user_profile.presentation

import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.BottomSheetChangeAvatarBinding

class ChangeAvatarBottomSheet : BottomSheetDialogFragment(R.layout.bottom_sheet_change_avatar) {

    private val binding by viewBinding(BottomSheetChangeAvatarBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        with(binding) {
            llChangeAvatar.setOnClickListener {
                setResultAndExit(EditPhotoAction.CHOOSE)
            }
            llCamera.setOnClickListener {
                setResultAndExit(EditPhotoAction.TAKE)
            }
            llRemoveAvatar.setOnClickListener {
                setResultAndExit(EditPhotoAction.DELETE)
            }
        }
    }

    private fun setResultAndExit(editPhotoAction: EditPhotoAction) {
        setFragmentResult(
            REQUEST_EDIT_PHOTO_ACTION_KEY,
            bundleOf(EDIT_PHOTO_ACTION_BUNDLE_KEY to editPhotoAction.ordinal)
        )
        findNavController().navigateUp()
    }

    enum class EditPhotoAction {
        CHOOSE,
        TAKE,
        DELETE
    }

    companion object {
        const val REQUEST_EDIT_PHOTO_ACTION_KEY = "request_edit_photo_action"
        const val EDIT_PHOTO_ACTION_BUNDLE_KEY = "edit_photo_action_key"
    }
}