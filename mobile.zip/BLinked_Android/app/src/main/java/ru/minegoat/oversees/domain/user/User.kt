package ru.minegoat.oversees.domain.user

import android.util.Log
import ru.minegoat.oversees.data.db.userProfile.UserRoom
import ru.minegoat.oversees.domain.karma.Karma
import ru.minegoat.oversees.data.network.skill.responses.ResponseMasterSkill
import ru.minegoat.oversees.data.network.user.model.ResponseSocialNetwork
import ru.minegoat.oversees.domain.auth.Phone
import ru.minegoat.oversees.domain.auth.split
import ru.minegoat.oversees.modules.user_profile.network.model.RequestUserProfile
import ru.minegoat.oversees.modules.user_profile.network.model.RequestUserProfileItem

data class User(
    val userId: String,
    val name: String? = null,
    val soname: String? = null,
    val role: UserRole? = null,
    val avatar: String? = null,
    val phone: Phone? = null,
    val description: String? = null,
    val isGuide: Boolean? = null,
    val isCustomer: Boolean = false,
    var isMaster: Boolean? = false,
    val avatarUrl: String? = null,
    val guid: String? = null,
    val homeLocationId: String? = null,
    val sex: Sex? = null,
    val socialNetworks: List<SocialNetwork> = emptyList(),
    val skills: List<MasterSkill>? = null,
    val userRating: UserRating? = null,
    val karma : Karma? = null,
)

fun User.toNetwork(avatarImageEncoded: String? = null, avatarImageFileName: String? = null): RequestUserProfile {
    return RequestUserProfile(
        listOf(RequestUserProfileItem(
            id = userId,
            name = name,
            avatarImageEncoded = avatarImageEncoded,
            avatarFileName = avatarImageFileName,
            phone = phone?.split(),
            userDescription = description,
            isGuide = isGuide,
            isMaster = isMaster,
            homeLocationID = homeLocationId,
            sex = sex?.name?.lowercase(),
            skills = skills?.map { ResponseMasterSkill(it.objId, it.experience ?: "") } ?: emptyList(),
            socialNetwork = socialNetworks.map {
                ResponseSocialNetwork(it.name.name, it.link ?: "") }
        ))
    )
}

fun User.toRoom(): UserRoom {
    Log.d("VVVVV", "toRoom: ${socialNetworks.toMutableList()}")
    return UserRoom(
        userId = userId,
        name = name,
        soname = soname,
//        role = role,
        avatar = avatar,
        phone = phone?.split(),
        description = description,
        isGuide = isGuide,
        isCustomer = isCustomer,
        isMaster = isMaster,
        avatarUrl = avatarUrl,
        guid = guid,
        homeLocationId = homeLocationId,
        sex = sex,
        socialNetworks = socialNetworks.toMutableList(),
        skills = skills?.toMutableList() ?: mutableListOf(),
        karma = karma,
    )
}