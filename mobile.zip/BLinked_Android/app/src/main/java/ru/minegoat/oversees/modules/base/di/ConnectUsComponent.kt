package ru.minegoat.oversees.modules.base.di

import dagger.Component
import ru.minegoat.oversees.base.di.AppComponent
import ru.minegoat.oversees.base.di.components.DiComponent
import ru.minegoat.oversees.modules.base.viewmodels.SendConnectUsMessageViewModel

@ConnectUsScope
@Component(dependencies = [AppComponent::class], modules = [ConnectUsModule::class])
interface ConnectUsComponent : DiComponent {

    fun sendConnectUsMessageViewModel(): SendConnectUsMessageViewModel.Factory

}