package ru.minegoat.oversees.domain.trip

import ru.minegoat.oversees.domain.location.Location

data class Milestone(
    val objID: String? = null,
    val name: String? = null,
    val location: Location? = null,
    val date: Int? = null,
    val type: String? = null,
    val descriptionMilestone: String? = null,
    val order: Int? = null,
    val userEdited: Boolean? = null,
    val journeyNumber: String? = null,
//    val carrier: Carrier? = null,
    val seat: String? = null,
    val vagon: Int? = null,
    val classType: String? = null,
    val terminal: String? = null,
    val distance: Float? = null,
    val aircraft: String? = null,
    val arrayOfLinkedMilestones: List<Milestone>? = null,
    val duration: String? = null,
    val address: String? = null,
    val website: String? = null,
    val phoneNumber: String? = null,
    val isStartPoint: Boolean? = null,
    val isEndPoint: Boolean? = null,
    val inTransit: Boolean? = null,
    val tags: List<String>? = null,
    val images: List<String>? = null,
    val roomNumber: String? = null,
    val mealTimetables: List<MealTimetable>? = null,
    val rentType: String? = null,
    val visibility: Boolean? = null,
    val ownerID: String? = null,
//val organizationLocation: Location? = null,
    val reviewsNumber: Int? = null,
) {
    companion object{
        const val freeTime = ".freeTime"
    }
}