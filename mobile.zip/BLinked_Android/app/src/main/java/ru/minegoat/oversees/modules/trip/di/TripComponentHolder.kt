package ru.minegoat.oversees.modules.trip.di

import ru.minegoat.oversees.App
import ru.minegoat.oversees.base.di.holders.FeatureComponentHolder

object TripComponentHolder : FeatureComponentHolder<TripComponent>() {
    override fun build(): TripComponent {
        return DaggerTripComponent.builder()
            .appComponent(App.component)
            .tripModule(TripModule())
            .build()
    }
}