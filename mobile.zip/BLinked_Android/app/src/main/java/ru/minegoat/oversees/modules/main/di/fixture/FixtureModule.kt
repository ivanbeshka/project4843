package ru.minegoat.oversees.modules.main.di.fixture

import dagger.Module
import dagger.Provides
import ru.minegoat.oversees.modules.main.repository.LocationsFixtureRepository
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import ru.minegoat.oversees.base.db.room.RoomDB
import ru.minegoat.oversees.modules.main.repository.MessagesFixtureRepository

@Module
class FixtureModule {

    @FixtureScope
    @Provides
    fun provideLocationsFixtureRepository(ds: RealmDataStorage): LocationsFixtureRepository {
        return LocationsFixtureRepository(ds)
    }

    @FixtureScope
    @Provides
    fun provideMessagesFixtureRepository(room: RoomDB): MessagesFixtureRepository {
        return MessagesFixtureRepository(room.messageDao())
    }
}