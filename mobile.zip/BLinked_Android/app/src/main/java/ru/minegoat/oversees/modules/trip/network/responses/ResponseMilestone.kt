package ru.minegoat.oversees.modules.trip.network.responses

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.trip.Milestone

data class ResponseMilestone(
    @SerializedName("carrierID")
    val carrierID: String?,
    @SerializedName("locationID")
    val locationID: String?,
    @SerializedName("linkedMilestones")
    val linkedMilestones: List<ResponseMilestone>?,
    @SerializedName("userEdited")
    val userEdited: Boolean?,
    @SerializedName("objID")
    val objID: String?,
    @SerializedName("name")
    val name: String?,
    @SerializedName("date")
    val date: Int?,
    @SerializedName("type")
    val type: String?,
    @SerializedName("milestoneDescription")
    val milestoneDescription: String?,
    @SerializedName("order")
    val order: Int?,
    @SerializedName("journeyNumber")
    val journeyNumber: String?,
    @SerializedName("seat")
    val seat: String?,
    @SerializedName("vagon")
    val vagon: Int?,
    @SerializedName("classType")
    val classType: String?,
    @SerializedName("terminal")
    val terminal: String?,
    @SerializedName("distance")
    val distance: Float?,
    @SerializedName("aircraft")
    val aircraft: String?,
    @SerializedName("duration")
    val duration: String?,
    @SerializedName("address")
    val address: String?,
    @SerializedName("website")
    val website: String?,
    @SerializedName("phoneNumber")
    val phoneNumber: String?,
    @SerializedName("isStartPoint")
    val isStartPoint: Boolean?,
    @SerializedName("isEndPoint")
    val isEndPoint: Boolean?,
    @SerializedName("inTransit")
    val inTransit: Boolean?,
    @SerializedName("roomNumber")
    val roomNumber: String?,
    @SerializedName("rentType")
    val rentType: String?,
    @SerializedName("ownerID")
    val ownerID: String?,
    @SerializedName("organizationLocationID")
    val organizationLocationID: String?,
    @SerializedName("images")
    val images: List<String>?,
    @SerializedName("tags")
    val tags: List<String>?,
    @SerializedName("mealTimetables")
    val mealTimetables: List<ResponseMealTimetable>?,
    @SerializedName("reviewsNumber")
    val reviewsNumber: Int?,
)

fun ResponseMilestone.toBusiness(): Milestone {
    return Milestone(
        objID = objID,
        name = name,
//            location = milestone.locationID,
        date = date,
        type = type,
        descriptionMilestone = milestoneDescription,
        order = order,
        userEdited = userEdited,
        journeyNumber = journeyNumber,
//    carrier: Carrier = "",
        seat = seat,
        vagon = vagon,
        classType = classType,
        terminal = terminal,
        distance = distance,
        aircraft = aircraft,
        arrayOfLinkedMilestones = linkedMilestones?.map { it.toBusiness() },
        duration = duration,
        address = address,
        website = website,
        phoneNumber = phoneNumber,
        isStartPoint = isStartPoint,
        isEndPoint = isEndPoint,
        inTransit = inTransit,
        tags = tags ?: listOf(),
        images = images ?: listOf(),
        roomNumber = roomNumber,
        mealTimetables = mealTimetables?.map { it.toBusiness() },
        rentType = rentType,
        visibility = true,
        ownerID = ownerID,
//organizationLocation: Location = "",
        reviewsNumber = reviewsNumber,
    )
}