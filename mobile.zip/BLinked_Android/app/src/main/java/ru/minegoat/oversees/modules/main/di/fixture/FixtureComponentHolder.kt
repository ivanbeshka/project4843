package ru.minegoat.oversees.modules.main.di.fixture

import ru.minegoat.oversees.App
import ru.minegoat.oversees.base.di.holders.FeatureComponentHolder

object FixtureComponentHolder : FeatureComponentHolder<FixtureComponent>() {
    override fun build(): FixtureComponent {
        return DaggerFixtureComponent.builder()
            .appComponent(App.component)
            .fixtureModule(FixtureModule())
            .build()
    }
}