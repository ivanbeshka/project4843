package ru.minegoat.oversees.modules.chat.repository

import android.util.Log
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.map
import androidx.paging.rxjava2.flowable
import io.reactivex.Completable
import io.reactivex.Flowable
import io.reactivex.Maybe
import io.reactivex.disposables.Disposable
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import ru.minegoat.oversees.base.db.room.RoomDB
import ru.minegoat.oversees.data.db.chat.toChat
import ru.minegoat.oversees.data.db.chat.toMessage
import ru.minegoat.oversees.data.db.trip.TripRealm
import ru.minegoat.oversees.data.db.trip.toTrip
import ru.minegoat.oversees.data.network.chat.model.toChat
import ru.minegoat.oversees.data.repository.user.UserRepository
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import ru.minegoat.oversees.domain.chat.Chat
import ru.minegoat.oversees.domain.chat.ChatLinkedObjType
import ru.minegoat.oversees.domain.chat.Message
import ru.minegoat.oversees.domain.chat.toRoom
import ru.minegoat.oversees.modules.chat.di.ChatScope
import ru.minegoat.oversees.modules.chat.network.ChatApi
import ru.minegoat.oversees.modules.chat.network.MessageTransportApi
import ru.minegoat.oversees.modules.chat.network.responses.MessageResponse
import ru.minegoat.oversees.modules.chat.network.responses.toRoom
import javax.inject.Inject

@ChatScope
class ChatRepository @Inject constructor(
    private val chatApi: ChatApi,
    private val authSharedPref: AuthSharedPref,
    private val userRepository: UserRepository,
    private val roomDB: RoomDB,
    private val realmDS: RealmDataStorage,
    private val messageTransportApi: MessageTransportApi
) {

    fun getChat(chatId: String): Maybe<Chat> {
        return getChatFromNetwork(chatId)
            .onErrorResumeNext(getChatFromDB(chatId))
    }

    fun setupNewChat(chatId: String): Completable {
        return Completable.fromSingle(
            chatApi.getAllMessages(chatId)
            .doOnSuccess { messages ->
                roomDB.messageDao()
                    .insertAll(
                        *messages.map { it.toRoom() }.toTypedArray()
                    )
            }
        )
    }

    fun getMessagesPagingData(
        chatId: String,
        pagingConfig: PagingConfig
    ): Flowable<PagingData<Message>> {

        return Pager(
            config = pagingConfig,
            pagingSourceFactory = { roomDB.messageDao().getAll(chatId) }
        ).flowable
            .map { pagingData ->
                pagingData.map {
                    it.toMessage()
                }
            }
    }

    fun subscribeOnNewMessages(chatId: String): Disposable {
        return messageTransportApi.subscribeOnNewMessages(chatId)
            .subscribeOn(Schedulers.io())
            .subscribeBy(
                onNext = {
                    val messageRoom = it.toRoom()
                    roomDB.messageDao().insertAll(messageRoom).subscribe()
                },
                onError = {
                    Log.d(TAG, "subscribeOnNewMessages: ${it.message}")
                },
                onComplete = {
                    Log.d(TAG, "subscribeOnNewMessages: complete")
                }
            )
    }

    fun readMessage(messageId: String): Completable {
        val userId = "lfjdlfjld" //todo
        return chatApi.readMessage(messageId, userId)
    }

    fun sendMessage(msg: Message): Completable {
        val messageResponse = MessageResponse(msg.objID,msg.ownerId,msg.ownerName,msg.chatId,msg.text,msg.dateTimeSec,msg.contentUrl)
        return messageTransportApi.sendMessage(messageResponse)
    }

    private fun getChatFromDB(chatId: String): Maybe<Chat> {
        return roomDB.chatDao()
            .getById(chatId)
            .flatMap { chat ->

                //todo refactor
                when (chat.linkedObj.type) {
                    ChatLinkedObjType.TRIP -> {
                        val model = TripRealm::class
                        realmDS.getById(model, chat.linkedObj.linkedObjId)
                            .map { chat.toChat(it.toTrip()) }
                    }
                    ChatLinkedObjType.SERVICE -> {
                        Maybe.empty()
                    }
                }
            }
    }

    private fun getChatFromNetwork(chatId: String): Maybe<Chat> {
        return chatApi.getChat(chatId)
            .flatMap { chat ->

                //todo refactor
                when (ChatLinkedObjType.valueOf(chat.linkedObj.type)) {
                    ChatLinkedObjType.TRIP -> {
                        val model = TripRealm::class
                        realmDS.getById(model, chat.linkedObj.linkedObjId)
                            .map { chat.toChat(it.toTrip()) }
                    }
                    ChatLinkedObjType.SERVICE -> {
                        Maybe.empty()
                    }
                }
            }
            .doOnSuccess {
                roomDB.chatDao().insertAll(it.toRoom())
            }
    }

    private companion object {
        private const val TAG = "ChatRepo"
    }
}