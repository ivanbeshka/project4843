package ru.minegoat.oversees.modules.user_profile.model

import android.content.Context
import ru.minegoat.oversees.R

enum class Progress {
    TRAVELS,
    COUNTRIES,
    CITIES,
    PHOTOS,
    PLACES,
    COMMENTS;

    val res: Int
        get() {
            return when (this) {
                TRAVELS -> R.string.travels
                COUNTRIES -> R.string.countries
                CITIES -> R.string.cities
                PHOTOS -> R.string.photos
                PLACES -> R.string.places
                COMMENTS -> R.string.comments
            }
        }

    companion object {
        fun fromStringByRes(string: String, context: Context): Progress {
            return when (string) {
                context.getString(R.string.travels) -> TRAVELS
                context.getString(R.string.countries) -> COUNTRIES
                context.getString(R.string.cities) -> CITIES
                context.getString(R.string.photos) -> PHOTOS
                context.getString(R.string.places) -> PLACES
                context.getString(R.string.comments) -> COMMENTS
                else -> throw IllegalStateException()
            }
        }
    }
}