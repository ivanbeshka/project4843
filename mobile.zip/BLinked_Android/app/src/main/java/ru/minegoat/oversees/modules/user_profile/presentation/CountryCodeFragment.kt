package ru.minegoat.oversees.modules.user_profile.presentation

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.databinding.FragmentCounryCodeBinding
import ru.minegoat.oversees.modules.map.di.MapComponentHolder

class CountryCodeFragment : Fragment(R.layout.fragment_counry_code) {

    private val component by featureComponent(MapComponentHolder)

    private val binding by viewBinding(FragmentCounryCodeBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

            binding.ivBtnExit.setOnClickListener {
                findNavController().navigateUp()
            }
    }

}