package ru.minegoat.oversees.base.exceptions

open class AuthException(override val message: String) : Exception(message)