package ru.minegoat.oversees.domain.user

enum class FeedbackType {
    MASTERS,
    CLIENTS
}