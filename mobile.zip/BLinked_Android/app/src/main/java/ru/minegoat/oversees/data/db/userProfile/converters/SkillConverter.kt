package ru.minegoat.oversees.data.db.userProfile.converters

import androidx.room.ProvidedTypeConverter
import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import ru.minegoat.oversees.domain.user.MasterSkill
import java.lang.reflect.Type
import java.util.*

@ProvidedTypeConverter
class SkillConverter {

    var gson = Gson()

    @TypeConverter
    fun toList(data: String?): MutableList<MasterSkill?>?{
        if (data == null) {
            return Collections.emptyList()
        }
        val listType: Type = object : TypeToken<MutableList<MasterSkill?>?>() {}.type
        return gson.fromJson<MutableList<MasterSkill?>>(data, listType)
    }


    @TypeConverter
    fun toString(someObjects: MutableList<MasterSkill?>?): String? {
        return gson.toJson(someObjects)
    }
}