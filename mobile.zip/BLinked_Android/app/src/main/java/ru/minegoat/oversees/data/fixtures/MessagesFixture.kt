package ru.minegoat.oversees.data.fixtures

import ru.minegoat.oversees.domain.chat.Message

object MessagesFixture {

    val messages = listOf(
        Message(
            objID = "roeworuowerowerowr",
            ownerId = "",
            ownerName = "Masha",
            chatId = "qwwqwqwwqw",
            text = "Hello world",
            dateTimeSec = 1652949767
        ),
        Message(
            objID = "roeworuowerowerow",
            ownerId = "weqwe",
            ownerName = "Name",
            chatId = "qwwqwqwwqw",
            text = "Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world!Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world!Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world!",
            dateTimeSec = 1655628167
        ),
        Message(
            objID = "roeworuowerowero",
            ownerId = "weqwe",
            ownerName = "Name",
            chatId = "qwwqwqwwqw",
            text = "Hello world",
            dateTimeSec = 1655628167
        ),
        Message(
            objID = "roeworuowerower",
            ownerId = "",
            ownerName = "Masha",
            chatId = "qwwqwqwwqw",
            text = "Hello world Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world!Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world!Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world!Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world!Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world!Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world!",
            dateTimeSec = 1655628167
        ),
        Message(
            objID = "roeworuowerowe",
            ownerId = "",
            ownerName = "Masha",
            chatId = "qwwqwqwwqw",
            text = "Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world! Hello world!",
            dateTimeSec = 1655628167
        ),
        Message(
            objID = "roeworuowerow",
            ownerId = "",
            ownerName = "Masha",
            chatId = "qwwqwqwwqw",
            text = "Hello world",
            dateTimeSec = 1655628167
        ),
        Message(
            objID = "roeworuowero",
            ownerId = "",
            ownerName = "Masha",
            chatId = "qwwqwqwwqw",
            text = "Hello world",
            dateTimeSec = 1668847367
        ),
        Message(
            objID = "roeworuower",
            ownerId = "",
            ownerName = "Masha",
            chatId = "qwwqwqwwqw",
            text = "Hello world",
            dateTimeSec = 1668847367
        ),
        Message(
            objID = "roeworuowe",
            ownerId = "",
            ownerName = "Masha",
            chatId = "qwwqwqwwqw",
            text = "Hello world",
            dateTimeSec = 1668847367
        )
    )
}