package ru.minegoat.oversees.modules.master_profile.di

import dagger.Module

@Module
class CommentModule {
}