package ru.minegoat.oversees.modules.user_profile.presentation.utils

import android.net.Uri


private const val SCHEME = "https"
private const val HOST = "oversees.ru"
const val PATH_USER = "userID"
const val PARAMETER_ID = "id"

fun createShareUserUri(userId: String): Uri {
    val builder = Uri.Builder()
    builder.scheme(SCHEME)
        .authority(HOST)
        .appendPath(PATH_USER)
        .appendQueryParameter(PARAMETER_ID, userId)
    return builder.build()
}



