package ru.minegoat.oversees.data.network.karma

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.karma.KAttribute
import ru.minegoat.oversees.domain.karma.Karma

data class KarmaNetwork(
    @SerializedName("ownerID")
    val ownerID: String,
    @SerializedName("attribute")
    val attribute: List<KAttributeNetwork>
)

fun KarmaNetwork.toKarma(): Karma {
    return Karma(
        ownerID,
        attribute.map { it.toKAttribute() }
    )
}