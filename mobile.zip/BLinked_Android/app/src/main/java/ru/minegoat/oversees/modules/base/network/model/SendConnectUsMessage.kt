package ru.minegoat.oversees.modules.base.network.model

import com.google.gson.annotations.SerializedName

data class SendConnectUsMessage(
    @SerializedName("additional")
    val additional: String? = null,
    @SerializedName("name")
    val name: String? = null,
    @SerializedName("description")
    val description: String? = null,
    @SerializedName("type")
    val type: String? = null,
)