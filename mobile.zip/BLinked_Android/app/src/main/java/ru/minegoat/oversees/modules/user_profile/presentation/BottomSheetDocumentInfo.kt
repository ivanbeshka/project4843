package ru.minegoat.oversees.modules.user_profile.presentation


import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.fragment.app.setFragmentResult
import androidx.fragment.app.setFragmentResultListener
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.BottomSheetDocumentInfoBinding

class BottomSheetDocumentInfo : BottomSheetDialogFragment(R.layout.bottom_sheet_document_info) {

    private val binding by viewBinding(BottomSheetDocumentInfoBinding::bind)

    private val oldName: String by lazy {
        this.arguments?.getString(NAME, "") ?: ""
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setFragmentResultListener(REQUEST_ACTION_KEY) { _, bundle ->
            val action = bundle.getInt(ACTION_BUNDLE_KEY)
            when (FragmentAction.values()[action]) {
                FragmentAction.RENAMED -> {
                    val name = bundle.getString(ACTION_NAME_KEY, "")
                    setResultAndExit(UserAccountFragment.FragmentAction.RENAMED, name)
                }
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.llRename.setOnClickListener {
            findNavController().navigate(R.id.action_bottomSheetDocumentInfo_to_bottomSheetRenameDocument,
                                         bundleOf(BottomSheetRenameDocument.SEND_NAME to oldName)
            )
        }

        binding.llDelete.setOnClickListener {
            setResultAndExit(UserAccountFragment.FragmentAction.DELETE_DOC, oldName)
        }

        binding.llShare.setOnClickListener {
            setResultAndExit(UserAccountFragment.FragmentAction.SHARE_DOCUMENT, oldName)
        }
    }

    private fun setResultAndExit(resultAction: UserAccountFragment.FragmentAction, name: String) {
        setFragmentResult(
            UserAccountFragment.REQUEST_ACTION_KEY,
            bundleOf(
                UserAccountFragment.ACTION_BUNDLE_KEY to resultAction.ordinal,
                UserAccountFragment.ACTION_NAME_KEY to name
            )
        )
        findNavController().navigateUp()
    }

    enum class FragmentAction {
        RENAMED
    }

    companion object {
        const val REQUEST_ACTION_KEY = "BottomSheetDocumentInfo_request_action"
        const val ACTION_BUNDLE_KEY = "BottomSheetDocumentInfo_action_bundle_key"
        const val ACTION_NAME_KEY = "BottomSheetDocumentInfo_action_name_key"
        const val NAME = "name"
    }
}
