package ru.minegoat.oversees.modules.master_profile.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResultListener
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.subscribeBy
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.base.utils.ui.fragment.showToast
import ru.minegoat.oversees.databinding.FragmentEditMasterProfileBinding
import ru.minegoat.oversees.modules.user_profile.di.UserProfileComponentHolder
import ru.minegoat.oversees.modules.user_profile.presentation.DialogDeleteAccountFragment

class EditMasterProfileFragment : Fragment(R.layout.fragment_edit_master_profile) {

    private val binding by viewBinding(FragmentEditMasterProfileBinding::bind)

    private val component by featureComponent(UserProfileComponentHolder)

    private val compositeDisposable = CompositeDisposable()

    private val viewModel by lazyViewModel {
        component.editMasterProfileViewModel().create()
    }

    @SuppressLint("CheckResult")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setFragmentResultListener(DialogDeleteAccountFragment.REQUEST_ACTION_KEY) { _, bundle ->

            bundle.getBoolean(DialogDeleteAccountFragment.ACTION_BUNDLE_KEY).let { needDelete ->
                if (needDelete) {
                    compositeDisposable.add(viewModel.deleteProfile().subscribeBy(
                        onComplete = {
                            showToast(R.string.delete_account_complete)
                        },
                        onError = {
                            showToast(R.string.delete_account_error)
                        }
                    ))
                }
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setOnMenuItemsClickListeners()
        setOnClickListeners()
    }

    override fun onDestroy() {
        compositeDisposable.clear()
        super.onDestroy()
    }

    private fun setOnClickListeners() {
        with(binding) {
            flPersonalInfo.setOnClickListener {
                findNavController().navigate(
                    R.id.action_editMasterProfileFragment_to_editUserProfileFragment
                )
            }
            flTechnics.setOnClickListener {
                findNavController().navigate(
                    R.id.action_editMasterProfileFragment_to_userTechniquesFragment
                )
            }
            flWayOfMaster.setOnClickListener {
                findNavController().navigate(R.id.action_editMasterProfileFragment_to_masterInfoFragment)
            }
        }
    }


    private fun setOnMenuItemsClickListeners() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }

        binding.toolbar.setOnMenuItemClickListener {
            if (it.itemId == R.id.delete_account) {
                findNavController().navigate(R.id.action_editMasterProfileFragment_to_dialogDeleteAccountFragment)
            }
            true
        }
    }


}