package ru.minegoat.oversees.modules.chat.network

import io.reactivex.Completable
import io.reactivex.Flowable
import ru.minegoat.oversees.modules.chat.network.responses.MessageResponse

interface MessageTransportApi {
    fun sendMessage(msg: MessageResponse): Completable
    fun subscribeOnNewMessages(chatId: String): Flowable<MessageResponse>
    fun unsubscribeOnNewMessages(chatId: String): Completable
}