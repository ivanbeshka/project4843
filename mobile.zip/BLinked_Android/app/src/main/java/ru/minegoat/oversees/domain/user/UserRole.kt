package ru.minegoat.oversees.domain.user

data class UserRole(
    val id: String? = null,
    val name: String? = null
)