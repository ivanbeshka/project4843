package ru.minegoat.oversees.base.helpers.file_manager

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.Single
import io.reactivex.Observable
import kotlinx.coroutines.*
import ru.minegoat.oversees.BuildConfig
import ru.minegoat.oversees.data.network.filemanager.GetFilesApi
import java.io.File
import java.io.IOException
import java.util.*
import javax.inject.Inject
import javax.net.ssl.*

class FileManager @Inject constructor(private val context: Context,
                                      private val getFiles: GetFilesApi) {

    // Копирование файлов из внешних папок во внутреннюю
    fun getFilesFromPick(vararg storageFilesUris: Uri, isCache: Boolean): Single<List<Uri>> =
            Observable
                .fromIterable(
                    arrayListOf(*storageFilesUris)
                )
                .flatMap {
                    copyFile(it, isCache).toObservable()
                }
                .toList()

    // Получение Uri файлов по его имени из сети с проверкой их кэширования
    // При отсутствии файла возвращает Uri.EMPTY в соответствующем месте массива
    fun getFiles(vararg nameList: String, isCache: Boolean): Single<List<Uri>> =
            Observable
                .fromIterable(arrayListOf(*nameList))
                .concatMap {
                    getFileUri(it, isCache).toObservable()
                }
                .toList()

    // Генерация Uri для фото с камеры
    fun createUriForNewPhoto(isCache: Boolean): Single<Uri> =
            Single.create {
                try {
                    it.onSuccess(
                        FileProvider.getUriForFile(context, "${BuildConfig.APPLICATION_ID}.provider", File(dir(isCache), "${UUID.randomUUID()}.png").apply {
                            createNewFile()
                            deleteOnExit()
                        })
                    )
                } catch (e: Exception) {
                    it.onError(e)
                }
            }

    // Удаление файлов
    fun removeFile(storageFileName: String): Completable =
            Completable.create {
                try {
                    File(dir(true), storageFileName).delete()
                    File(dir(false), storageFileName).delete()
                    it.onComplete()
                } catch (e: Exception) {
                    it.onError(e)
                }
            }

    private fun dir(isCache: Boolean) = if (isCache) context.cacheDir else context.filesDir

    // Функция получения имени файла из URI, полученного из пикера
    @SuppressLint("Recycle")
    fun getFileName(uri: Uri): String {
        if (uri.scheme == "content") {
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            cursor?.run {
                if (moveToFirst()) {
                    val columnIndex = getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    return getString(columnIndex)
                }
            }
        }
        return uri.path?.substring((uri.path?.lastIndexOf('/') ?: 0) + 1) ?: ""
    }

    // Функция получения расширения файла по его имени
    private fun getFileExt(name: String): String = name.substringAfterLast('.', "")
    private fun getFileExt(uri: Uri): String = getFileExt(getFileName(uri))

    // Функция копирования файла из папки в папку
    private fun copyFile(uri: Uri, isCache: Boolean): Maybe<Uri> =
            Maybe.create {
                try {
                    val ext = getFileExt(uri)
                    val dst = File(dir(isCache), "${UUID.randomUUID()}${if (ext.isNotEmpty()) ".$ext" else ""}").toUri()
                    context.contentResolver.openInputStream(uri)?.use { fis ->
                        context.contentResolver.openOutputStream(dst)?.use { os ->
                            try {
                                fis.copyTo(os)
                                it.onSuccess(dst)
                            } catch (e: IOException) {
                                throw(e)
                            } finally {
                                os.close()
                                fis.close()
                            }
                        }
                    }
                } catch (e: Exception) {
                    it.onError(e)
                }
            }

    // Получение Uri файла по его имени
    private fun getFileUri(fileName: String, isCache: Boolean): Maybe<Uri> =
            Maybe.create {
                val dir = dir(isCache)
                if (fileName.isEmpty())
                    it.onSuccess(Uri.EMPTY)
                try {
                    if (!isFileCached(fileName, isCache)) {
                        val downloadResult = downloadFile(fileName, isCache)
                        it.onSuccess(downloadResult)
                    }
                    it.onSuccess(File(dir, fileName).toUri())
                } catch (e: Exception) {
                    it.onSuccess(Uri.EMPTY)
                }
            }


    // Проверка на наличие кэша
    private fun isFileCached(name: String, isCache: Boolean): Boolean =
            try {
                val stream = context.contentResolver.openInputStream(File(dir(isCache), name).toUri())
                (stream != null).also {
                    stream?.close()
                }
            } catch (e: Exception) {
                false
            }

    // Функция скачивания файла из интернета
    private fun downloadFile(fileName: String, isCache: Boolean): Uri {
        if (fileName.isEmpty())
            return Uri.EMPTY
        val outFile = File(dir(isCache), fileName)
        try {
            val inputStream = getFiles.getImage(fileName).blockingGet().byteStream()
            inputStream.let { fis ->
                try {
                    val outputStream = context.contentResolver.openOutputStream(outFile.toUri(), "rw")
                    outputStream?.let { os ->
                        try {
                            fis.copyTo(os)

                        } catch (e: Exception) {
                            throw Throwable(e)
                        } finally {
                            os.close()
                        }
                    }
                    fis.close()
                    return Uri.fromFile(outFile)
                } catch (e: Exception) {
                    fis.close()
                    throw Throwable(e)
                } finally {
                    fis.close()
                }
            }
        } catch (e: Exception) {
            return Uri.EMPTY
        }
    }

//    private lateinit var resultLauncher: ActivityResultLauncher<Intent>
//    private val pickResult: PublishSubject<List<FileManager.Document>> = PublishSubject.create()

//    private fun getMediaType(fileName: String) = FileManager.MediaType.getTypeFromExt(getFileExt(fileName))
//
//    // Получение mime типа файла
//    private fun mime(uri: Uri): String = context.contentResolver.getType(uri) ?: ""
//
//    // Перечень файлов для проверки возможности просмотра
//    private val fileTypes by lazy {
//        arrayListOf(jpg, tif, png, pdf, doc, docx, rtf, mp4, avi)
//    }

    // Функция сохранения выбранных пикером файлов в локальную папку
//    private fun copyMediaToLocalDir(filesList: ArrayList<Pair<String, Uri>>): List<FileManager.Document> {
//        val docList = mutableListOf<FileManager.Document>()
//        for (i in filesList.indices) {
//            val ext = getFileExt(filesList[i].first)
//            val fileName = "${UUID.randomUUID()}.$ext"
//            if (copyFile(filesList[i].second, Uri.fromFile(File(localDir, fileName))))
//                docList.add(FileManager.Document(type = FileManager.MediaType.getTypeFromExt(ext), name = fileName,
//                                                 uri = Uri.fromFile(File(localDir, fileName))
//                )
//                )
//        }
//        return docList.toList()
//    }

    // Функция удаления файлов из кеша
//    override fun cacheClean(): Single<Boolean> = Single.create {
//        try {
//            File(cacheDir.path).walkTopDown().forEach { file ->
//                if (file.isFile)
//                    file.delete()
//            }
//            it.onSuccess(true)
//        } catch (e: Exception) {
//            it.onError(e)
//        }
//    }
}

// Регистрация контракта на запуск внешних активностей. Вызывается до запуска onResume Activity
//    override fun registerContract(activity: AppCompatActivity) {
//        resultLauncher = activity.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
//            if (result.resultCode == AppCompatActivity.RESULT_OK) {
//                try {
//                    result.data?.run {          // Получены данные от запущенной внешней программы
//                        val imagesEncodedList = ArrayList<Pair<String, Uri>>()
//                        data?.run {             // Обработка выбора одного файла
//                            val fileName = getFileName(this)
//                            if (getMediaType(fileName) != FileManager.MediaType.OTHER)
//                                imagesEncodedList.add(Pair(getFileName(this), this))
//                            else {
//                                pickResult.onError(Throwable("Files of such type are not supported"))
//                            }
//                        } ?: clipData?.run {        // Обработка выбора нескольких файлов
//                            for (i in 0 until this.itemCount) {
//                                val uri = this.getItemAt(i).uri
//                                val fileName = getFileName(uri)
//                                if (getMediaType(fileName) != FileManager.MediaType.OTHER)
//                                    imagesEncodedList.add(Pair(getFileName(uri), uri))
//                            }
//                            if (this.itemCount > imagesEncodedList.size)        // Часть файлов не могут быть применены в программе
//                                Toast.makeText(context, "Only ${imagesEncodedList.size} can be picked", Toast.LENGTH_LONG).show()
//                        }
//                        if (imagesEncodedList.size == 0)            // Ничего не выбрано
//                            Toast.makeText(context, "Yoy have selected nothing", Toast.LENGTH_LONG).show()
//                        else
//                            pickResult.onNext(copyMediaToLocalDir(imagesEncodedList))
//                    }
//                } catch (e: Exception) {
//                    pickResult.onError(e)
//                    Toast.makeText(activity, "Something went wrong", Toast.LENGTH_LONG)
//                        .show()
//                }
//            }
//        }
//    }

// Интент на запуск пикера файлов
//    private val pickIntent by lazy {
//        Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
//            addCategory(Intent.CATEGORY_OPENABLE)
//            val mimeTypes = arrayOf(FileManager.MediaType.IMAGE.mime,
//                                    FileManager.MediaType.PDF.mime,
//                                    FileManager.MediaType.DOC.mime,
//                                    FileManager.MediaType.VIDEO.mime
//            )
//            type = "*/*"
//            putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
//            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
//            action = Intent.ACTION_GET_CONTENT
//        }
//    }

// Запуск пикера файлов
//    override fun pickFiles(): PublishSubject<List<FileManager.Document>> {
//        if (this::resultLauncher.isInitialized)
//            resultLauncher.launch(Intent.createChooser(pickIntent, "Select Picture"))
//        return pickResult
//    }

// Запуск интента на просмотр файла
//    override fun showFile(name: String) {
//        if (!fileTypes.contains(getFileExt(name))) {
//            Toast.makeText(context, "This file has wrong extension", Toast.LENGTH_LONG).show()
//            return
//        }
//        CoroutineScope(Dispatchers.IO).launch {
//            try {
//                val fileDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
//                val localFile = File(localDir, name)
//                if (!isFileCached(name)) {
//                    if (webDownload("$host$name", localFile.path) == Uri.EMPTY) {
//                        CoroutineScope(Dispatchers.Main).launch {
//                            Toast.makeText(context, "File not found", Toast.LENGTH_SHORT).show()
//                        }
//                        return@launch
//                    }
//                }
//                if (localFile != Uri.EMPTY) {
//                    val outUri = FileProvider.getUriForFile(context, BuildConfig.APPLICATION_ID + ".provider", File(fileDir, name))
//                    copyFile(localFile.toUri(), outUri)
//                    val intent = Intent(Intent.ACTION_VIEW, outUri)
//                    intent.setDataAndType(outUri, mime(outUri))
//                    intent.flags = FLAG_ACTIVITY_NEW_TASK or FLAG_GRANT_READ_URI_PERMISSION
//                    context.startActivity(intent)
//                }
//            } catch (e: Exception) {
//                throw Throwable(e)
//            }
//        }
//    }

// Удаление файла в кеше
//    override fun cacheDelete(name: String): Single<Boolean> = Single.create {
//        try {
//            File(cacheDir, name).delete()
//            it.onSuccess(true)
//        } catch (e: Exception) {
//            it.onError(e)
//        }
//    }

// Функция обновления файла в кеше. Скачивается из сети
//    override fun cacheUpdate(name: String): Single<Uri> = Single.create {
//        if (name.isEmpty())
//            it.onError(FileNotFoundException())
//        val outFile = File(cacheDir, name)
//        try {
//            webDownload("$host$name", outFile.path)
//        } catch (e: Exception) {
//            it.onError(e)
//        }
//        it.onSuccess(outFile.toUri())
//    }

//    override fun cacheUpdate(nameList: List<String>): Single<List<Uri>> =
//            Observable
//                .fromIterable(nameList)
//                .concatMapSingle {
//                    cacheUpdate(it)
//                }
//                .toList()