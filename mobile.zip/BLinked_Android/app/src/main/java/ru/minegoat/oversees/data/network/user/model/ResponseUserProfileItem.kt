package ru.minegoat.oversees.data.network.user.model

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.data.network.karma.KarmaNetwork
import ru.minegoat.oversees.data.network.skill.responses.ResponseMasterSkill
import ru.minegoat.oversees.domain.karma.Karma

data class ResponseUserProfileItem(
    @SerializedName("id")
    val id: String,
    @SerializedName("name")
    val name: String?,
    @SerializedName("avatarURL")
    val avatarURL: String?,
    @SerializedName("phone")
    val phone: String?,
    @SerializedName("userDescription")
    val userDescription: String?,
    @SerializedName("guide")
    val guide: Boolean?,
    @SerializedName("isGuide")
    val isGuide: Boolean?,
    @SerializedName("isMaster")
    val isMaster: Boolean?,
    @SerializedName("homeLocationID")
    val homeLocationID: String?,
    @SerializedName("sex")
    val sex: String?,
    @SerializedName("skills")
    val skills: MutableList<ResponseMasterSkill>,
    @SerializedName("userRating")
    val userRating: ResponseUserRating,
    @SerializedName("socialNetworks")
    val socialNetworks: MutableList<ResponseSocialNetwork>,
    @SerializedName("karma")
    val karma : KarmaNetwork,
//    @SerializedName("socialNetworks")
//    val socialNetworks: MutableList<ResponseSocialNetwork>
)
