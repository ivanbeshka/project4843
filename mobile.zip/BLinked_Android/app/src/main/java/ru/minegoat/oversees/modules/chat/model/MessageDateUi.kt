package ru.minegoat.oversees.modules.chat.model

import ru.minegoat.oversees.modules.chat.presentation.MessageListAdapter

data class MessageDateUi(
    override val id: String,
    val date: String
) : MessageItemUi(id, MessageListAdapter.MessageItemType.DATE)
