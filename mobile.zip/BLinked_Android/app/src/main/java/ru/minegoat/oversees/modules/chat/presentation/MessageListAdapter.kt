package ru.minegoat.oversees.modules.chat.presentation

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.ItemMsgDateBinding
import ru.minegoat.oversees.databinding.ItemMyMsgBinding
import ru.minegoat.oversees.databinding.ItemOtherMsgBinding
import ru.minegoat.oversees.modules.chat.model.MessageDateUi
import ru.minegoat.oversees.modules.chat.model.MessageItemUi
import ru.minegoat.oversees.modules.chat.model.MessageUi

class MessageListAdapter : PagingDataAdapter<MessageItemUi, MessageListAdapter.BaseViewHolder>(
    COMPARATOR
) {

    abstract inner class BaseViewHolder(root: View): ViewHolder(root) {
        abstract fun bind(item: MessageItemUi)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder {
        val inflater = LayoutInflater.from(parent.context)

        if (viewType == PLACE_HOLDER) {
            throw IllegalStateException("not support placeholders")
        }

        return when(MessageItemType.values()[viewType]) {
            MessageItemType.MY -> {
                val root = inflater.inflate(R.layout.item_my_msg, parent, false)
                MyMessageViewHolder(root)
            }
            MessageItemType.OTHER -> {
                val root = inflater.inflate(R.layout.item_other_msg, parent, false)
                OtherMessageViewHolder(root)
            }
            MessageItemType.DATE -> {
                val root = inflater.inflate(R.layout.item_msg_date, parent, false)
                DateViewHolder(root)
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        val item = getItem(position)
        return item?.type?.ordinal ?: PLACE_HOLDER
    }

    override fun onBindViewHolder(holder: BaseViewHolder, position: Int) {
        getItem(position)?.let {
            holder.bind(it)
        }
    }

    enum class MessageItemType {
        MY,
        OTHER,
        DATE
    }

    private inner class MyMessageViewHolder(root: View): BaseViewHolder(root) {
        private val binding by viewBinding(ItemMyMsgBinding::bind)

        override fun bind(item: MessageItemUi) {
            val msg = item as MessageUi
            binding.vgMsg.msg = msg
        }
    }

    private inner class OtherMessageViewHolder(root: View): BaseViewHolder(root) {
        private val binding by viewBinding(ItemOtherMsgBinding::bind)

        override fun bind(item: MessageItemUi) {
            val msg = item as MessageUi
            binding.vgMsg.msg = msg
        }
    }

    private inner class DateViewHolder(root: View): BaseViewHolder(root) {
        private val binding by viewBinding(ItemMsgDateBinding::bind)

        override fun bind(item: MessageItemUi) {
            val date = item as MessageDateUi
            binding.tvMsgDate.text = date.date
        }
    }

    companion object {

        private const val PLACE_HOLDER = -1

        private val COMPARATOR = object : DiffUtil.ItemCallback<MessageItemUi>() {
            override fun areItemsTheSame(oldItem: MessageItemUi, newItem: MessageItemUi): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: MessageItemUi, newItem: MessageItemUi): Boolean {
                return if (oldItem is MessageUi && newItem is MessageUi) {
                    oldItem == newItem
                } else if (oldItem is MessageDateUi && newItem is MessageDateUi) {
                    oldItem == newItem
                } else false
            }
        }
    }
}