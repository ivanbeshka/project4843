package ru.minegoat.oversees.data.db.chat.dao

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import io.reactivex.Completable
import io.reactivex.Maybe
import ru.minegoat.oversees.data.db.chat.MessageRoom

@Dao
interface MessageDao {

    @Query("SELECT * FROM messages WHERE chat_id=:chatId ORDER BY dateTime DESC")
    fun getAll(chatId: String): PagingSource<Int, MessageRoom>

    @Query("SELECT * FROM messages WHERE objID=:messageId")
    fun getById(messageId: String): Maybe<MessageRoom>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(vararg messages: MessageRoom): Completable
}