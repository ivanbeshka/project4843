package ru.minegoat.oversees.data.db.skill

import io.realm.kotlin.ext.realmListOf
import io.realm.kotlin.ext.toRealmList
import io.realm.kotlin.types.ObjectId
import io.realm.kotlin.types.RealmList
import io.realm.kotlin.types.RealmObject
import io.realm.kotlin.types.annotations.PrimaryKey
import ru.minegoat.oversees.domain.user.Skill

class SkillRealm(): RealmObject {
    @PrimaryKey
    var id: ObjectId = ObjectId.create()
    val objId: String
        get() {
            return id.toString()
        }
    var ownerId: String? = null
    var tags: RealmList<String> = realmListOf()
    var name: String? = null
    var skillDescription: String? = null
    var internationalDescription: String? = null
    var internationalName: String? = null

    constructor(
        objId: String,
        ownerId: String? = null,
        tags: List<String>? = null,
        name: String? = null,
        skillDescription:String? = null,
        internationalDescription: String? = null,
        internationalName: String? = null
    ): this(){
        this.id = ObjectId.Companion.from(objId)
        this.ownerId = ownerId
        this.tags = tags?.toRealmList() ?: realmListOf()
        this.name = name
        this.skillDescription = skillDescription
        this.internationalDescription = internationalDescription
        this.internationalName = internationalName
    }
}

fun SkillRealm.toSkill(): Skill {
    return Skill(
        objId = objId,
        ownerId = ownerId,
        tags = tags.toList(),
        name = name,
        skillDescription = skillDescription,
        internationalDescription = internationalDescription,
        internationalName = internationalName
    )
}