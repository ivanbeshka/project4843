package ru.minegoat.oversees.data.network.auth

import okhttp3.Interceptor
import okhttp3.Response
import ru.minegoat.oversees.base.helpers.auth.INeedTokenUpdate
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import java.net.HttpURLConnection

class BearerTokenInterceptor(
    private val authSharedPref: AuthSharedPref,
    private val needTokenUpdate: dagger.Lazy<INeedTokenUpdate>
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request().newBuilder()
        authSharedPref.token?.let {
            request.addHeader("Authorization", "Bearer $it")
        }
        val buildRequest = request.build()
        val response = chain.proceed(buildRequest)

        if (response.code == HttpURLConnection.HTTP_UNAUTHORIZED && authSharedPref.token != null) {
            needTokenUpdate.get().updateToken()
        }

        return response
    }
}