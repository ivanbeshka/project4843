package ru.minegoat.oversees.data.network.skill.responses

import com.google.gson.annotations.SerializedName

data class ResponseSkill(
    @SerializedName("items")
    val items: List<ResponseSkillItem>
)
