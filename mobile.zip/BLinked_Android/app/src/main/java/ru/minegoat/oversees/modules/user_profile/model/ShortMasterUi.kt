package ru.minegoat.oversees.modules.user_profile.model

data class ShortMasterUi(
    val objID: String,
    val name: String? = null,
    val avatarUrl: String? = null,
    val masterTypes: List<String> = listOf(),
    val sumKarma: Int? = null
)
