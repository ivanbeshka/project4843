package ru.minegoat.oversees.data.db.userProfile.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import io.reactivex.Completable
import io.reactivex.Maybe
import ru.minegoat.oversees.data.db.userProfile.UserRoom

@Dao
interface UserDao {

    @Query("SELECT * FROM users WHERE userId=:id")
    fun getById(id: String): Maybe<UserRoom>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(user: UserRoom): Completable

    @Query("DELETE FROM users WHERE userId=:id")
    fun logout(id:String): Completable
}