package ru.minegoat.oversees.data.repository.messenger

import io.reactivex.Completable
import io.realm.kotlin.types.ObjectId
import ru.minegoat.oversees.base.db.room.RoomDB
import ru.minegoat.oversees.data.network.chat.ChatManageApi
import ru.minegoat.oversees.data.network.chat.model.ChatResponse
import ru.minegoat.oversees.data.db.chat.ChatRoom
import ru.minegoat.oversees.domain.chat.Chat
import ru.minegoat.oversees.domain.chat.IChatLinkedObj
import ru.minegoat.oversees.domain.chat.toNetwork
import ru.minegoat.oversees.domain.chat.toRoom
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MessengerRepository @Inject constructor(
    private val api: ChatManageApi,
    private val roomDB: RoomDB
) {

    fun createChat(userId: String, chatName: String, linkedObjProvider: IChatLinkedObj): Completable {
        val chat = Chat(
            ObjectId.create().toString(),
            chatName,
            userId,
            listOf(userId),
            linkedObj = linkedObjProvider
        )

        val completableFromDS = addChatToDB(chat.toRoom())
        val completableFromNetwork = addChatToNetwork(chat.toNetwork())

        return completableFromDS.mergeWith(completableFromNetwork)
    }

    fun addToChat(chatId: String, userId: String): Completable {
        return api.addToChat(chatId, userId)
    }

    fun removeFromChat(chatId: String, userId: String): Completable {
        return api.removeFromChat(chatId, userId)
    }

    private fun addChatToDB(chat: ChatRoom): Completable {
        return roomDB.chatDao().insertAll(chat)
    }

    private fun addChatToNetwork(chat: ChatResponse): Completable {
        return api.createChat(chat)
    }
}