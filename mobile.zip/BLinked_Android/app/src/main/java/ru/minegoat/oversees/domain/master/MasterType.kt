package ru.minegoat.oversees.domain.master

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import ru.minegoat.oversees.data.db.master.MasterTypeRealm

@Parcelize
data class MasterType(
    val objID: String,
    val name: String,
    val masterTypeDescription: String?
) : Parcelable

fun MasterTypeRealm.toMasterType() =
    MasterType(
        objID = this.objId,
        name = this.name ?: "",
        masterTypeDescription = this.masterTypeDescription
    )


