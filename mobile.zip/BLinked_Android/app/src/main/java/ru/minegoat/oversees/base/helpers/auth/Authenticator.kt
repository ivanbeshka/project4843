package ru.minegoat.oversees.base.helpers.auth

import android.util.Log
import io.reactivex.Completable
import io.reactivex.Observable
import io.reactivex.Single
import io.reactivex.subjects.PublishSubject
import ru.minegoat.oversees.data.repository.auth.AuthRepository
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import ru.minegoat.oversees.domain.auth.Phone
import java.time.ZoneId

class Authenticator constructor(
    private val authSharedPref: AuthSharedPref,
    private val authRepo: AuthRepository
) : INeedTokenUpdate {
    private val needTokenUpdate = PublishSubject.create<Boolean>()

    fun register(): Single<Boolean> {
        if (isRegistered()) {
            return Single.just(true)
        }

        return authRepo.authorize()
            .toSingleDefault(true)
            .onErrorReturnItem(false)
    }

    fun isUserExisted(phone: Phone): Single<Pair<Boolean, Phone>> {
        return authRepo.isPhoneExisted(phone)
    }

    fun authOldUser(): Single<Boolean> {
        if (!isRegistered()) { //maybe need this
            return register()
        }

//        if (isRegistered() && !isTokenExpired()) {
//            return Single.just(true)
//        }

        return authRepo.authorizeWithLoginAndPass()
            .toSingleDefault(true)
            .onErrorReturnItem(false)
    }

    fun recoverUser(phone: Phone): Completable {
        return authRepo.recoverUser(phone).andThen(authRepo.saveUserId())
    }

    fun getNeedTokenUpdate(): Observable<Boolean> {
        return needTokenUpdate
    }

    override fun updateToken() {
        needTokenUpdate.onNext(true)
    }

    private fun isRegistered(): Boolean {
        Log.d("", "isRegistered: ${authSharedPref.token}")
        return authSharedPref.token != null
    }

    private fun isTokenExpired(): Boolean {
        val tokenExpiresAt = authSharedPref.tokenExpiresAt ?: return true
        val millis = tokenExpiresAt.atZone(ZoneId.systemDefault())
            .toInstant().epochSecond
        return millis <= System.currentTimeMillis()
    }
}