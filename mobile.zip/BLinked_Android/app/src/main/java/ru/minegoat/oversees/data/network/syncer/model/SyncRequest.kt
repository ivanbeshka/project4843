package ru.minegoat.oversees.data.network.syncer.model

import com.google.gson.annotations.SerializedName

data class SyncRequest(
    @SerializedName("items")
    val items: List<SyncItemRequest>
)