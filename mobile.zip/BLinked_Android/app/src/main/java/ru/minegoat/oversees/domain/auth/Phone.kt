package ru.minegoat.oversees.domain.auth

import java.util.regex.Pattern

data class Phone(
    val countryCode: String,
    val phonePrefix: String,
    val phone: String
) {

    companion object {
        fun fromSplitString(phone: String): Phone {
            val splitPhone = phone.split(" ")
            return Phone(splitPhone[0], splitPhone[1].removePrefix(PLUS_PREFIX), splitPhone[2])
        }
    }
}

fun Phone.split(): String {
    val cleanPhonePrefix = phonePrefix.removePrefix(PLUS_PREFIX)

    return "$countryCode $cleanPhonePrefix $phone"
}

fun Phone.toNormalize(): String {
    val str = "$phonePrefix$phone".replace(Regex("[^0123456789]"),"")
    return str
}

private const val PLUS_PREFIX = "+"