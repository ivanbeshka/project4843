package ru.minegoat.oversees.data.network.auth.model

import com.google.gson.annotations.SerializedName

data class UserToken(
    @SerializedName("apiToken")
    val token: String
)
