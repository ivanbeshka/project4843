package ru.minegoat.oversees.data.network.skill

import io.reactivex.Single
import retrofit2.http.GET
import ru.minegoat.oversees.data.network.skill.responses.ResponseSkill

interface SkillApi {
    @GET("skills/list")
    fun getSkillsList(): Single<ResponseSkill>
}