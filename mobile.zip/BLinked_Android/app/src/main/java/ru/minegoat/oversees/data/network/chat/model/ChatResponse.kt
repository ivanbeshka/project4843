package ru.minegoat.oversees.data.network.chat.model

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.data.db.chat.ChatRoom
import ru.minegoat.oversees.domain.chat.Chat
import ru.minegoat.oversees.domain.chat.IChatLinkedObj

data class ChatResponse(
    @SerializedName("obj_id")
    val objID: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("owner_id")
    val ownerId: String,
    @SerializedName("members_ids")
    val membersIds: List<String>,
    @SerializedName("linked_obj")
    val linkedObj: ChatLinkedObjResponse,
    @SerializedName("messages_ids")
    val messagesIds: List<String> = listOf(),
    @SerializedName("icon_url")
    val iconUrl: String? = null
)

fun ChatResponse.toRoom(): ChatRoom {
    return ChatRoom(
        objID = objID,
        name = name,
        ownerId = ownerId,
        messagesIds = messagesIds,
        linkedObj = linkedObj.toRoom(),
        membersIds = messagesIds,
        iconUrl = iconUrl
    )
}

fun ChatResponse.toChat(linkedObj: IChatLinkedObj): Chat {
    return Chat(
        objID = objID,
        name = name,
        ownerId = ownerId,
        membersIds = membersIds,
        linkedObj = linkedObj,
        messagesIds = messagesIds,
        iconUrl = iconUrl
    )
}
