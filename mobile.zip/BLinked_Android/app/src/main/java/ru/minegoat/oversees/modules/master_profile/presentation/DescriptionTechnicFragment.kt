package ru.minegoat.oversees.modules.master_profile.presentation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.FragmentDescriptionTechnicBinding

class DescriptionTechnicFragment : Fragment(R.layout.fragment_description_technic) {

    private val binding by viewBinding(FragmentDescriptionTechnicBinding::bind)


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val pagerAdapter = PagerAdapter(childFragmentManager, lifecycle)

    }
}