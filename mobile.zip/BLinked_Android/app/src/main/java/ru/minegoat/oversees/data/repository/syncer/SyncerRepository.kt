package ru.minegoat.oversees.data.repository.syncer

import io.reactivex.Completable
import io.realm.kotlin.types.RealmObject
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SyncerRepository @Inject constructor(private val ds: RealmDataStorage) {

    fun <T : RealmObject> save(items: List<T>): Completable {
        return ds.saveAll(items)
    }
}