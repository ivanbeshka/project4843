package ru.minegoat.oversees.modules.main.di.auth

import javax.inject.Scope

@Scope
annotation class AuthScope
