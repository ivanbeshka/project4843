package ru.minegoat.oversees.modules.trip.di

import javax.inject.Scope

@Scope
annotation class TripScope
