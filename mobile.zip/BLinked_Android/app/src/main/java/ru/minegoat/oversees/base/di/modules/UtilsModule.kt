package ru.minegoat.oversees.base.di.modules

import android.content.Context
import dagger.Module
import dagger.Provides
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import javax.inject.Singleton

@Module
class UtilsModule {

    @Singleton
    @Provides
    fun provideTokenPref(context: Context): AuthSharedPref =
        AuthSharedPref(context)
}