package ru.minegoat.oversees.modules.search.viewmodels

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.base.viewmodels.*
import ru.minegoat.oversees.data.repository.location.LocationRepository
import ru.minegoat.oversees.data.repository.skill.SkillRepository
import ru.minegoat.oversees.data.repository.user.UserRepository
import ru.minegoat.oversees.domain.ShortTrip
import ru.minegoat.oversees.domain.location.Location
import ru.minegoat.oversees.domain.search.SearchForm
import ru.minegoat.oversees.domain.user.ShortUser
import ru.minegoat.oversees.domain.user.Skill
import ru.minegoat.oversees.modules.search.model.FilterType
import ru.minegoat.oversees.modules.search.model.SelectedFilter
import ru.minegoat.oversees.modules.trip.repository.TripRepository
import ru.minegoat.oversees.modules.user_profile.model.ShortMasterUi

class SearchViewModel @AssistedInject constructor(
    private val tripRepository: TripRepository,
    private val locationRepository: LocationRepository,
    private val userRepository: UserRepository,
    private val skillRepository: SkillRepository,
) : RxViewModel() {

    private val tripList = MutableLiveData<ScreenState<List<ShortTrip>>>()
    private val getLocationByIdLiveData = MutableLiveData<ScreenState<Location>>()
    private val mastersList = MutableLiveData<ScreenState<List<ShortUser>>>()
    private val mastersUiList = MutableLiveData<ScreenState<List<ShortMasterUi>>>()
    private val skillsList = MutableLiveData<ScreenState<List<Skill>>>()

    val choosenSkillsList = MutableLiveData<MutableSet<Skill>>()

    private val selectedFilter = MutableLiveData<FilterType>()

    private val selectedSubFilters = MutableLiveData<List<SelectedFilter>>()

    val tripData: LiveData<ScreenState<List<ShortTrip>>> = tripList

    fun getSelectedSubFilters(): LiveData<List<SelectedFilter>> {
        return selectedSubFilters
    }

    fun isSubFilterSelected(selectedSubFilter: SelectedFilter): Boolean {
        selectedSubFilters.value?.let {
            return it.any { filter ->
                filter.filterValue == selectedSubFilter.filterValue
            }
        }
        return false
    }

    fun addSelectedSubFilter(selectedFilter: SelectedFilter) {
        if (selectedSubFilters.value == null) {
            selectedSubFilters.value = mutableListOf(selectedFilter)
        } else {
            val oldValue = selectedSubFilters.value!!.toMutableList()
            oldValue.add(selectedFilter)
            selectedSubFilters.value = oldValue
        }

    }

    fun removeSelectedSubFilter(selectedSubFilter: SelectedFilter) {
        selectedSubFilters.value?.let {
            val oldValue = it.toMutableList()
            oldValue.find { filter ->
                filter.filterValue == selectedSubFilter.filterValue
            }?.let { valueToRemove ->
                oldValue.remove(valueToRemove)
                selectedSubFilters.value = oldValue
            }
        }
    }

    fun setSelectedFilter(filterType: FilterType) {
        selectedFilter.value = filterType
    }

    fun getSelectedFilter(): LiveData<FilterType> {
        return selectedFilter
    }

    fun getLocationById(objID: String): LiveData<ScreenState<Location>> {
        locationRepository.getLocationById(objID)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { getLocationByIdLiveData.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    getLocationByIdLiveData.value = SuccessScreenState(it)
                },
                onError = {
                    getLocationByIdLiveData.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()

        return getLocationByIdLiveData
    }

    fun getShortTripList(objId: String): LiveData<ScreenState<List<ShortTrip>>> {
        tripRepository.getShortTripList(objId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { tripList.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    tripList.value = SuccessScreenState(it)
                },
                onError = {
                    tripList.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish();

        return tripList;
    }

    fun getMastersList(): LiveData<ScreenState<List<ShortUser>>> {
        userRepository.getUsersList()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { mastersList.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    mastersList.value = SuccessScreenState(it)
                },
                onError = {
                    mastersList.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()

        return mastersList
    }

    fun getSkillsList(): LiveData<ScreenState<List<Skill>>> {
        skillRepository.getSkillsList()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { skillsList.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    skillsList.value = SuccessScreenState(it)
                },
                onError = {
                    skillsList.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()

        return skillsList
    }

    fun getSkillsListBySearch(skillName: String): LiveData<ScreenState<List<Skill>>> {
        skillRepository.getSkillsListByPredicate(skillName)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { skillsList.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    skillsList.value = SuccessScreenState(it)
                },
                onError = {
                    skillsList.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()

        return skillsList
    }

    fun convertToShortUserUI(userName: String): LiveData<ScreenState<List<ShortMasterUi>>> {
        userRepository.getMasters(userName)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { mastersUiList.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = { list ->
                    mastersUiList.value = SuccessScreenState(
                        list.map {
                            ShortMasterUi(
                                objID = it.userId,
                                name = it.name,
                                avatarUrl = it.avatar,
                                masterTypes = it.masterTypeId,
                                sumKarma = it.karmaSum
                            )
                        }
                    )
                },
                onError = {
                    mastersUiList.value = ErrorScreenState(it)
                }
            ).disposeOnFinish()
        return mastersUiList
    }

    fun getAllTrips(): LiveData<ScreenState<List<ShortTrip>>> {
        tripRepository.getAllShortTripList()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { tripList.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    tripList.value = SuccessScreenState(it)
                },
                onError = {
                    tripList.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()

        return tripList

    }

    fun sendSearchForm(
        skillIds: List<String>,
        master_types: List<String>? = null,
    ): LiveData<ScreenState<List<ShortTrip>>> {
        tripRepository.sendSearchForm(
            searchForm = SearchForm(
                skills = skillIds,
                masters_types = master_types
            )
        )?.subscribeOn(Schedulers.io())
            ?.observeOn(AndroidSchedulers.mainThread())
            ?.doOnSubscribe { tripList.value = LoadingScreenState() }
            ?.subscribeBy(
                onSuccess = {
                    Log.d("TRIPLOG", it.toString())
                    tripList.value = SuccessScreenState(it)
                },
                onError = {
                    Log.d("TRIPLOG", it.toString())
                    tripList.value = ErrorScreenState(it)
                }
            )?.disposeOnFinish()

        return tripList
    }


    @AssistedFactory
    interface Factory {
        fun create(): SearchViewModel
    }
}