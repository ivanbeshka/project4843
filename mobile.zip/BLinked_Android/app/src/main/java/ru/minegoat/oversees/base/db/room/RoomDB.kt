package ru.minegoat.oversees.base.db.room

import androidx.room.*
import ru.minegoat.oversees.base.db.room.converters.StringListConverter
import ru.minegoat.oversees.data.db.chat.ChatRoom
import ru.minegoat.oversees.data.db.chat.MessageRoom
import ru.minegoat.oversees.data.db.chat.converters.ChatLinkedObjConverter
import ru.minegoat.oversees.data.db.chat.dao.ChatDao
import ru.minegoat.oversees.data.db.chat.dao.MessageDao
import ru.minegoat.oversees.data.db.userProfile.UserRoom
import ru.minegoat.oversees.data.db.userProfile.converters.*
import ru.minegoat.oversees.data.db.userProfile.dao.UserDao

@Database(entities = [ChatRoom::class, MessageRoom::class, UserRoom::class,], version = 4)
@TypeConverters(
    value = [
        ChatLinkedObjConverter::class,
        StringListConverter::class,
        SexConverter::class,
        SocialNetworkConverter::class,
        SkillConverter::class,
        RatingConverter::class,
        KarmaTypeConverter::class]
)
abstract class RoomDB : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun messageDao(): MessageDao
    abstract fun userDao(): UserDao
}

