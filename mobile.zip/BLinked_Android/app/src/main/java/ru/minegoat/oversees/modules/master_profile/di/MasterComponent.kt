package ru.minegoat.oversees.modules.master_profile.di

import dagger.Component
import ru.minegoat.oversees.base.di.AppComponent
import ru.minegoat.oversees.base.di.components.DiComponent
import ru.minegoat.oversees.modules.master_profile.viewmodels.MasterInfoViewModel

@MasterScope
@Component(dependencies = [AppComponent::class], modules = [MasterModule::class])
interface MasterComponent : DiComponent {

    fun masterInfoViewModel(): MasterInfoViewModel.Factory
}