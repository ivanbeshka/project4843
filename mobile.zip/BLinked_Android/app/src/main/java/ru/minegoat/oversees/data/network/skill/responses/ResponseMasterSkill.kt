package ru.minegoat.oversees.data.network.skill.responses

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.user.MasterSkill

data class ResponseMasterSkill(
    @SerializedName("objId")
    val objId: String,
    @SerializedName("experience")
    val experience: String
)

fun ResponseMasterSkill.toMasterSkill() = MasterSkill(this.objId, this.experience)