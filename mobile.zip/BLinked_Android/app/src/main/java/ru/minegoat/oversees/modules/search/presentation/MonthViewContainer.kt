package ru.minegoat.oversees.modules.search.presentation

import android.view.View
import android.view.ViewGroup
import com.kizitonwose.calendar.view.ViewContainer
import ru.minegoat.oversees.databinding.CalendarHeaderBinding
import java.time.DayOfWeek
import java.time.Month
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.*

class MonthViewContainer(view: View) : ViewContainer(view) {
    val textView = CalendarHeaderBinding.bind(view).tvHeaderText
}