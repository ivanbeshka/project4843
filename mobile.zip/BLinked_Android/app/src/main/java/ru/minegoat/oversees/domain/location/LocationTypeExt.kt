package ru.minegoat.oversees.domain.location

import ru.minegoat.oversees.R

fun LocationType.toStringRU(): String {
    when (this) {
        LocationType.COUNTRY -> return "Страна"
        LocationType.CITY -> return "Город"
        LocationType.HOTEL -> return "Отель"
        LocationType.RESTAURANT -> return "Ресторан, кафе"
        LocationType.MUSEUM -> return "Музей"
        LocationType.SPOT -> return "Место (Blink it)"
        LocationType.OTHER -> return "Другое"
        LocationType.AIRPORT -> return "Аэропорт"
        LocationType.RAILWAYSTATION -> return "Ж/Д Вокзал"
        LocationType.BUSSTATION -> return "Автовокзал"
        LocationType.PORT -> return "Порт"
        LocationType.CAMPING -> return "Кэмпинг"
        LocationType.BAR -> return "Бар"
        LocationType.NIGHTCLUB -> return "Ночной клуб"
        LocationType.AMUSEMENTPARK -> return "Парк развлечений"
        LocationType.AQUARIUM -> return "Океанариум"
        LocationType.ARTGALLERY -> return "Галерея"
        LocationType.BOWLING -> return "Боулинг"
        LocationType.CINEMA -> return "Кино"
        LocationType.THEATRE -> return "Театр"
        LocationType.ZOO -> return "Зоопарк"
        LocationType.PARK -> return "Парк"
        LocationType.SPA -> return "Спа, красота"
        LocationType.STADIUM -> return "Стадион"
        LocationType.PLAYGROUND -> return "Детская площадка"
        LocationType.ATTRACTION -> return "Достопримечательность"
        LocationType.CASINO -> return "Казино"
        LocationType.CHURCH -> return "Религиозное место"
        LocationType.GYM -> return "Спортзал"
        LocationType.STORE -> return "Магазины"
        LocationType.DRUGSTORE -> return "Аптека"
        LocationType.RENT -> return "Аренда"
        LocationType.PARKING -> return "Парковка"
        LocationType.SERVICE -> return "Услуги"
        LocationType.GASSTATION -> return "Заправка"
        LocationType.PUBLICSTATION -> return "Метро"
        LocationType.BANK -> return "Банк"
        LocationType.ADDRESS -> return "Адрес"
        LocationType.TRAVEL -> return "Турагентство"
    }
}

fun LocationType.marker(): Int {
    when (this) {
        LocationType.COUNTRY -> return R.drawable.mark_city
        LocationType.CITY -> return R.drawable.mark_city
        LocationType.HOTEL -> return R.drawable.mark_hotel
        LocationType.RESTAURANT -> return R.drawable.mark_restaurant
        LocationType.MUSEUM -> return R.drawable.mark_museum
        LocationType.SPOT -> return R.drawable.mark_spot
        LocationType.OTHER -> return R.drawable.mark_other
        LocationType.AIRPORT -> return R.drawable.mark_airport
        LocationType.RAILWAYSTATION -> return R.drawable.mark_railway_station
        LocationType.BUSSTATION -> return R.drawable.mark_bus_station
        LocationType.PORT -> return R.drawable.mark_port
        LocationType.CAMPING -> return R.drawable.mark_camping
        LocationType.BAR -> return R.drawable.mark_bar
        LocationType.NIGHTCLUB -> return R.drawable.mark_night_club
        LocationType.AMUSEMENTPARK -> return R.drawable.mark_amusement_park
        LocationType.AQUARIUM -> return R.drawable.mark_aquarium
        LocationType.ARTGALLERY -> return R.drawable.mark_art_gallery
        LocationType.BOWLING -> return R.drawable.mark_bowling
        LocationType.CINEMA -> return R.drawable.mark_cinema
        LocationType.THEATRE -> return R.drawable.mark_theatre
        LocationType.ZOO -> return R.drawable.mark_zoo
        LocationType.PARK -> return R.drawable.mark_park
        LocationType.SPA -> return R.drawable.mark_spot
        LocationType.STADIUM -> return R.drawable.mark_stadium
        LocationType.PLAYGROUND -> return R.drawable.mark_playground
        LocationType.ATTRACTION -> return R.drawable.mark_attraction
        LocationType.CASINO -> return R.drawable.mark_casino
        LocationType.CHURCH -> return R.drawable.mark_church
        LocationType.GYM -> return R.drawable.mark_gym
        LocationType.STORE -> return R.drawable.mark_store
        LocationType.DRUGSTORE -> return R.drawable.mark_drugstore
        LocationType.RENT -> return R.drawable.mark_rent
        LocationType.PARKING -> return R.drawable.mark_parking
        LocationType.SERVICE -> return R.drawable.mark_service
        LocationType.GASSTATION -> return R.drawable.mark_gas_station
        LocationType.PUBLICSTATION -> return R.drawable.mark_railway_station //todo
        LocationType.BANK -> return R.drawable.mark_bank
        LocationType.ADDRESS -> return R.drawable.mark_address
        LocationType.TRAVEL -> return R.drawable.mark_travel
    }
}