package ru.minegoat.oversees.data.network.syncer

import io.reactivex.Single
import retrofit2.http.Body
import retrofit2.http.POST
import ru.minegoat.oversees.data.network.syncer.model.SyncResponse
import ru.minegoat.oversees.data.network.syncer.model.SyncRequest

interface SyncerApi {

    @POST("sync")
    fun sync(@Body syncRequest: SyncRequest): Single<SyncResponse>
}