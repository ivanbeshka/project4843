package ru.minegoat.oversees.modules.user_profile.presentation

import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.databinding.BottomSheetCheckPhoneNumBinding
import ru.minegoat.oversees.domain.user.CountryPhone
import ru.minegoat.oversees.modules.user_profile.di.UserProfileComponentHolder

class BottomSheetCheckPhoneNum : BottomSheetDialogFragment(R.layout.bottom_sheet_check_phone_num) {

    private val binding by viewBinding(BottomSheetCheckPhoneNumBinding::bind)

    private val onItemClick: BottomSheetCheckPhoneNumAdapter.OnItemClick =
        object : BottomSheetCheckPhoneNumAdapter.OnItemClick {
            override fun setPhoneNum(countryPhone: CountryPhone) {
                setResultAndExit(countryPhone)
            }
        }

    private val component by featureComponent(UserProfileComponentHolder)

    private val viewModel by lazyViewModel {
        component.checkPhoneNumBottomSheetViewModel().create()
    }

    private val adapter = BottomSheetCheckPhoneNumAdapter(onItemClick)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.recyclerView.also {
            it.layoutManager = LinearLayoutManager(requireContext())
            it.adapter = adapter
        }
        adapter.differ.submitList(emptyList())
        binding.etFindCountry.doOnTextChanged { text, _, _, _ ->
            viewModel.filterCountries(text.toString())
        }
        viewModel.filterCountries("")
        viewModel.countryPhones.observe(viewLifecycleOwner) {
            adapter.data = it
        }
    }

    private fun setResultAndExit(countryPhone: CountryPhone) {
        setFragmentResult(
            REQUEST_ACTION_KEY,
            bundleOf(
                ACTION_COUNTRY_NAME_KEY to countryPhone.countryName,
                ACTION_COUNTRY_PHONE_KEY to countryPhone.phonePrefix,
                ACTION_COUNTRY_CODE_KEY to countryPhone.countryCode.name
            )
        )
        findNavController().navigateUp()
    }

    companion object {
        const val REQUEST_ACTION_KEY = "BottomSheetCheckPhone_request_action"
        const val ACTION_COUNTRY_NAME_KEY = "BottomSheetCheckPhone_action_country_name_key"
        const val ACTION_COUNTRY_PHONE_KEY = "UserAccountFragment_action_country_phone_key"
        const val ACTION_COUNTRY_CODE_KEY = "UserAccountFragment_action_country_code_key"
    }
}