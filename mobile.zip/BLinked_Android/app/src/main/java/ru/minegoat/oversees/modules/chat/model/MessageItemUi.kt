package ru.minegoat.oversees.modules.chat.model

import ru.minegoat.oversees.modules.chat.presentation.MessageListAdapter

abstract class MessageItemUi(
    open val id: String,
    open val type: MessageListAdapter.MessageItemType
)