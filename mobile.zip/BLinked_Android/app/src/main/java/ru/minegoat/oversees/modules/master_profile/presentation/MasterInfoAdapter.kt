package ru.minegoat.oversees.modules.master_profile.presentation

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import io.reactivex.disposables.CompositeDisposable
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.ItemMasterInfoBinding
import ru.minegoat.oversees.domain.master.MasterType

class MasterInfoAdapter(
    private val listener: OnCLickListener,
) : RecyclerView.Adapter<MasterInfoAdapter.MasterPathViewHolder>() {

    interface OnCLickListener {
        fun onMasterTypeTagSelect(masterType: MasterType)
    }

    private val differCallback = object : DiffUtil.ItemCallback<MasterType>() {
        override fun areItemsTheSame(oldItem: MasterType, newItem: MasterType): Boolean =
            oldItem.objID == newItem.objID

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: MasterType, newItem: MasterType): Boolean =
            oldItem.name == newItem.name
    }

    val differ = AsyncListDiffer(this, differCallback)

    var data: List<MasterType>
        get() = differ.currentList
        set(value) = differ.submitList(value)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MasterPathViewHolder =
        MasterPathViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.item_master_info, parent, false)
        )

    override fun getItemCount(): Int = data.size

    override fun onBindViewHolder(holder: MasterPathViewHolder, position: Int) =
        holder.bind(data[position])


    inner class MasterPathViewHolder(root: View) : RecyclerView.ViewHolder(root) {

        private val binding by viewBinding(ItemMasterInfoBinding::bind)

        fun bind(masterType: MasterType) = with(binding) {
            itemTextView.text = masterType.name
            itemContainer.setOnClickListener {
                listener.onMasterTypeTagSelect(masterType)
            }
        }
    }
}