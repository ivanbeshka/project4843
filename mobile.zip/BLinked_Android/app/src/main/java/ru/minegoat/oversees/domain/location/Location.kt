package ru.minegoat.oversees.domain.location

import com.google.android.gms.maps.model.LatLng
import ru.minegoat.oversees.data.db.location.LocationRealm
import java.util.*

//TODO
data class Location(
    val objID: String,
    val name: String? = null,
    val internationalName: String? = null,
    val latLng: LatLng? = null,
    val type: LocationType? = null,
    val descriptionLocation: String? = null,
    val cityLocation: Location? = null,
    val countryLocation: Location? = null,
    val timeZone: TimeZone? = null,
    val codeIATA: String? = null, //for airport
    val address: String? = null,
    val internationalAddress: String? = null,
    val phoneNumber: String? = null,
    val website: String? = null,
    val countryCode: String? = null,
    val externalID: String? = null,
    val ownerID: String? = null,
    val isUsing: Boolean = false,
    val wildCity: Boolean = false,
)

fun Location.toLocationRealm(): LocationRealm {
    return LocationRealm(
        objID = objID,
        name = name,
        latitude = latLng?.latitude,
        longitude = latLng?.longitude,
        type = type,
        descriptionLocation = descriptionLocation,
//        cityLocationRealm = cityLocation?.toLocationRealm(),
//        countryLocationRealm = countryLocation?.toLocationRealm(),
        timeZoneIdentifier = timeZone?.id,
        codeIATA = codeIATA,
        countryCode = countryCode,
        externalID = externalID,
        address = address,
        phoneNumber = phoneNumber,
        website = website,
        internationalName = internationalName,
        internationalAddress = internationalAddress,
        ownerID = ownerID,
        isUsing = isUsing,
        wildCity = wildCity,
    )
}