package ru.minegoat.oversees.modules.user_profile.presentation

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import android.view.ViewGroup
import android.view.Window
import androidx.core.os.bundleOf
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.showToast
import ru.minegoat.oversees.databinding.DialogChooseSexBinding
import ru.minegoat.oversees.domain.user.Sex

class ChooseSexFragment : DialogFragment(R.layout.dialog_choose_sex) {

    private val binding by viewBinding(DialogChooseSexBinding::bind)

    private val args: ChooseSexFragmentArgs by navArgs()
    private val sex by lazy { args.sex }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        if (dialog != null && dialog?.window != null) {
            dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog?.window?.requestFeature(Window.FEATURE_NO_TITLE)
        }

        return super.onCreateView(inflater, container, savedInstanceState)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val allStates = listOf(binding.tvSexMan, binding.tvSexWoman, binding.tvSexUndefined)

        allStates.forEach {
            if (it.text.toString() == getString(sex.res)) {
                it.isSelected = true
            }
        }

        val clickListener = OnClickListener {
            allStates.forEach { state ->
                if (state != it) {
                    state.isSelected = false
                }
            }
            it.isSelected = true
        }

        allStates.forEach { it.setOnClickListener(clickListener) }

        binding.btnOk.setOnClickListener {
            val selectedSex = allStates.find { it.isSelected }?.text
            if (selectedSex != null) {
                setFragmentResult(
                    SEX_RESULT_KEY,
                    bundleOf(
                        SEX_BUNDLE_KEY to Sex.fromStringByRes(
                            selectedSex.toString(),
                            requireContext()
                        ).ordinal
                    )
                )
                findNavController().navigateUp()

            } else {
                showToast(R.string.oops_something_went_wrong)
            }
        }
    }

    companion object {
        const val SEX_RESULT_KEY = "sex_result"
        const val SEX_BUNDLE_KEY = "sex_bundle"
    }
}