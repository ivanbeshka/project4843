package ru.minegoat.oversees.modules.chat.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import androidx.paging.*
import androidx.paging.rxjava2.cachedIn
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.Flowable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import io.realm.kotlin.types.ObjectId
import kotlinx.coroutines.ExperimentalCoroutinesApi
import ru.minegoat.oversees.base.utils.DateUtils
import ru.minegoat.oversees.base.viewmodels.*
import ru.minegoat.oversees.domain.trip.Trip
import ru.minegoat.oversees.domain.chat.Chat
import ru.minegoat.oversees.domain.chat.toMessageUi
import ru.minegoat.oversees.modules.chat.model.MessageDateUi
import ru.minegoat.oversees.modules.chat.model.MessageItemUi
import ru.minegoat.oversees.modules.chat.repository.ChatRepository
import java.util.*
import java.util.concurrent.TimeUnit

class ChatViewModel @AssistedInject constructor(
    private val repo: ChatRepository,
) : RxViewModel() {

    private val setupNewChat = MutableLiveData<ScreenState<Boolean>>()
    private val chat = MutableLiveData<ScreenState<Chat>>(
        SuccessScreenState(
            Chat(
                "qwwqwqwwqw",
                "Чат для путешествия!",
                "fksdjfsdjflksdfj",
                listOf("fksdjfsdjflksdfj", "fksdjfsdj"),
                Trip(
                    "trip_obj_id",
                    startDate = 4832480923409,
                    endDate = 5573749832723,
                    name = "Trip",
                    mainImage = "https://klike.net/uploads/posts/2020-05/1588837021_5.jpg"
                ),
                iconUrl = "https://klike.net/uploads/posts/2020-05/1588837021_5.jpg"
            ))
    )
    private val sendMsgLiveData = MutableLiveData<ScreenState<Boolean>>()
    private val readMsgLiveData = MutableLiveData<ScreenState<Boolean>>()

    fun subscribeOnNewMessages(chatId: String) {
        repo.subscribeOnNewMessages(chatId)
            .disposeOnFinish()
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    fun getMessages(chatId: String): Flowable<PagingData<MessageItemUi>> {
        return repo.getMessagesPagingData(
            chatId,
            PagingConfig(
                20,
                5,
                false,
                40,
                30
            )
        )
        .map { pagingData ->
            pagingData.map {
                it.toMessageUi("")
            }
        }
        .map {
            it.insertSeparators { after, before ->

                //this fine
                val afterDate = before?.dateTimeSec
                val beforeDate = after?.dateTimeSec

                val isDateChanged = (afterDate != null && beforeDate != null)
                        && TimeUnit.SECONDS.toDays(afterDate) < TimeUnit.SECONDS.toDays(beforeDate)
                val isFirstDate = afterDate == null && beforeDate != null

                if (isDateChanged || isFirstDate) {
                    val dateText = DateUtils.getDateForChat(beforeDate!!)
                    MessageDateUi(ObjectId.create().toString(), dateText)
                } else {
                    null
                }
            }
        }
        .cachedIn(viewModelScope)
    }

    fun setupNewChat(chatId: String): LiveData<ScreenState<Boolean>> {
        repo.setupNewChat(chatId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { setupNewChat.value = LoadingScreenState() }
            .subscribeBy(
                onComplete = {
                    setupNewChat.value = SuccessScreenState(true)
                },
                onError = {
                    setupNewChat.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()

        return setupNewChat
    }

    fun getChat(chatId: String): LiveData<ScreenState<Chat>> {
//        repo.getChat(chatId)
//            .subscribeOn(Schedulers.io())
//            .observeOn(AndroidSchedulers.mainThread())
//            .doOnSubscribe { chat.value = LoadingScreenState() }
//            .subscribeBy(
//                onNext = {
//                    chat.value = SuccessScreenState(it)
//                },
//                onError = {
//                    chat.value = ErrorScreenState(it)
//                }
//            )
//            .disposeOnFinish()

        return chat
    }

    fun sendMsg(text: String, chatId: String): LiveData<ScreenState<Boolean>> {
        val msg = ru.minegoat.oversees.domain.chat.Message(ObjectId.create().toString(),"userID","userName",chatId, text,System.currentTimeMillis() / 1000,null)
        repo.sendMessage(msg).subscribe()
        return sendMsgLiveData
    }

    fun readMsg(messageId: String): LiveData<ScreenState<Boolean>> {
        repo.readMessage(messageId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { readMsgLiveData.value = LoadingScreenState() }
            .subscribeBy(
                onComplete = {
                    readMsgLiveData.value = SuccessScreenState(true)
                },
                onError = {
                    readMsgLiveData.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()

        return readMsgLiveData
    }

    @AssistedFactory
    interface Factory {
        fun create(): ChatViewModel
    }
}