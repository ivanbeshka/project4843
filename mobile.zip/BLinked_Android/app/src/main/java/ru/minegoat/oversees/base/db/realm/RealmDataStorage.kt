package ru.minegoat.oversees.base.db.realm

import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.Single
import io.realm.kotlin.MutableRealm
import io.realm.kotlin.Realm
import io.realm.kotlin.UpdatePolicy
import io.realm.kotlin.delete
import io.realm.kotlin.query.RealmQuery
import io.realm.kotlin.types.RealmObject
import ru.minegoat.oversees.base.utils.rx.createCompletableWithBodyForRealm
import kotlin.reflect.KClass

// TODO extends DataStorage
class RealmDataStorage(private val realm: Realm) {

    fun <T : RealmObject> create(model: T): Single<T> {
        return Single.create { emitter ->
            realm.writeBlocking {
                try {
                    val obj = copyToRealm(model, UpdatePolicy.ALL)
                    emitter.onSuccess(obj)
                } catch (e: Exception) {
                    emitter.onError(e)
                }
            }
        }
    }

    fun <T : RealmObject> save(obj: T): Completable {
        return createCompletableWithBodyForRealm(realm) {
            it.copyToRealm(obj, UpdatePolicy.ALL)
        }
    }

    fun <T : RealmObject> saveAll(objs: List<T>): Completable {
        return createCompletableWithBodyForRealm(realm) {
            for (obj in objs) {
                it.copyToRealm(obj, UpdatePolicy.ALL)
            }
        }
    }

    fun <T : RealmObject> update(obj: T): Completable {
        return createCompletableWithBodyForRealm(realm) {
            it.copyToRealm(obj, UpdatePolicy.ALL)
        }
    }

    fun update(block: (MutableRealm) -> Void): Completable {
        return createCompletableWithBodyForRealm(realm) {
            block(it)
        }
    }

    fun <T : RealmObject> delete(obj: T): Completable {
        return createCompletableWithBodyForRealm(realm) {
            it.delete(obj)
        }
    }

    fun <T : RealmObject> deleteArray(objs: List<T>, withWaiting: Boolean): Completable {
        return createCompletableWithBodyForRealm(realm) {
            for (obj in objs) {
                it.delete(obj)
            }
        }
    }

    fun <T : RealmObject> deleteAll(model: KClass<T>): Completable {
        return createCompletableWithBodyForRealm(realm) {
            it.delete(model)
        }
    }

    fun <T : RealmObject> getById(
        model: KClass<T>,
        id: String
    ): Maybe<T> {
        val dbPredicate = "$OBJ_ID_PREDICATE oid($id)"
        return fetch(model, dbPredicate)
            .map { it.first() }
            .toMaybe()
    }

    fun <T : RealmObject> fetch(
        model: KClass<T>,
        predicate: String? = null,
        sorted: Sorted? = null
    ): Single<List<T>> {
        return Single.create { emitter ->
            realm.writeBlocking {
                try {
                    var queryChain = query(model)

                    predicate?.let {
                        queryChain = queryChain.query(it)
                    }
                    sorted?.let {
                        queryChain = queryChain.sort(it.key, it.ascending)
                    }

                    val results = queryChain.find().toList()

                    if (results.isNotEmpty()) {
                        emitter.onSuccess(results)
                    } else {
                        emitter.onError(Exception("Not found results"))
                    }
                } catch (e: Exception) {
                    emitter.onError(e)
                }
            }
        }
    }

    private companion object {
        private const val OBJ_ID_PREDICATE = "id =="
    }
}