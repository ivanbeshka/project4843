package ru.minegoat.oversees.modules.search.presentation

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import ru.minegoat.oversees.base.utils.DateUtils
import ru.minegoat.oversees.databinding.ItemEventNewBinding
import ru.minegoat.oversees.domain.ShortTrip

class SearchTripAdapter() : RecyclerView.Adapter<SearchTripAdapter.ViewHolder>() {

    private val differ = AsyncListDiffer(this, TripDiffUtilCallback())
    var data: List<ShortTrip>
        get() = differ.currentList
        set(value) = differ.submitList(value)

    inner class ViewHolder(val binding: ItemEventNewBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val trip = data[position]
        holder.binding.trip = trip
        holder.binding.apply {
            tvEventName.text = trip.name
            tvEventType.text = trip.shortMilestones!![0].type
            tvEventPrice.text = trip.cost
            if (trip.startDate != null && trip.endDate != null) {
                val startDate = if (DateUtils.getDateBySeconds(trip.startDate).substring(6, 10)
                        .toInt() < DateUtils.getDateBySeconds(trip.endDate).substring(6, 10)
                        .toInt()
                ) {
                    DateUtils.getDateBySecondsWithMonth(trip.startDate) + " " + DateUtils.getDateBySeconds(
                        trip.startDate
                    ).substring(6, 10).toInt()
                } else {
                    DateUtils.getDateBySecondsWithMonth(trip.startDate)
                }

                val endDate = DateUtils.getDateBySecondsWithMonth(trip.endDate) + " " + DateUtils.getDateBySeconds(
                    trip.endDate
                ).substring(6, 10).toInt()

                val evDate = "$startDate - $endDate"

                tvEventDate.text = evDate
            }
        }
    }
//        data[position].mainImage?.let { loadImageFromOurApi(holder.binding.ivEventImage, it) }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemEventNewBinding.inflate(inflater, parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    private class TripDiffUtilCallback : DiffUtil.ItemCallback<ShortTrip>() {
        override fun areItemsTheSame(oldItem: ShortTrip, newItem: ShortTrip): Boolean {
            return oldItem.objId == newItem.objId
        }

        override fun areContentsTheSame(oldItem: ShortTrip, newItem: ShortTrip): Boolean {
            return oldItem == newItem
        }
    }
}