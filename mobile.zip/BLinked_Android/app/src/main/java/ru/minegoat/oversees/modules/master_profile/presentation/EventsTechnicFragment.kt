package ru.minegoat.oversees.modules.master_profile.presentation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.FragmentEventsTechnicBinding

class EventsTechnicFragment : Fragment(R.layout.fragment_events_technic) {

    private val binding by viewBinding(FragmentEventsTechnicBinding::bind)
    private lateinit var recyclerview: RecyclerView
    private var adapter: RecyclerView.Adapter<MastersAdapter.MainViewHolder>? = null

    override fun onViewCreated(itemView: View, savedInstanceState: Bundle?) {
        super.onViewCreated(itemView, savedInstanceState)
        binding.rvEventsTechnic.apply {
            // set a LinearLayoutManager to handle Android
            // RecyclerView behavior
            // set the custom adapter to the RecyclerView
            adapter = EventsTechnicAdapter()
        }
    }
}