package ru.minegoat.oversees.data.repository.location

import io.reactivex.Maybe
import io.reactivex.Single
import io.realm.kotlin.query.Sort
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import ru.minegoat.oversees.base.db.realm.Sorted
import ru.minegoat.oversees.data.db.document.DocumentRealm
import ru.minegoat.oversees.data.db.document.toDocument
import ru.minegoat.oversees.data.db.location.LocationRealm
import ru.minegoat.oversees.data.db.location.toLocation
import ru.minegoat.oversees.data.repository.document.DocumentRepository
import ru.minegoat.oversees.domain.location.Location
import ru.minegoat.oversees.domain.location.LocationType
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LocationRepository @Inject constructor(private val ds: RealmDataStorage) {

    fun getUsedLocations(): Single<List<Location>> {
        return ds.fetch(LocationRealm::class, IS_USING_PREDICATE)
            .map { locationsRealm ->
                locationsRealm.map { it.toLocation() }
            }
    }

    fun getLocationsWithPredicate(namePredicate: String, isUsing: Boolean): Single<List<Location>> {
        val dbPredicate = if (isUsing) {
            "$NAME_PREDICATE '$namePredicate' $AND $IS_USING_PREDICATE"
        } else {
            "$NAME_PREDICATE '$namePredicate'"
        }

        if (namePredicate.isBlank()) {
            return Single.just(listOf())
        }
        return ds.fetch(LocationRealm::class, dbPredicate)
            .map { locationsRealm ->
                locationsRealm.map { it.toLocation() }
            }
    }

    fun getLocationById(objID: String): Maybe<Location> {
        return ds.getById(LocationRealm::class, objID)
            .map { locationRealm ->
                locationRealm.toLocation()
            }
    }

    fun getAllLocationRealmData() = ds.fetch(LocationRealm::class)

    fun getPhoneNumbers(): Single<List<Location>> =
        ds.fetch(LocationRealm::class, COUNTRY_PREDICATE, Sorted("name", Sort.ASCENDING))
            .flattenAsFlowable {
                it
            }
            .map {
                it.toLocation()
            }
            .toList()

    private companion object {
        private val COUNTRY_PREDICATE = "_type = \'${LocationType.COUNTRY}\'"
        private const val IS_USING_PREDICATE = "isUsing == true"
        private const val NAME_PREDICATE = "name CONTAINS[c]"
        private const val AND = "AND"
    }
}
