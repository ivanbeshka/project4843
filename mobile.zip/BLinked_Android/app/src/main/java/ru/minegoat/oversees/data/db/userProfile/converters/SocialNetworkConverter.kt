package ru.minegoat.oversees.data.db.userProfile.converters

import androidx.room.ProvidedTypeConverter
import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import ru.minegoat.oversees.domain.user.SocialNetwork
import java.lang.reflect.Type
import java.util.*


@ProvidedTypeConverter
class SocialNetworkConverter {

    var gson = Gson()

    @TypeConverter
    fun toList(data: String?): MutableList<SocialNetwork?>? {
        if (data == null) {
            return Collections.emptyList()
        }
        val listType: Type = object : TypeToken<MutableList<SocialNetwork?>?>() {}.type
        return gson.fromJson<MutableList<SocialNetwork?>>(data, listType)
    }

    @TypeConverter
    fun toString(someObjects: MutableList<SocialNetwork?>?): String? {
        return gson.toJson(someObjects)
    }
}