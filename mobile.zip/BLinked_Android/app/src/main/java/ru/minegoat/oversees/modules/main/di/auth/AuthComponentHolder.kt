package ru.minegoat.oversees.modules.main.di.auth

import ru.minegoat.oversees.App
import ru.minegoat.oversees.base.di.holders.FeatureComponentHolder

object AuthComponentHolder : FeatureComponentHolder<AuthComponent>() {
    override fun build(): AuthComponent {
        return DaggerAuthComponent.builder()
            .appComponent(App.component)
            .build()
    }
}