package ru.minegoat.oversees.modules.search.presentation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.navigation.fragment.findNavController
import androidx.viewpager2.adapter.FragmentStateAdapter
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.tabs.TabLayoutMediator
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.FragmentChooseSearchBinding


class ChooseSearchFragment : Fragment(R.layout.fragment_choose_search) {
    private val binding by viewBinding(FragmentChooseSearchBinding::bind)


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tbSearch.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
        initVP()
        initTL()

    }

    private fun initVP() {
        binding.vpSearch.adapter = SearchVPAdapter(
            this@ChooseSearchFragment.childFragmentManager,
            this@ChooseSearchFragment.lifecycle
        )
    }

    private fun initTL() {
        TabLayoutMediator(binding.tabSearch, binding.vpSearch) { tab, position ->
            when (position) {
                0 -> tab.text = getString(R.string.for_technic)
                1 -> tab.text = getString(R.string.for_masters)
            }
        }.attach()
    }


    private inner class SearchVPAdapter(fm: FragmentManager, lifecycle: Lifecycle) :
        FragmentStateAdapter(fm, lifecycle) {

        override fun createFragment(position: Int) =
            when (SearchType.values()[position]) {
                SearchType.TECHIC -> {
                    SearchSkillsFragment.newInstance(SearchType.TECHIC)
                }
                SearchType.MASTERS -> {
                    SearchMastersFragment.newInstance(SearchType.MASTERS)
                }
            }

        override fun getItemCount(): Int = SearchType.values().size
    }
}