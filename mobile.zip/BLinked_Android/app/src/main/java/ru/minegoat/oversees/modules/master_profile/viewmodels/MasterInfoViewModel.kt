package ru.minegoat.oversees.modules.master_profile.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.base.viewmodels.*
import ru.minegoat.oversees.data.db.master.toRequestMasterInfo
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import ru.minegoat.oversees.domain.master.MasterInfo
import ru.minegoat.oversees.domain.master.MasterType
import ru.minegoat.oversees.domain.master.toMasterInfoRealm
import ru.minegoat.oversees.modules.master_profile.repository.MasterInfoRepository
import ru.minegoat.oversees.modules.user_profile.network.UserProfileApi

class MasterInfoViewModel @AssistedInject constructor(
    private var authSharePrefs: AuthSharedPref,
    private val masterInfoRepository: MasterInfoRepository,
    private val userProfileApi: UserProfileApi
) : RxViewModel() {

    private val _masterInfo = MutableLiveData<MasterInfo>()
    val masterInfo: LiveData<MasterInfo> get() = _masterInfo

    private val _isSaved = MutableLiveData<ScreenState<Boolean>>()
    val isSaved: LiveData<ScreenState<Boolean>> get() = _isSaved

    private val _isLoaded = MutableLiveData<ScreenState<Boolean>>()
    val isLoaded: LiveData<ScreenState<Boolean>> get() = _isLoaded

    private lateinit var masterTypeListData: MutableList<MasterType>
    private val _masterTypeList = MutableLiveData<List<MasterType>>()
    val masterTypeList: LiveData<List<MasterType>> get() = _masterTypeList


    val userId get() = authSharePrefs.userId

    init {
        userId?.run { getByUserID(this) }
        getMasterTypes()
    }

    fun getByUserID(userID: String) {
        masterInfoRepository.getMasterInfoByUserId(userID)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { _isSaved.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    _masterInfo.postValue(it)
                    _isLoaded.postValue(SuccessScreenState(true))
                },
                onError = {
                    _isLoaded.postValue(ErrorScreenState(it))
                    _masterInfo.postValue(
                        MasterInfo(
                            objId = "",
                            masterTypes = listOf(),
                            path = "",
                            masterId = userID
                        )
                    )
                }
            ).disposeOnFinish()
    }

    fun getMasterTypes() {
//        masterTypeListData = masterTypeDemo
        masterInfoRepository.getMasterTypes().subscribeBy(
            onSuccess = {
                masterTypeListData = it.map { masterType ->
                    MasterType(masterType.objID, masterType.name.lowercase(), masterType.masterTypeDescription)
                }.toMutableList()
            },
            onError = {
                masterTypeListData = mutableListOf()
            }
        ).disposeOnFinish()
    }


    fun getMasterTypes(name: String) {
        _masterTypeList.postValue(masterTypeListData.filter { it.name.startsWith(name, true) })
    }

    fun addMasterType(masterType: MasterType) {
        _masterInfo.value?.run {
            this@MasterInfoViewModel.masterInfo.value?.run {
                val masterInfo = MasterInfo(
                    objId = this.objId,
                    masterTypes = this.masterTypes.toMutableList().apply { add(masterType) },
                    path = this.path,
                    masterId = this.masterId
                )
                _masterInfo.postValue(masterInfo)
            }
        }
    }

    fun removeMasterType(name: String) {
        _masterInfo.value?.run {
            userId?.let {
                this@MasterInfoViewModel.masterInfo.value?.run {
                    val masterInfo = MasterInfo(
                        objId = this.objId,
                        masterTypes = this.masterTypes.toMutableList().apply {
                            for (i in this.count() - 1 downTo 0) {
                                if (this[i].name == name) {
                                    this.removeAt(i)
                                    break
                                }
                            }
                        },
                        path = this.path,
                        masterId = it
                    )
                    _masterInfo.postValue(masterInfo)
                }
            }
        }
    }

    fun setNewData(
        path: String? = null,
        masterTypes: List<MasterType>? = null
    ) {
        if (masterInfo.value == null) {
            _masterInfo.value = MasterInfo()
        }

        val oldInfo = masterInfo.value

        oldInfo?.copy(
            path = path ?: oldInfo.path,
            masterTypes = masterTypes ?: oldInfo.masterTypes
        )?.let {
            _masterInfo.value = it
        }
    }

    fun saveMasterInfo(description: String) {
        masterInfo.value?.run {
            val newMasterInfo = MasterInfo(
                objId = this.objId,
                masterTypes = this.masterTypes,
                path = description,
                masterId = this.masterId
            )
            val masterInfoRealm = newMasterInfo.toMasterInfoRealm()
            userProfileApi.updateMasterInfo(masterInfoRealm.toRequestMasterInfo()).subscribeBy(
                onComplete = {
                    masterInfoRepository.saveMasterInfo(newMasterInfo)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribeBy(
                            onComplete = {
                                _isSaved.postValue(SuccessScreenState(true))
                            },
                            onError = {
                                _isSaved.postValue(ErrorScreenState(it))
                            }
                        ).disposeOnFinish()
                },
                onError = {}
            ).disposeOnFinish()

        }

    }

    @AssistedFactory
    interface Factory {
        fun create(): MasterInfoViewModel
    }
}

val demoMasterInfo = MasterInfo(
    "",
    emptyList(),
    "", ""
)