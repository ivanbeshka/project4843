package ru.minegoat.oversees.modules.master_profile.presentation

import android.graphics.PorterDuff
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.chip.Chip
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.ui.LikeClickHandler
import ru.minegoat.oversees.databinding.ItemEventNewBinding

class EventsAdapter(private val type: EventType, private val isHorizontal: Boolean = false) :
    RecyclerView.Adapter<EventsAdapter.ViewHolder>() {

    inner class ViewHolder(root: View) : RecyclerView.ViewHolder(root) {
        private val binding by viewBinding(ItemEventNewBinding::bind)

        fun bind(position: Int) {
//            if (isHorizontal) {
//                binding.itemEventNew.layoutParams.width =
//                    binding.root.resources.getDimensionPixelOffset(R.dimen.event_width)
//            }
            binding.viewLike.likeHandler = LikeClickHandler()
            if (type == EventType.PAST) {

                binding.cgEventTags.removeAllViews()
                val inflater = LayoutInflater.from(binding.cgEventTags.context)
                val endedChip =
                    inflater.inflate(R.layout.view_chip_disable, binding.cgEventTags, false) as Chip
                endedChip.text = "Завершено"

                binding.cgEventTags.addView(endedChip)

                binding.ivEventImage.setColorFilter(
                    binding.root.context.getColor(R.color.tint_image_disabled),
                    PorterDuff.Mode.MULTIPLY
                )

                binding.viewLike.containerLike.isVisible = false

                val textSecondaryColor = binding.root.context.getColor(R.color.text_secondary)
                binding.tvEventName.setTextColor(textSecondaryColor)
                binding.tvEventType.setTextColor(textSecondaryColor)
                binding.tvEventPrice.setTextColor(textSecondaryColor)

                val gray40 = binding.root.context.getColor(R.color.gray_40)
                binding.ivCalendar.setColorFilter(gray40)
                binding.ivLocation.setColorFilter(gray40)
                binding.mastersImageView.setColorFilter(gray40)


                if (position == 2) {
                    binding.tvEventName.text = "Путешествие на горный Алтай оооооооочень длинное"
                }
            }

            repeat(position) {
                binding.fblEventHashtags.addView(
                    TextView(binding.root.context).apply {
                        text = "#йога"
                        setTextAppearance(R.style.Subtitle_S)
                        setTextColor(context.getColor(R.color.primary_100))

                    },
                    ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                )
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val root = inflater.inflate(R.layout.item_event_new, parent, false)
        return ViewHolder(root)
    }

    override fun getItemCount(): Int {
        return 6
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(position)
    }
}