package ru.minegoat.oversees.data.repository.user

import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.Single
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import ru.minegoat.oversees.data.db.userProfile.RequestToMasterStatusModel
import ru.minegoat.oversees.data.db.userProfile.toRequestMasterStatus
import ru.minegoat.oversees.data.network.user.UserApi
import ru.minegoat.oversees.data.network.user.model.toBusiness
import ru.minegoat.oversees.domain.user.RequestMasterStatus
import ru.minegoat.oversees.domain.user.ShortUser
import javax.inject.Inject
import kotlin.reflect.KClass

class UserRepository @Inject constructor(
    private val api: UserApi,
    private val realm: RealmDataStorage,
) {
    fun getUser(id: String): Maybe<ShortUser> {
        return api.getUser(id).toMaybe().flatMap {
            Maybe.just(
                it.items[0].toBusiness()
            )
        }
    }

    fun getUsersList(): Single<List<ShortUser>> {
        return api.getUsersList().map {
            it.items.map { user ->
                user.toBusiness()
            }
        }
    }

    fun getMasters(userName: String): Single<List<ShortUser>> {
        return api.getMasters().map {
            it.items.filter { user ->
                user.name.contains(userName)
            }
        }.map {
            it.map { user ->
                user.toBusiness()
            }
        }
    }


    fun saveUserRequestToMaster(userStatus: RequestMasterStatus): Completable {
        val userStatusModel = RequestToMasterStatusModel()
        userStatusModel.apply {
            userId = userStatus.userId.toInt()
            isSend = userStatus.isSend
            invitedMaster = userStatus.invitedMaster
            message = userStatus.message
            phone = userStatus.phone
            phoneCode = userStatus.phoneCode
            imageUrl = userStatus.imageUrl
            socialNetworks = userStatus.socialNetworks
        }
        return realm.save(userStatusModel)
    }

    fun getUserRequestStatus(id: String): Maybe<RequestMasterStatus> {
        return getByUserId(RequestToMasterStatusModel::class, id).map {
            it.toRequestMasterStatus()
        }
    }

    fun cancelRequest(userId: String): Completable =
        Completable.fromObservable(
            getByUserId(RequestToMasterStatusModel::class, userId)
                .map {
                    it.apply {
                        isSend = false
                    }
                }.toObservable()
        )


    private fun getByUserId(
        model: KClass<RequestToMasterStatusModel>,
        id: String
    ): Maybe<RequestToMasterStatusModel> {
        val dbPredicate = "$USER_ID_PREDICATE $id"
        return realm.fetch(model, dbPredicate)
            .map {
                it.last()
            }
            .toMaybe()
    }

    private companion object {
        private const val USER_ID_PREDICATE = "userId =="
    }
}