package ru.minegoat.oversees.domain.user

import ru.minegoat.oversees.data.db.comment.ShortUserRealm
import ru.minegoat.oversees.domain.karma.Karma

data class ShortUser(
    val userId: String,
    val role: UserRole? = null,
    val name: String? = null,
    val avatar: String? = null,
    val phone: String? = null,
    val isMaster: Boolean? = null,
    val masterTypeId: List<String> = listOf(),
    val karmaSum: Int? = null
) {
    companion object {
        fun emptyUser() : ShortUser {
            return ShortUser(
                userId = ""
            )
        }
    }
}

fun ShortUser.toShortUserRealm() =
    ShortUserRealm(
        userId = this.userId,
        role = this.role,
        name = this.name,
        avatar = this.avatar,
        isMaster = this.isMaster ?: false,
    )
