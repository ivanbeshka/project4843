package ru.minegoat.oversees.modules.map.presentation.map

import android.content.Context
import android.view.LayoutInflater
import androidx.appcompat.content.res.AppCompatResources
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.maps.android.clustering.Cluster
import com.google.maps.android.clustering.ClusterManager
import com.google.maps.android.clustering.view.DefaultClusterRenderer
import com.google.maps.android.ui.IconGenerator
import ru.minegoat.oversees.R
import ru.minegoat.oversees.modules.map.model.LocationClusterItem
import ru.minegoat.oversees.base.utils.image.bitmapDescriptorFromVector
import ru.minegoat.oversees.domain.location.marker
import kotlin.Boolean
import kotlin.let

class MyClusterRender(
    private val context: Context,
    map: GoogleMap,
    clusterManager: ClusterManager<LocationClusterItem>
) : DefaultClusterRenderer<LocationClusterItem>(context, map, clusterManager) {

    private val clusterIconGenerator = IconGenerator(context)

    override fun getDescriptorForCluster(cluster: Cluster<LocationClusterItem>): BitmapDescriptor {
        clusterIconGenerator.setBackground(AppCompatResources.getDrawable(context, R.drawable.ic_cluster))

        val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val clusterView = inflater.inflate(R.layout.view_cluster_text, null, false)

        clusterIconGenerator.setContentView(clusterView)

        val clusterSize = cluster.size
        val stringClusterSize = if (clusterSize > 99) {
            context.getString(R.string.ninety_nine_plus_cluster)
        } else {
            clusterSize.toString()
        }

        val icon = clusterIconGenerator.makeIcon(stringClusterSize)
        return BitmapDescriptorFactory.fromBitmap(icon)
    }

    override fun shouldRenderAsCluster(cluster: Cluster<LocationClusterItem>): Boolean {
        return cluster.size >= MIN_CLUSTER_SIZE
    }

    override fun onBeforeClusterItemRendered(
        item: LocationClusterItem,
        markerOptions: MarkerOptions
    ) {
        item.location.type?.marker()?.let {
            markerOptions.icon(bitmapDescriptorFromVector(context, it))
        }
    }

    override fun onClusterItemUpdated(item: LocationClusterItem, marker: Marker) {
        item.location.type?.marker()?.let {
            marker.setIcon(bitmapDescriptorFromVector(context, it))
        }
    }

    private companion object {
        private const val MIN_CLUSTER_SIZE = 2
    }
}