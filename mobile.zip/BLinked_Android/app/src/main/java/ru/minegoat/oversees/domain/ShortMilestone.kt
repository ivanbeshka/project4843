package ru.minegoat.oversees.domain

data class ShortMilestone(
    val objID: String,
    val locationName: String? = null,
    val reviewsNumber: Int? = null,
    val date: Long? = null,
    val type: String? = null,
    val locationObjID: String? = null
)