package ru.minegoat.oversees.domain.chat

import ru.minegoat.oversees.base.utils.DateUtils
import ru.minegoat.oversees.data.db.chat.MessageRoom
import ru.minegoat.oversees.modules.chat.model.MessageUi
import ru.minegoat.oversees.modules.chat.presentation.MessageListAdapter

data class Message(
    val objID: String,
    val ownerId: String,
    val ownerName: String,
    val chatId: String,
    val text: String,
    val dateTimeSec: Long,
    val contentUrl: String? = null
)

fun Message.toMessageUi(myUserId: String): MessageUi {
    return MessageUi(
        objID = objID,
        ownerId = ownerId,
        ownerName = ownerName,
        chatId = chatId,
        text = text,
        time = DateUtils.getTimeBySec(dateTimeSec),
        date = DateUtils.getDateBySeconds(dateTimeSec),
        dateTimeSec = dateTimeSec,
        type = if (ownerId == myUserId) {
            MessageListAdapter.MessageItemType.MY
        } else {
            MessageListAdapter.MessageItemType.OTHER
        }
    )
}

fun Message.toRoom(): MessageRoom {
    return MessageRoom(
        objID = objID,
        ownerId = ownerId,
        ownerName = ownerName,
        chatId = chatId,
        text = text,
        dateTime = dateTimeSec,
        contentUrl = contentUrl
    )
}
