package ru.minegoat.oversees.modules.search.presentation

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.ItemRandomSearchBinding

class DialogRandomSearchFragment: DialogFragment(R.layout.item_random_search) {
    private val binding by viewBinding(ItemRandomSearchBinding::bind)

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        dialog?.window?.setBackgroundDrawableResource(R.drawable.shape_dialog_random_search)
        return super.onCreateView(inflater, container, savedInstanceState)
    }

}