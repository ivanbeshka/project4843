package ru.minegoat.oversees.modules.user_profile.presentation

import android.app.Dialog
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.core.os.bundleOf
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.DialogLogoutBinding

class DialogLogoutFragment : DialogFragment(R.layout.dialog_logout) {

    private lateinit var binding: DialogLogoutBinding

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        binding = DialogLogoutBinding.inflate(layoutInflater)

        binding.btAccept.setOnClickListener {
            with (UserAccountFragment){
                setFragmentResult(
                    REQUEST_ACTION_KEY,
                    bundleOf(
                        ACTION_BUNDLE_KEY to UserAccountFragment.FragmentAction.NEED_LOGOUT.ordinal
                    )
                )
            }

            findNavController().navigateUp()
        }

        binding.btCancel.setOnClickListener {
            findNavController().navigateUp()
        }

        return AlertDialog.Builder(requireActivity())
            .setView(binding.root)
            .create()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        dialog?.window?.setBackgroundDrawableResource(R.drawable.shape_logout)
    }
}