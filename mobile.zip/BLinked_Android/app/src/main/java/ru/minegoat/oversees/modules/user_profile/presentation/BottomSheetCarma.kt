package ru.minegoat.oversees.modules.user_profile.presentation

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.navigation.fragment.navArgs
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.BottomSheetCarmaBinding

class BottomSheetCarma : BottomSheetDialogFragment(R.layout.bottom_sheet_carma) {

    private val binding by viewBinding(BottomSheetCarmaBinding::bind)
    private val args: BottomSheetCarmaArgs by navArgs()
    private val karma by lazy { args.karma }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val map = mapOf(
            "Лайки" to binding.carmaLikesData,
            "Заполнен профиль" to binding.carmaCompleteData
        )

        karma?.attribute?.forEach {
            map[it.type.name]?.text = it.sum.toString()
        }

        binding.tvKarmaSum.text = karma?.attribute?.sumOf { it.sum }.toString()
    }
}