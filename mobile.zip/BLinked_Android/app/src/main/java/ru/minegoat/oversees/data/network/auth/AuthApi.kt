package ru.minegoat.oversees.data.network.auth

import io.reactivex.Single
import retrofit2.http.GET
import retrofit2.http.Query
import ru.minegoat.oversees.data.network.auth.model.CheckPhoneResponse
import ru.minegoat.oversees.data.network.auth.model.UserAuthResponse
import ru.minegoat.oversees.data.network.auth.model.UserRecoverResponse
import ru.minegoat.oversees.data.network.auth.model.UserTokenResponse

interface AuthApi {

    @GET("user/register")
    fun register(): Single<UserAuthResponse>

    @GET("user/login")
    fun loginWithUsernameAndPass(
        @Query("username")
        username: String,
        @Query("password")
        password: String
    ): Single<UserTokenResponse>

    @GET("user/profile/recover")
    fun recoverUser(
        @Query("phone")
        phone: String
    ): Single<UserRecoverResponse>

    @GET("user/profile/check")
    fun checkUserPhone(
        @Query("phone")
        phone: String
    ): Single<CheckPhoneResponse>
}