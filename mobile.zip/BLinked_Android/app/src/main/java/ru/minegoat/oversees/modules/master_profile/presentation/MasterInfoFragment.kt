package ru.minegoat.oversees.modules.master_profile.presentation

import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import androidx.core.view.children
import androidx.core.view.get
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResultListener
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.chip.Chip
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.*
import ru.minegoat.oversees.databinding.FragmentMasterInfoBinding
import ru.minegoat.oversees.databinding.ViewChipWhiteBinding
import ru.minegoat.oversees.domain.master.MasterType
import ru.minegoat.oversees.modules.base.presentation.ConnectUsFragment
import ru.minegoat.oversees.modules.user_profile.di.UserProfileComponentHolder

class MasterInfoFragment : Fragment(R.layout.fragment_master_info) {

    private val binding by viewBinding(FragmentMasterInfoBinding::bind)

    private val component by featureComponent(UserProfileComponentHolder)

    private val viewModel by lazyViewModel {
        component.masterInfoViewModel().create()
    }

    private var userId = arguments?.getString(USER_ID) ?: "-1"

    private val adapter = MasterInfoAdapter(object : MasterInfoAdapter.OnCLickListener {
        override fun onMasterTypeTagSelect(masterType: MasterType) {
            viewModel.addMasterType(masterType)
        }
    })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setFragmentResultListener(ConnectUsFragment.SEND_CONNECT_US_STATUS) { _, bundle ->
            if (bundle.getBoolean(ConnectUsFragment.SEND_CONNECT_US_STATUS_VALUE))
                showSpecialToast(
                    header = getString(R.string.thanks_for_connect),
                    message = getString(R.string.we_get_master_type)
                )
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (userId != "-1") {
            viewModel.getByUserID(userId)
            viewModel.getMasterTypes()
        }

        with(binding) {

            recyclerView.also {
                it.layoutManager = LinearLayoutManager(requireContext())
                it.adapter = adapter
            }

            toolbarInfo.apply {
                setNavigationOnClickListener {
                    findNavController().navigateUp()
                }
            }

            toolbarAsk.apply {
                setNavigationOnClickListener {
                    tagsAddField.setText("")
                }
            }

            tagsAddField.apply {
                setOnFocusChangeListener { v, hasFocus ->
                    if (hasFocus) {
                        tagsLayout.background = ContextCompat.getDrawable(requireContext(), R.drawable.shape_r8dp_primary100)
                    } else {
                        tagsLayout.background = ContextCompat.getDrawable(requireContext(), R.drawable.shape_r8dp_gray40)
                    }
                }
                doOnTextChanged { text, _, _, count ->
                    viewModel.getMasterTypes(text.toString())
                    val masterTypesCount = viewModel.masterInfo.value?.masterTypes?.count() ?: 0
                    if (count == 0 && masterTypesCount == 0) {
                        showSamplePanel(true)
                    } else {
                        showSamplePanel(false)
                    }
                }
            }

            tagsLayout.setOnClickListener {
                tagsAddField.requestFocus()
                showKeyboard(tagsAddField)
            }

            newTagButton.setOnClickListener {
                findNavController().navigate(
                    R.id.action_masterInfoFragment_to_connectUsFragment,
                    bundleOf(
                        ConnectUsFragment.MESSAGE_TYPE to 3,
                        ConnectUsFragment.MESSAGE_TEXT to tagsAddField.text.toString()
                    )
                )
            }

            acceptButton.setOnClickListener {
                viewModel.saveMasterInfo(descInputField.text.toString())
            }

            tagsAddField.setText("")
        }

        with(viewModel) {

            masterInfo.observe(viewLifecycleOwner) { masterInfo ->
                if (masterInfo.masterTypes.isEmpty() && binding.tagsAddField.text.toString().isEmpty())
                    binding.samplePanel.visibility = View.VISIBLE
                else
                    binding.samplePanel.visibility = View.GONE
                with(binding.tagsLayout) {
                    for (i in childCount - 1 downTo 0) {
                        if (this[i] is Chip) {
                            val chip = this[i] as Chip
                            var isExist = false
                            for (j in masterInfo.masterTypes.indices) {
                                if (masterInfo.masterTypes[j].name == chip.tag) {
                                    isExist = true
                                    break
                                }
                            }
                            if (!isExist) {
                                this.removeViewAt(i)
                            }
                        }
                    }
                    masterInfo.masterTypes.forEach {
                        val masterType = it
                        var isExist = false
                        for (view in children) {
                            if (view is Chip) {
                                if (view.tag == masterType.name) {
                                    isExist = true
                                    break
                                }
                            }
                        }
                        if (!isExist) {
                            ViewChipWhiteBinding.inflate(layoutInflater).apply {
                                root.tag = masterType.name
                                val text = "#${masterType.name}"
                                chip.text = text
                                chip.setOnCloseIconClickListener {
                                    viewModel.removeMasterType(masterType.name)
                                }
                                chip.setOnClickListener {
                                    masterType.masterTypeDescription?.let {
                                        showToast(it)
                                    }

                                }
                                binding.tagsLayout.addView(root as View, childCount-1)
                            }

                        }
                    }
                }
                binding.tagsAddField.setText("")
                binding.descInputField.setText(masterInfo.path)
            }

            masterTypeList.observe(viewLifecycleOwner) {
                val masterTypeList = mutableListOf<MasterType>()
                it.forEach {
                    masterTypeList.add(it)
                }
                adapter.data = masterTypeList
                if (it.isEmpty() && binding.tagsAddField.text.toString().isNotEmpty()) {
                    showPanel(addPanel = true)
                } else if (it.isEmpty() && binding.tagsAddField.text.toString().isEmpty()) {
                    showPanel(descPanel = true)
                } else if (it.isNotEmpty() && binding.tagsAddField.text.toString().isEmpty()) {
                    showPanel(descPanel = true)
                } else {
                    showPanel(selectPanel = true)
                }
            }

            isSaved.observe(viewLifecycleOwner) {
                it.on(
                    success = {
                        if (it)
                            showToast(R.string.way_of_master_saved)
                    },
                    error = {
                        showToast(R.string.way_of_master_saved_error)
                    }
                )
            }
        }

        setFragmentResultListener(ConnectUsFragment.SEND_CONNECT_US_STATUS) { _, bundle ->
            if (bundle.getBoolean(ConnectUsFragment.SEND_CONNECT_US_STATUS_VALUE)) {
                showSpecialToast(
                    header = getString(R.string.thanks_for_connect),
                    message = getString(R.string.we_get_master_type)
                )
                binding.tagsAddField.setText("")
            }

        }
    }

    private fun showSamplePanel(show: Boolean) {
        when (show) {
            true -> {
                binding.samplePanel.visibility = View.VISIBLE
                binding.recyclerView.visibility = View.GONE
            }
            false -> {
                binding.samplePanel.visibility = View.GONE
                binding.recyclerView.visibility = View.VISIBLE
            }
        }
    }

    private fun showPanel(descPanel: Boolean = false, selectPanel: Boolean = false, addPanel: Boolean = false) {
        with(binding) {
            this.descPanel.visibility = if (descPanel) View.VISIBLE else View.GONE
            this.recyclerView.visibility = if (selectPanel) View.VISIBLE else View.GONE
            this.addPanel.visibility = if (addPanel) View.VISIBLE else View.GONE
            this.toolbarInfo.visibility = if (descPanel) View.VISIBLE else View.GONE
            this.toolbarAsk.visibility = if (!descPanel) View.VISIBLE else View.GONE
        }
    }

    companion object {
        const val USER_ID = "userId"
    }
}

