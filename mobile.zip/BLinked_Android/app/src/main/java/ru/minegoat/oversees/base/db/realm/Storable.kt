package ru.minegoat.oversees.base.db.realm

//TODO fix extends bugs
interface Storable<T> {
    val objID: String
}