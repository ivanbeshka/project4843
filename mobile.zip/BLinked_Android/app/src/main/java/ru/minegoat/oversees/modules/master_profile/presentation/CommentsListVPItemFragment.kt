package ru.minegoat.oversees.modules.master_profile.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.databinding.FragmentFeedbackListVPItemBinding
import ru.minegoat.oversees.domain.feedback.Comment
import ru.minegoat.oversees.domain.feedback.CommentType
import ru.minegoat.oversees.domain.user.ShortUser
import ru.minegoat.oversees.modules.master_profile.di.CommentComponentHolder
import java.time.LocalTime

class FeedbackListVPItemFragment : Fragment(R.layout.fragment_feedback_list_v_p_item) {

    private val binding by viewBinding(FragmentFeedbackListVPItemBinding::bind)

    private val component by featureComponent(CommentComponentHolder)

    private val viewModel by lazyViewModel { component.commentViewModel().create() }

    private val type by lazy { arguments?.getBoolean(TYPE, false) ?: false }

    private val adapter by lazy { FeedbackAdapter(type) }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

//        saveComment()

        getComments()

        binding.rvFeedback.adapter = adapter
    }

    private fun saveComment() {

        val date = LocalTime.now()

        val badUsersComment = Comment(
            objId = "",
            tags = listOf(
                "9520",
                "Новичок"
            ),
            userId = "1",
            images = listOf(""),
            date = date.toNanoOfDay() / 1000000,
            type = CommentType.REVIEW,
            content = "Я просто пример большого негативного отзыва от человека, которому ничего не " +
                    "нравится. И еще, мой отзыв будет настолько большим, что вам придется нажать на " +
                    "экран, чтобы прочитать его полностью",
            user = ShortUser(
                userId = "1",
                name = "Алена Васильева",
                isMaster = false
            ),
            rating = 1
        )

        val goodUsersComment = Comment(
            objId = "",
            tags = listOf(
                "9520",
                "Новичок"
            ),
            userId = "2",
            images = listOf(""),
            date = date.toNanoOfDay() / 1000000,
            type = CommentType.NOTE,
            content = "Как же круто ваще ваще ваще",
            user = ShortUser(
                userId = "2",
                name = "Игорь Николаев",
                isMaster = false
            ),
            rating = 4
        )

        val badMastersComment = Comment(
            objId = "",
            tags = listOf(
                "9520",
                "#шаман",
                "#проводник"
            ),
            userId = "1",
            images = listOf(""),
            date = date.toNanoOfDay() / 1000000,
            type = CommentType.REVIEW,
            content = "Я просто пример большого негативного отзыва от человека, которому ничего не " +
                    "нравится. И еще, мой отзыв будет настолько большим, что вам придется нажать на " +
                    "экран, чтобы прочитать его полностью",
            user = ShortUser(
                userId = "1",
                name = "Алена Васильева",
                isMaster = true
            ),
            rating = 1
        )

        val goodMastersComment = Comment(
            objId = "",
            tags = listOf(
                "9520",
                "#шаман",
                "#проводник"
            ),
            userId = "2",
            images = listOf(""),
            date = date.toNanoOfDay() / 1000000,
            type = CommentType.NOTE,
            content = "Как же круто ваще ваще ваще",
            user = ShortUser(
                userId = "2",
                name = "Игорь Николаев",
                isMaster = true
            ),
            rating = 4
        )

        val comments = listOf(
            badUsersComment,
            badUsersComment,
            goodUsersComment,
            goodUsersComment,
            goodMastersComment,
            badMastersComment,
            badMastersComment,
            goodMastersComment
        )

        for (comment in comments)
            viewModel.saveComment(comment)
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun getComments() {
        viewModel.comments.observe(viewLifecycleOwner) { comments ->
            for (comment in comments)
                if (comment.user.isMaster == true) adapter.mastersComments.add(comment)
                else adapter.usersComments.add(comment)

            adapter.notifyDataSetChanged()
        }
        viewModel.getComments()
    }

    companion object {
        private const val TYPE = "comment_type"

        fun newInstance(isMaster: Boolean) =
            FeedbackListVPItemFragment().apply { arguments = bundleOf(TYPE to isMaster) }
    }
}