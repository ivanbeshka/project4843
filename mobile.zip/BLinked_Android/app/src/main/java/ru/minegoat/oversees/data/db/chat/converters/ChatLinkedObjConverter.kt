package ru.minegoat.oversees.data.db.chat.converters

import androidx.room.ProvidedTypeConverter
import androidx.room.TypeConverter
import ru.minegoat.oversees.data.db.chat.ChatLinkedObjRoom
import ru.minegoat.oversees.domain.chat.ChatLinkedObjType

@ProvidedTypeConverter
class ChatLinkedObjConverter {

    @TypeConverter
    fun fromString(chatLinkedObj: String): ChatLinkedObjRoom {
        val parsedObj = chatLinkedObj.split(" ")
        return ChatLinkedObjRoom(parsedObj[0], ChatLinkedObjType.valueOf(parsedObj[1]))
    }

    @TypeConverter
    fun toString(chatLinkedObj: ChatLinkedObjRoom): String {
        return "${chatLinkedObj.linkedObjId} ${chatLinkedObj.type.name}"
    }
}