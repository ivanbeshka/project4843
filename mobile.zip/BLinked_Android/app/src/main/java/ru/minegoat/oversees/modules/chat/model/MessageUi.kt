package ru.minegoat.oversees.modules.chat.model

import ru.minegoat.oversees.modules.chat.presentation.MessageListAdapter

data class MessageUi(
    val objID: String,
    val ownerId: String,
    val ownerName: String,
    val chatId: String,
    val text: String,
    val time: String,
    val date: String,
    val dateTimeSec: Long,
    override val type: MessageListAdapter.MessageItemType,
    val contentUrl: String? = null
) : MessageItemUi(objID, type)
