package ru.minegoat.blinked.modules.user_profile.presentation

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipDrawable
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.loadImageFromOurApi

import ru.minegoat.oversees.databinding.ItemMasterShortBinding
import ru.minegoat.oversees.modules.user_profile.model.MasterUi

class DetailMasterAdapter(private val onClick: (masterId: String) -> Unit) :
    ListAdapter<MasterUi, DetailMasterAdapter.DetailMasterHolder>(DiffCallback) {

    class DetailMasterHolder(private val binding: ItemMasterShortBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(master: MasterUi, onClick: (masterId: String) -> Unit) {
            binding.apply {
                chipCarmaPoints.text = master.carmaPoints.toString()
                tvUsername.text = master.soname + " " + master.name
                master.avatarUrl?.let {
                    loadImageFromOurApi(
                        binding.imageView,
                        it
                    )
                }
                for (tag in master.tags) {
                    val chip = Chip(this@DetailMasterHolder.itemView.context)

                    val drawable = ChipDrawable.createFromAttributes(
                        this@DetailMasterHolder.itemView.context,
                        null,
                        0,
                        R.style.ActionChipStyle_Master
                    )

                    chip.setChipDrawable(drawable)
                    chip.setTextAppearanceResource(R.style.ActionChipStyle_Master)
                    chip.text = tag
                    binding.chipGroup.addView(chip)
                    this@DetailMasterHolder.itemView.setOnClickListener {
                        onClick(master.userId)
                    }
                }
            }
        }
    }

    companion object {
        private val DiffCallback = object : DiffUtil.ItemCallback<MasterUi>() {
            override fun areItemsTheSame(oldItem: MasterUi, newItem: MasterUi): Boolean {
                return oldItem.userId == newItem.userId
            }

            override fun areContentsTheSame(oldItem: MasterUi, newItem: MasterUi): Boolean {
                return oldItem.name == newItem.name &&
                        oldItem.soname == newItem.soname &&
                        oldItem.tags == newItem.tags &&
                        oldItem.avatarUrl == newItem.avatarUrl &&
                        oldItem.carmaPoints == newItem.carmaPoints
            }

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DetailMasterHolder {
        val binding =
            ItemMasterShortBinding.inflate((LayoutInflater.from(parent.context)), parent, false)
        return DetailMasterHolder(binding)
    }

    override fun onBindViewHolder(holder: DetailMasterHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item, onClick)
    }

}