package ru.minegoat.oversees.modules.trip.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.ComposeView
import androidx.fragment.app.Fragment
import ru.minegoat.oversees.modules.trip.presentation.compose.LocalTrip
import ru.minegoat.oversees.modules.trip.presentation.compose.LocalTripSelectedHeader
import ru.minegoat.oversees.modules.trip.presentation.compose.LocalTripViewModel
import ru.minegoat.oversees.modules.trip.presentation.compose.TripScreen
import ru.minegoat.oversees.modules.trip.di.TripComponentHolder
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.modules.trip.viewmodels.TripViewModel

class TripFragment : Fragment() {

    private val component by featureComponent(TripComponentHolder)

    private val viewModel: TripViewModel by lazyViewModel {
        component.tripViewModel().create()
    }

    @SuppressLint("UnusedMaterialScaffoldPaddingParameter")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        viewModel.getTrip("6316e0b36b6bec04fbe9a402")
        return ComposeView(requireContext()).apply {
            setContent {
                val trip = viewModel.trip.observeAsState()
                CompositionLocalProvider(
                    LocalTrip provides trip.value,
                    LocalTripSelectedHeader provides remember { mutableStateOf(2) },
                    LocalTripViewModel provides viewModel
                ) {
                    TripScreen()
                }
            }
        }
    }
}
