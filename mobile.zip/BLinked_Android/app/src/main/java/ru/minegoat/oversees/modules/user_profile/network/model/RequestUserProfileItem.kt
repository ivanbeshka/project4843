package ru.minegoat.oversees.modules.user_profile.network.model

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.data.network.skill.responses.ResponseMasterSkill
import ru.minegoat.oversees.data.network.user.model.ResponseSocialNetwork
import ru.minegoat.oversees.domain.user.UserRating

data class RequestUserProfileItem(
    @SerializedName("id")
    val id: String,
    @SerializedName("name")
    val name: String? = null,
    @SerializedName("soname")
    val soname: String? = null,
    @SerializedName("avatar")
    val avatarImageEncoded: String? = null,
    @SerializedName("avatarFileName")
    val avatarFileName: String? = null,
    @SerializedName("phone")
    val phone: String? = null,
    @SerializedName("userDescription")
    val userDescription: String? = null,
    @SerializedName("isGuide")
    val isGuide: Boolean? = null,
    @SerializedName("homeLocationID")
    val homeLocationID: String? = null,
    @SerializedName("sex")
    val sex: String? = null,
    @SerializedName("isMaster")
    val isMaster: Boolean? = null,
    @SerializedName("userRating")
    val userRating: UserRating? = null,
    @SerializedName("skills")
    val skills: List<ResponseMasterSkill> = emptyList(),
    @SerializedName("socialNetworks")
    val socialNetwork: List<ResponseSocialNetwork> = emptyList()
)
