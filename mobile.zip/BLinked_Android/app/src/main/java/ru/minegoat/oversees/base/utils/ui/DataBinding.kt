package ru.minegoat.oversees.base.utils.ui

import android.net.Uri
import android.widget.ImageView
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.load.model.GlideUrl
import com.bumptech.glide.load.model.LazyHeaders
import ru.minegoat.oversees.base.utils.image.ImageDecoder
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref

@BindingAdapter("imageUrl")
fun loadImage(view: ImageView, imageUrl: String?) {
    Glide.with(view).load(imageUrl).centerCrop().into(view)
}

@BindingAdapter("tripMainImage")
fun loadImageFromString(imageView: ImageView, imageString: String?){
    if (!imageString.isNullOrBlank()){
        imageView.setImageBitmap(ImageDecoder.decodeImage(imageString))
    }
}

@BindingAdapter("imageUri")
fun loadImageFromUri(view: ImageView, imageUri: Uri?) {
    Glide.with(view).load(imageUri).centerCrop().into(view)
}

@BindingAdapter("imageUrlFromOurApi")
fun loadImageFromOurApi(imageView: ImageView, imageUrl: String) {
    val authSharedPref = AuthSharedPref(imageView.context)
    authSharedPref.token?.let { token ->
        val glideUrl = GlideUrl(
            imageUrl,
            LazyHeaders.Builder()
                .addHeader("Authorization", "Bearer $token")
                .build()
        )

        Glide.with(imageView.context)
            .load(glideUrl)
            .centerCrop()
            .into(imageView)
    }
}