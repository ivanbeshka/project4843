package ru.minegoat.oversees.modules.base.network.model

import com.google.gson.annotations.SerializedName

data class SendConnectUs(
    @SerializedName("items")
    val items: List<SendConnectUsMessage>
)
