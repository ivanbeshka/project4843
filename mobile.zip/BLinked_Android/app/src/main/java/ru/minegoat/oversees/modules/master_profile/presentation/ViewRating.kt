package ru.minegoat.oversees.modules.master_profile.presentation

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.ItemRatingBinding

class ViewRating(
    context: Context,
    attrs: AttributeSet?,
    defStyleAttr: Int,
    defStyleRes: Int
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {

    private val binding by viewBinding(ItemRatingBinding::bind)

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : this(context, attrs, defStyleAttr, 0)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context) : this(context, null)

    init {
        val inflater = LayoutInflater.from(context)
        inflater.inflate(R.layout.item_rating, this, true)
        initAttrs(attrs, defStyleAttr, defStyleRes)
    }

    private fun initAttrs(attrs: AttributeSet?, defStyleAttr: Int, defStyleRes: Int) {
        if (attrs == null) return

        val typedArray = context
            .obtainStyledAttributes(attrs, R.styleable.ViewRating, defStyleAttr, defStyleRes)

        val rating = typedArray.getInt(R.styleable.ViewRating_starCount, 0)
        setRating(rating)
        typedArray.recycle()
    }

    fun setRating(rating: Int) {
        binding.apply {
            val stars = arrayOf(star1, star2, star3, star4, star5)
            for (i in 0 until rating) {
                stars[i].setImageResource(R.drawable.ic_feedback_star)
            }
        }
    }
}