package ru.minegoat.oversees.modules.search.presentation

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.SpaceDividerItemDecoration
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.databinding.FragmentNewSearchBinding
import ru.minegoat.oversees.domain.ShortTrip
import ru.minegoat.oversees.domain.user.Skill
import ru.minegoat.oversees.modules.search.di.SearchComponentHolder


class NewSearchFragment : Fragment(R.layout.fragment_new_search) {

    private val binding by viewBinding(FragmentNewSearchBinding::bind)

    private val component by featureComponent(SearchComponentHolder)

    private var adapter: SearchTripAdapter? = null
    private var skillAdapter: SkillsPopularAdapter? = null
    private var minHeight = 0

    var searched = false

    private val viewModel by lazyViewModel {
        component.searchViewModel().create()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        adapter = SearchTripAdapter()
        skillAdapter = SkillsPopularAdapter(
            object : RecyclerSkillDescriptionClickListener {
                override fun onClick(v: View, position: Int, item: Skill) {
                    parentFragmentManager.setFragmentResult(
                        BottomSheetChooseSkillFragment.CHOOSE_SKILL_KEY, bundleOf(
                            BottomSheetChooseSkillFragment.CHOOSE_SKILL_NAME to item.name,
                            BottomSheetChooseSkillFragment.CHOOSE_SKILL_DESCRIPTION to item.skillDescription
                        )
                    )
                    findNavController().navigate(R.id.action_newSearchFragment_to_bottomSheetTechnicDescriptionFragment)
                }
            }
        )
        return super.onCreateView(inflater, container, savedInstanceState)
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            viewSearch.etSearch.setOnClickListener() {
                findNavController().navigate(R.id.action_newSearchFragment_to_chooseSearchFragment)
            }

            ivSearch.setOnClickListener() {
                findNavController().navigate(R.id.action_newSearchFragment_to_chooseSearchFragment)
            }

            ivRandomSearch.setOnClickListener() {
                findNavController().navigate(R.id.action_newSearchFragment_to_dialogRandomSearchFragment)
            }


            var isShow = true
            var scrollRange = -1

            binding.appBarLayout.addOnOffsetChangedListener { barLayout, verticalOffset ->
                if (scrollRange == -1) {
                    scrollRange = barLayout?.totalScrollRange!!
                }
                if (scrollRange + verticalOffset == 0) {
                    binding.tvSearch.visibility = View.VISIBLE
                    binding.ivSearch.visibility = View.VISIBLE
                    isShow = true
                } else if (isShow) {
                    binding.tvSearch.visibility = View.GONE
                    binding.ivSearch.visibility = View.GONE
                    isShow = false
                }
            }

            rvEvents.adapter = adapter

            rvEvents.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                    super.onScrollStateChanged(recyclerView, newState)
                    val newHeight = recyclerView.measuredHeight
                    if (0 != newHeight && minHeight < newHeight) {

                        minHeight = newHeight
                        recyclerView.minimumHeight = minHeight;
                    }
                }
            })
            rvPopularTechnics.adapter = skillAdapter
            rvPopularTechnics.addItemDecoration(
                SpaceDividerItemDecoration(
                    resources.getDimensionPixelSize(R.dimen.space_divider_12dp),
                    LinearLayout.HORIZONTAL,
                )
            )
        }

        setOnMenuItemsClickListeners()


        findNavController().currentBackStackEntry?.savedStateHandle?.getLiveData<Boolean>(
            SearchSkillsFragment.SEND_FORM_STATUS
        )?.observe(viewLifecycleOwner) {
            searched = it
            loadTrips(searched)
            Toast.makeText(requireContext(), it.toString(), Toast.LENGTH_SHORT).show()
        }


        if (!searched) {
            loadTrips(searched)
        }
        loadSkills()
    }

    private fun loadTrips(formStatus: Boolean) {
        if (formStatus) {
            findNavController().currentBackStackEntry?.savedStateHandle?.getLiveData<List<String>>(
                SearchSkillsFragment.SEND_FORM_SKILLS
            )?.observe(viewLifecycleOwner) { skillIds ->
                viewModel.sendSearchForm(
                    skillIds = skillIds,
                    null
                ).observe(viewLifecycleOwner) { state ->
                    state.on(
                        success = { tripList ->
                            val tripToDisplay = mutableListOf<ShortTrip>()
                            tripList.forEach {
                                tripToDisplay.add(it)
                            }
                            adapter?.let { adapter ->
                                adapter.data = tripToDisplay.toList()
                            }
                        },
                        error = {

                        }
                    )
                }
            }
        } else {
            viewModel.getAllTrips()
                .observe(viewLifecycleOwner) { state ->
                    state.on(
                        success = { tripList ->
                            val tripToDisplay = mutableListOf<ShortTrip>()
                            tripList.forEach {
                                tripToDisplay.add(it)
                            }
                            adapter?.let { adapter ->
                                adapter.data = tripToDisplay.toList()
                            }
                        },
                        error = {
                            Log.d("Error", "onLoadingSkills ${it.message}")
                        }
                    )
                }
        }
    }

    private fun loadSkills() {
        viewModel.getSkillsList()
            .observe(viewLifecycleOwner) { state ->
                state.on(
                    success = { skillList ->
                        val skillsToDisplay = mutableListOf<Skill>()
                        skillList.forEach {
                            skillsToDisplay.add(it)
                        }
                        skillAdapter?.let { adapter ->
                            adapter.data = skillsToDisplay.toList()
                        }
                    },
                    error = {
                        Log.d("Error", "onLoadingSkills ${it.message}")
                    }
                )
            }
    }

    private fun setOnMenuItemsClickListeners() {

        binding.toolbarEvents.setOnMenuItemClickListener {
            if (it.itemId == R.id.edit) {
                findNavController().navigate(R.id.action_newSearchFragment_to_chooseSearchFragment)
                return@setOnMenuItemClickListener true
            }
            return@setOnMenuItemClickListener false
        }
    }
}