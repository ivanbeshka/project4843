package ru.minegoat.oversees.base.di.modules

import android.content.Context
import androidx.room.Room
import dagger.Module
import dagger.Provides
import ru.minegoat.oversees.base.db.room.RoomDB
import ru.minegoat.oversees.data.db.chat.converters.ChatLinkedObjConverter
import ru.minegoat.oversees.data.db.userProfile.converters.*
import javax.inject.Singleton


@Module
class RoomModule {

    @Singleton
    @Provides
    fun provideRoom(context: Context): RoomDB {

        return Room
            .databaseBuilder(
                context,
                RoomDB::class.java,
                "app_db"
            )
            .addTypeConverter(SexConverter())
            .addTypeConverter(ChatLinkedObjConverter())
            .addTypeConverter(SocialNetworkConverter())
            .addTypeConverter(SkillConverter())
            .addTypeConverter(RatingConverter())
            .addTypeConverter(KarmaTypeConverter())
            .build()
    }
}