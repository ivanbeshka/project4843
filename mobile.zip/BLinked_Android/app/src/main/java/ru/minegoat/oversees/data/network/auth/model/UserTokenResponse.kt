package ru.minegoat.oversees.data.network.auth.model

import com.google.gson.annotations.SerializedName

data class UserTokenResponse(
    @SerializedName("items")
    val items: List<UserToken>
)