package ru.minegoat.oversees.modules.map.presentation.search

import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.base.utils.ui.fragment.showKeyboard
import ru.minegoat.oversees.databinding.FragmentSearchLocationsBinding
import ru.minegoat.oversees.modules.map.di.MapComponentHolder


class SearchLocationsFragment : Fragment(R.layout.fragment_search_locations) {

    private val component by featureComponent(MapComponentHolder)

    private val viewModel by lazyViewModel {
        component.searchViewModel().create()
    }

    private val binding by viewBinding(FragmentSearchLocationsBinding::bind)

    private var isUsing: Boolean = true

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        arguments?.getBoolean(BUNDLE_KEY_IS_USING)?.let {
            isUsing = it
        }

        with(binding) {
            val searchLocationsAdapter = createSearchLocationsAdapter()
            rvSearchLocations.adapter = searchLocationsAdapter

            viewSearch.etSearch.requestFocus()
            showKeyboard(viewSearch.etSearch)

            setEtSearchTextChangedListener(searchLocationsAdapter)

            binding.toolbar.setNavigationOnClickListener {
                findNavController().navigateUp()
            }
        }
    }

    private fun createSearchLocationsAdapter(): SearchLocationsAdapter {
        return SearchLocationsAdapter { objID ->
            if (isUsing) {
                setFragmentResult(
                    REQUEST_KEY_LOCATION_MAP,
                    bundleOf(BUNDLE_KEY_LOCATION_ID to objID)
                )
            } else {
                setFragmentResult(
                    REQUEST_KEY_LOCATION_EDIT_PROFILE,
                    bundleOf(BUNDLE_KEY_LOCATION_ID to objID)
                )
            }
            findNavController().navigateUp()
        }
    }

    private fun setEtSearchTextChangedListener(
        searchLocationsAdapter: SearchLocationsAdapter
    ) {
        binding.viewSearch.etSearch.doAfterTextChanged {
            it?.let {
                viewModel.getLocationsWithPredicate(it.toString(), isUsing)
                    .observe(viewLifecycleOwner) { state ->
                        state.on(success = { locations ->
                            if (locations.isNotEmpty()) {
                                setIsVisibleSearchLocations(true)
                                searchLocationsAdapter.data = locations
                            } else {
                                setIsVisibleSearchLocations(false)
                            }
                        }, error = {
                            setIsVisibleSearchLocations(false)
                        })
                    }
            }
        }
    }

    private fun setIsVisibleSearchLocations(isVisible: Boolean) {
        with(binding) {
            if (isVisible) {
                rvSearchLocations.isVisible = true
                containerLocationNotFound.isGone = true
            } else {
                binding.rvSearchLocations.isGone = true
                binding.containerLocationNotFound.isVisible = true
            }
        }
    }

    companion object {
        const val REQUEST_KEY_LOCATION_MAP = "location_key_map"
        const val REQUEST_KEY_LOCATION_EDIT_PROFILE = "location_key_edit_profile"

        const val BUNDLE_KEY_LOCATION_ID = "location_id"
        const val BUNDLE_KEY_IS_USING = "is_using_key"
    }
}