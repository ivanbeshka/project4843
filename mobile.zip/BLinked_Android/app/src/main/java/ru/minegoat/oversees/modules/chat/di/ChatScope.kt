package ru.minegoat.oversees.modules.chat.di

import javax.inject.Scope

@Scope
annotation class ChatScope
