package ru.minegoat.oversees.domain.user

import io.realm.kotlin.ext.toRealmList
import ru.minegoat.oversees.data.db.skill.SkillRealm

data class Skill(
    val objId: String,
    val ownerId: String? = null,
    val tags: List<String>? = null,
    val name: String? = null,
    val skillDescription: String? = null,
    val internationalDescription: String? = null,
    val internationalName: String? = null,
    var experience: String? = null
)

fun Skill.toSkillRealm(): SkillRealm {
    return SkillRealm(
        objId = objId,
        ownerId = ownerId,
        tags = tags?.toRealmList(),
        name = name,
        skillDescription = skillDescription,
        internationalDescription = internationalDescription,
        internationalName = internationalName
    )
}
