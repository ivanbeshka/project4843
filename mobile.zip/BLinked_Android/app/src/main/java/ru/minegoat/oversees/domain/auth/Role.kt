package ru.minegoat.oversees.domain.auth

enum class Role {
    ROLE_USER
}