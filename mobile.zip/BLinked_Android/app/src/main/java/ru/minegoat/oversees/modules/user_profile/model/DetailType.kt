package ru.minegoat.oversees.modules.user_profile.model

enum class DetailType {
    EVENTS,
    MASTERS,
    SKILLS
}