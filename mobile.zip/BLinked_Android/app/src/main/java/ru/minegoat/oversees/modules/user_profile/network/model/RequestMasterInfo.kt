package ru.minegoat.oversees.modules.user_profile.network.model

import com.google.gson.annotations.SerializedName

data class RequestMasterInfo (
    @SerializedName("objID")
    val objID: String,
    @SerializedName("masterTypes")
    val masterTypes: List<String>,
    @SerializedName("path")
    val path: String,
    @SerializedName("masterId")
    val masterId: String

)