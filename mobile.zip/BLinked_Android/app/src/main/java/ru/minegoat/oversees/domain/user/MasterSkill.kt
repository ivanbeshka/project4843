package ru.minegoat.oversees.domain.user

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class MasterSkill(
    val objId: String,
    val experience: String? = null
    ): Parcelable