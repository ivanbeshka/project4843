package ru.minegoat.oversees.domain.search

import ru.minegoat.oversees.data.network.search.model.TripItemRequest


data class SearchForm(
    val skills: List<String>,
    val masters_types: List<String>? = null,
)

fun SearchForm.toNetwork(): List<TripItemRequest> {
    return listOf(
        TripItemRequest(
            skills = skills,
            masters_types = masters_types
        )
    )
}