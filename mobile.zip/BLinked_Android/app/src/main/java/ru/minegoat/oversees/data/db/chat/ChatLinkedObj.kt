package ru.minegoat.oversees.data.db.chat

import ru.minegoat.oversees.domain.chat.ChatLinkedObjType

data class ChatLinkedObjRoom(
    val linkedObjId: String,
    val type: ChatLinkedObjType
)
