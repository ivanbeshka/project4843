package ru.minegoat.oversees.modules.search.di

import javax.inject.Scope

@Scope
annotation class SearchScope
