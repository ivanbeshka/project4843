package ru.minegoat.oversees.base.helpers.auth

interface INeedTokenUpdate {

    fun updateToken()
}