package ru.minegoat.oversees.data.network.syncer.model

import com.google.gson.annotations.SerializedName

data class SyncItemRequest(
    @SerializedName("type")
    val type: String,
    @SerializedName("object")
    val obj: SyncItemObjRequest
)
