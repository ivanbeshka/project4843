package ru.minegoat.oversees.modules.user_profile.model

sealed class EventsUi{
    data class EventUi(
        val eventId: String,
        val name : String,
        val type : String,
        val date : String,
        val location : String,
        val price : String,
        val countMasters : String,
        val tags : List<String>,
        val avatarUrl : String? = null,
        val isOnline : Boolean,
        val isStarted : Boolean,
        val isLiked : Boolean = false
    ) : EventsUi()

    data class MonthUi(
        val month : String,
        val year : String
    ) : EventsUi()
}
