package ru.minegoat.oversees.modules.main.repository

import io.reactivex.Completable
import ru.minegoat.oversees.data.db.chat.dao.MessageDao
import ru.minegoat.oversees.domain.chat.Message
import ru.minegoat.oversees.domain.chat.toRoom
import ru.minegoat.oversees.modules.main.di.fixture.FixtureScope

@FixtureScope
class MessagesFixtureRepository(
    private val messageDao: MessageDao
) {

    fun saveMessages(messages: List<Message>): Completable {
        return messageDao.insertAll(
            *messages.map { it.toRoom() }.toTypedArray()
        )
    }
}