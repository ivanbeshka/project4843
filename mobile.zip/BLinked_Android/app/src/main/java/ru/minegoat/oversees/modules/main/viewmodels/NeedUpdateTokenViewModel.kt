package ru.minegoat.oversees.modules.main.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.base.helpers.auth.Authenticator
import ru.minegoat.oversees.base.viewmodels.*

class NeedUpdateTokenViewModel @AssistedInject constructor(
    private val authenticator: Authenticator
) : RxViewModel() {
    private val isTokenUpdating =
        MutableLiveData<ScreenState<Boolean>>(SuccessScreenState(false))

    fun getIsTokenUpdating(): LiveData<ScreenState<Boolean>> {
        authenticator.getNeedTokenUpdate()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe {
                authenticator.authOldUser()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .doOnSubscribe {
                        isTokenUpdating.value = LoadingScreenState()
                    }
                    .subscribeBy(
                        onSuccess = {
                            isTokenUpdating.value = SuccessScreenState(it)
                        },
                        onError = {
                            isTokenUpdating.value = ErrorScreenState(it)
                        }
                    )
                    .disposeOnFinish()
            }
            .disposeOnFinish()

        return isTokenUpdating
    }

    @AssistedFactory
    interface Factory {
        fun create(): NeedUpdateTokenViewModel
    }
}