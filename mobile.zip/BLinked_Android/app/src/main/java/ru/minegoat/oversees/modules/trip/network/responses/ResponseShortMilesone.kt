package ru.minegoat.oversees.modules.trip.network.responses

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.ShortMilestone

data class ResponseShortMilestone (
    @SerializedName("objID")
    val objID: String,
    @SerializedName("locationName")
    val locationName: String?,
    @SerializedName("reviewsNumber")
    val reviewsNumber: Int?,
    @SerializedName("date")
    val date: Long?,
    @SerializedName("type")
    val type: String?,
    @SerializedName("locationObjID")
    val locationObjID: String?
)

fun ResponseShortMilestone.toBusiness(): ShortMilestone {
    val milestone = this
    return ShortMilestone(
        objID = milestone.objID,
        locationName = milestone.locationName,
        date = milestone.date,
        type = milestone.type,
        reviewsNumber = milestone.reviewsNumber,
        locationObjID = milestone.locationObjID,
    )
}