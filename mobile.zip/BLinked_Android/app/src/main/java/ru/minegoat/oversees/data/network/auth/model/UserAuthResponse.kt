package ru.minegoat.oversees.data.network.auth.model

import com.google.gson.annotations.SerializedName

data class UserAuthResponse(
    @SerializedName("items")
    val items: List<UserAuthNetwork>
)
