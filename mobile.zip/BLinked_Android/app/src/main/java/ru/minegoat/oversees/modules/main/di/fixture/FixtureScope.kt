package ru.minegoat.oversees.modules.main.di.fixture

import javax.inject.Scope

@Scope
annotation class FixtureScope
