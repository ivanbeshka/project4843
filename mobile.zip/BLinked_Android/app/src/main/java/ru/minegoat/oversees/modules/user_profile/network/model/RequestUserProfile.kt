package ru.minegoat.oversees.modules.user_profile.network.model

import com.google.gson.annotations.SerializedName

data class RequestUserProfile(
    @SerializedName("items")
    val items: List<RequestUserProfileItem>
)