package ru.minegoat.oversees.modules.chat.di

import ru.minegoat.oversees.App
import ru.minegoat.oversees.base.di.holders.FeatureComponentHolder

object ChatComponentHolder : FeatureComponentHolder<ChatComponent>() {
    override fun build(): ChatComponent {
        return DaggerChatComponent.builder()
            .appComponent(App.component)
            .chatModule(ChatModule())
            .build()
    }
}