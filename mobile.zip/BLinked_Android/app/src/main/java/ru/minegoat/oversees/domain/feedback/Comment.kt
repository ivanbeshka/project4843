package ru.minegoat.oversees.domain.feedback

import io.realm.kotlin.ext.toRealmList
import ru.minegoat.oversees.data.db.comment.CommentRealm
import ru.minegoat.oversees.domain.user.ShortUser
import ru.minegoat.oversees.domain.user.toShortUserRealm

data class Comment(
    val objId: String,
    val tags: List<String>,
    val userId: String = "",
    val images: List<String>,
    val date: Long = 0,
    val type: CommentType = CommentType.NOTE,
    val content: String = "",
    val user: ShortUser = ShortUser.emptyUser(),
    val rating: Int
)

fun Comment.toCommentRealm(linkedObjId: String) =
    CommentRealm(
        objId = this.objId,
        linkedObjId = linkedObjId,
        tags = this.tags.toRealmList(),
        userId = this.userId,
        images = this.images.toRealmList(),
        date = this.date,
        type = this.type,
        content = this.content,
        user = this.user.toShortUserRealm(),
        rating = this.rating
    )