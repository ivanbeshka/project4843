package ru.minegoat.oversees.base.helpers.messenger

import io.reactivex.Completable
import ru.minegoat.oversees.base.exceptions.UserNotAuthorizedException
import ru.minegoat.oversees.data.repository.messenger.MessengerRepository
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import ru.minegoat.oversees.domain.chat.IChatLinkedObj
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class Messenger @Inject constructor(
    private val messengerRepo: MessengerRepository,
    private val authSharedPref: AuthSharedPref
) {

    fun createChat(userId: String, chatName: String, linkedObj: IChatLinkedObj): Completable {
        return messengerRepo.createChat(userId, chatName, linkedObj)
    }

    fun addToChat(chatId: String, userId: String): Completable {
        return messengerRepo.addToChat(chatId, userId)
    }

    fun removeFromChat(chatId: String, userId: String): Completable {
        return messengerRepo.removeFromChat(chatId, userId)
    }

    private fun doIfAuthorized(body: () -> Completable): Completable {
        authSharedPref.token?.let {
            return body()
        }
        return Completable.error(UserNotAuthorizedException())
    }
}