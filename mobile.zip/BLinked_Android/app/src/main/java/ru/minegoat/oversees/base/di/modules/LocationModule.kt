package ru.minegoat.oversees.base.di.modules

import android.content.Context
import dagger.Module
import dagger.Provides
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import ru.minegoat.oversees.data.repository.location.LocationRepository
import ru.minegoat.oversees.base.utils.LocationUtils
import javax.inject.Singleton

@Module
class LocationModule {

    @Singleton
    @Provides
    fun provideLocationRepository(ds: RealmDataStorage): LocationRepository =
        LocationRepository(ds)

    @Singleton
    @Provides
    fun provideLocationUtils(context: Context): LocationUtils =
        LocationUtils(context)
}