package ru.minegoat.oversees.modules.trip.network.responses

import com.google.gson.annotations.SerializedName

data class ResponseLocation(
    @SerializedName("items")
    val items: List<ResponseLocationItem>?
)