package ru.minegoat.oversees.data.network.search.model

import com.google.gson.annotations.SerializedName

data class TripItemRequest(
    @SerializedName("skills")
    val skills: List<String>,
    @SerializedName("masters_types")
    val masters_types: List<String>? = null
)
