package ru.minegoat.oversees.base.db.realm

import io.reactivex.Completable
import io.reactivex.Single
import kotlin.reflect.KClass

//TODO fix extends bugs
interface DataStorage<DSType : Any> {
    fun <T> create(model: T): Single<T> where T : Storable<DSType>
    fun save(obj: Storable<DSType>): Completable
    fun saveAll(objs: List<Storable<DSType>>): Completable
    fun update(obj: Storable<DSType>): Completable
    fun update(block: () -> Unit): Completable
    fun delete(obj: Storable<DSType>): Completable
    fun deleteArray(objs: List<Storable<DSType>>, withWaiting: Boolean): Completable
    fun <T : DSType> deleteAll(model: KClass<T>): Completable
    fun <T : DSType> fetch(
        model: KClass<T>,
        predicate: String? = null,
        sorted: Sorted? = null
    ): Single<List<T>>
}