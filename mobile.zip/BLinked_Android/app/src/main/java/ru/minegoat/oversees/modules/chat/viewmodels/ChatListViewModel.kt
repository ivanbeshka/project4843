package ru.minegoat.oversees.modules.chat.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.base.viewmodels.RxViewModel
import ru.minegoat.oversees.base.viewmodels.ScreenState
import ru.minegoat.oversees.base.viewmodels.SuccessScreenState
import ru.minegoat.oversees.modules.chat.model.UnreadMsgCountForTabs

class ChatListViewModel @AssistedInject constructor(
    private val chatNamePredicateSubManager: ChatNamePredicateSubManager,
    private val unreadMsgCountForTabsSubManager: UnreadMsgCountForTabsSubManager
) : RxViewModel() {

    private val unreadMessagesCount = MutableLiveData<ScreenState<UnreadMsgCountForTabs>>()

    fun onNextChatNamePredicate(namePredicate: String) {
        chatNamePredicateSubManager.onNext(namePredicate)
    }

    fun getUnreadMessagesCount(): LiveData<ScreenState<UnreadMsgCountForTabs>> {
        unreadMsgCountForTabsSubManager.get()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeBy(
                onNext = {
                    if (unreadMessagesCount.value is SuccessScreenState
                        || unreadMessagesCount.value == null
                    ) {
                        val unreadMsgCountForTabs =
                            (unreadMessagesCount.value as? SuccessScreenState)?.data ?: UnreadMsgCountForTabs()

                        unreadMsgCountForTabs.setUnreadMsgCountForType(it)

                        unreadMessagesCount.value = SuccessScreenState(unreadMsgCountForTabs)
                    }
                }
            )
            .disposeOnFinish()

        return unreadMessagesCount
    }

    @AssistedFactory
    interface Factory {
        fun create(): ChatListViewModel
    }
}