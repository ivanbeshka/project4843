package ru.minegoat.oversees.modules.chat.presentation

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isInvisible
import androidx.core.view.isVisible
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.ItemChatBinding
import ru.minegoat.oversees.modules.chat.model.ChatItemUi
import ru.minegoat.oversees.modules.chat.utils.UnreadMsgCountUtils

class ChatListAdapter(private val onChatItemClick: (chatId: String) -> Unit) :
    RecyclerView.Adapter<ChatListAdapter.ViewHolder>() {

    private val differ = AsyncListDiffer(this, ChatListDiffUtilCallback())
    var data: List<ChatItemUi>
        get() = differ.currentList
        set(value) = differ.submitList(value)

    inner class ViewHolder(root: View) : RecyclerView.ViewHolder(root) {
        private val binding by viewBinding(ItemChatBinding::bind)

        fun bind(chatItem: ChatItemUi) {
            with(binding) {
                this.chatItem = chatItem
                if (chatItem.unreadMessagesCount > 0) {

                    viewUnreadMsgCount.tvMessageCount.text =
                        UnreadMsgCountUtils.unreadMsgCountToString(chatItem.unreadMessagesCount)
                    viewUnreadMsgCount.containerViewMsgCount.isVisible = true
                } else {
                    viewUnreadMsgCount.containerViewMsgCount.isInvisible = true
                }

                containerItemChat.setOnClickListener {
                    onChatItemClick(chatItem.chat.objID)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val root = inflater.inflate(R.layout.item_chat, parent, false)
        return ViewHolder(root)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val chatItem = data[position]
        holder.bind(chatItem)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    private class ChatListDiffUtilCallback : DiffUtil.ItemCallback<ChatItemUi>() {
        override fun areItemsTheSame(oldItem: ChatItemUi, newItem: ChatItemUi): Boolean {
            return oldItem.chat.objID == newItem.chat.objID
                    && oldItem.lastMessage.objID == newItem.lastMessage.objID
        }

        override fun areContentsTheSame(oldItem: ChatItemUi, newItem: ChatItemUi): Boolean {
            return oldItem == newItem
        }
    }
}