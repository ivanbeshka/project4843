package ru.minegoat.oversees.modules.master_profile.di

import ru.minegoat.oversees.App
import ru.minegoat.oversees.base.di.holders.FeatureComponentHolder

class MasterComponentHolder : FeatureComponentHolder<MasterComponent>() {
    override fun build(): MasterComponent {
        return DaggerMasterComponent.builder()
            .appComponent(App.component)
            .masterModule(MasterModule())
            .build()
    }
}