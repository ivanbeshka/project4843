package ru.minegoat.oversees.modules.main.presentation

import android.animation.ObjectAnimator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.view.animation.AnticipateInterpolator
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.animation.doOnEnd
import androidx.core.splashscreen.SplashScreen
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.*
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.activity.lazyViewModel
import ru.minegoat.oversees.databinding.ActivityMainBinding
import ru.minegoat.oversees.modules.main.di.auth.AuthComponentHolder
import ru.minegoat.oversees.modules.main.di.fixture.FixtureComponentHolder
import com.google.firebase.dynamiclinks.PendingDynamicLinkData
import com.google.firebase.dynamiclinks.ktx.dynamicLinks
import com.google.firebase.ktx.Firebase
import ru.minegoat.oversees.modules.user_profile.presentation.utils.PARAMETER_ID
import ru.minegoat.oversees.modules.user_profile.presentation.utils.PATH_USER

class MainActivity : AppCompatActivity(R.layout.activity_main) {

    private val authComponent = AuthComponentHolder.get()
    private val fixtureComponent = FixtureComponentHolder.get()

    private val needUpdateTokenViewModel by lazyViewModel {
        authComponent.needUpdateTokenViewModel().create()
    }
    private val locationsFixtureViewModel by lazyViewModel {
        fixtureComponent.locationsFixtureViewModel().create()
    }
    private val messagesFixtureViewModel by lazyViewModel {
        fixtureComponent.messagesFixtureViewModel().create()
    }

    private val binding by viewBinding(ActivityMainBinding::bind, R.id.container_main)

    private lateinit var navController: NavController

    private var keepSplashOnScreen = true

    override fun onCreate(savedInstanceState: Bundle?) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO) //light theme
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)

        setSplashExitAnim(splashScreen)
        setupSplashScreenExit(splashScreen)

        setupBottomNavigation()

        subscribeOnNeedUpdateToken()
        getDataFromLink()
    }

    override fun onResume() {
        super.onResume()
        saveLocationsFixture()
        saveMessagesFixture()
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp()
    }

    override fun onDestroy() {
        FixtureComponentHolder.clear()
        super.onDestroy()
    }

    //TODO : УБРАТЬ ПОЛУЧЕНИЕ ДАННЫХ
    private fun getDataFromLink() {
        val link = Firebase.dynamicLinks
            .getDynamicLink(intent)

        link.addOnSuccessListener(this) { data: PendingDynamicLinkData? ->
            if (data != null) {
                val deepLink = data.link!!
                if (deepLink.path.equals("/$PATH_USER")) {
                    val id = deepLink.getQueryParameter(PARAMETER_ID)
                    Log.i("LINK", id ?: "error")
                }
            }
        }
            .addOnFailureListener(this) { e ->
                Log.e("LINK", e.message ?: "Unknown Error")
            }
    }

    private fun subscribeOnNeedUpdateToken() {
        needUpdateTokenViewModel.getIsTokenUpdating().observe(this) { state ->
            state.on(
                success = {
                    //ok
                },
                loading = {
                    //todo
                },
                error = {
                    //todo
                }
            )
        }
    }

    //todo remove
    private fun saveMessagesFixture() {
        messagesFixtureViewModel.saveMessagesFixture().observe(this) { state ->
            state.on(
                success = {
                    //ok
                },
                error = {
                    Log.d(TAG, "saveMessagesFixture: ${it.message}")
                }
            )
        }
    }

    //todo remove
    private fun saveLocationsFixture() {
        locationsFixtureViewModel.saveLocationsFixture().observe(this) { state ->
            state.on(
                success = {
                    // ok
                },
                error = {
                    // may be locations already saved
                    Log.d(TAG, "saveLocationsFixture: ${it.message}")
                }
            )
        }
    }

    private fun setupBottomNavigation() {
        val navHostFragment = supportFragmentManager.findFragmentById(
            R.id.nav_host_fragment
        ) as NavHostFragment
        navController = navHostFragment.navController

        binding.bottomNav.setupWithNavController(navController)

        navController.addOnDestinationChangedListener { _, destination, _ ->

            when (destination.id) {
                R.id.splashFragment -> {
                    hideSystemUI(binding.root)
                    binding.bottomNav.isGone = true
                }

                R.id.allEventsFragment,
                R.id.feedbackFragment,
                R.id.chatListFragment,
                R.id.favoritesFragment,
                R.id.mapFragment,
                R.id.searchFragment,
                R.id.userProfileFragment,
                R.id.userAccountFragment,
                R.id.detailInfoFragment,
                R.id.bottomSheetDocumentInfo,
                R.id.bottomSheetRenameDocument,
                R.id.selectFileDirectoryFragment,
                R.id.dialogLogoutFragment,
                R.id.markerInfoBottomSheet,
                R.id.chooseMapFragment -> {
                    showSystemUI(binding.root)
                    binding.bottomNav.isVisible = true
                }

                else -> {
                    binding.bottomNav.isGone = true
                }
            }

            if (destination.id == R.id.chatFragment ||
                destination.id == R.id.bottomSheetRenameDocument ||
                destination.id == R.id.sendRequestMasterSubmissionFragment ||
                destination.id == R.id.connectUsFragment
            ) {
                window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE) //todo
            } else {
                window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
            }
        }
    }

    private fun setSplashExitAnim(splashScreen: SplashScreen) {
        splashScreen.setOnExitAnimationListener {
            val slideUp = ObjectAnimator.ofFloat(
                it.view,
                View.TRANSLATION_Y,
                0f,
                -it.view.height.toFloat()
            )
            slideUp.interpolator = AnticipateInterpolator()
            slideUp.duration = DELAY

            // Call SplashScreenView.remove at the end of your custom animation.
            slideUp.doOnEnd { _ ->
                it.remove()
            }

            // Run your animation.
            slideUp.start()
        }
    }

    private fun setupSplashScreenExit(splashScreen: SplashScreen) {
        splashScreen.setKeepOnScreenCondition { keepSplashOnScreen }
        Handler(Looper.getMainLooper()).postDelayed({ keepSplashOnScreen = false }, DELAY)
    }

    private fun hideSystemUI(container: View) {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, container).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun showSystemUI(container: View) {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, container).show(WindowInsetsCompat.Type.systemBars())
    }

    companion object {
        private const val DELAY = 400L
        private const val TAG = "MainActivity"
    }
}