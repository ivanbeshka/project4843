package ru.minegoat.oversees.modules.master_profile.presentation

import android.os.Bundle
import android.view.View
import android.view.View.OnFocusChangeListener
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.databinding.FragmentSearchSkillsBinding
import ru.minegoat.oversees.domain.user.Skill
import ru.minegoat.oversees.modules.user_profile.di.UserProfileComponentHolder

class SearchSkillFragment : Fragment(R.layout.fragment_search_skills) {

    private val component by featureComponent(UserProfileComponentHolder)

    private val viewModel by lazyViewModel {
        component.skillsViewModel().create()
    }

    private val binding by viewBinding(FragmentSearchSkillsBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val skillsAdapter = SearchSkillsAdapter(object:SearchSkillsAdapter.OnClick{
            override fun show(skill: Skill) {
                TODO("Not yet implemented")
            }

            override fun executeAction(skill: Skill) {
                findNavController().navigate(
                    R.id.action_searchSkillFragment_to_addSkillExperienceFragment, bundleOf(
                        SKILL_ID_BUNDLE_KEY to skill.objId
                    )
                )
            }

        })
        binding.skillsList.adapter = skillsAdapter

        setOnClickListeners()
        setEtSearchSkillTextChangedListener(skillsAdapter)
        selectSkill("", skillsAdapter)
    }

    private fun setEtSearchSkillTextChangedListener(searchSkillsAdapter: SearchSkillsAdapter) {
        binding.viewSearch.etSearch.run{
            onFocusChangeListener = OnFocusChangeListener { _, hasFocus ->
                if (hasFocus){
                    selectSkill(text.toString(), searchSkillsAdapter)
                }
            }
            doAfterTextChanged {
                it?.let { selectSkill(it.toString(), searchSkillsAdapter) }
            }
        }
    }

    fun selectSkill(predicate:String, searchSkillsAdapter: SearchSkillsAdapter){
        viewModel.getSkillsWithPredicate(predicate)
            .observe(viewLifecycleOwner) { state ->
                state.on(success = { skills ->
                    searchSkillsAdapter.data = skills
                    binding.groupSkillEmpty.isVisible = skills.isEmpty()
                }, error = {
                    searchSkillsAdapter.data = emptyList()
                    binding.groupSkillEmpty.isVisible = true
                })
            }
    }

    private fun setOnClickListeners() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }

        binding.tvCreateNewSkill.setOnClickListener {
            findNavController().navigate(
                R.id.action_searchSkillFragment_to_createSkillFragment,
                bundleOf(SKILL_NAME_BUNDLE_KEY to binding.viewSearch.etSearch.text.toString())
            )
        }
    }

    companion object {
        const val SKILL_NAME_BUNDLE_KEY = "skill_name_bundle"
        const val SKILL_ID_BUNDLE_KEY = "skill_name_bundle"
    }
}