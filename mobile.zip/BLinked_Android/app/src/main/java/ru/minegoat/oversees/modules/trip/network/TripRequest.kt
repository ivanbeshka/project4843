package ru.minegoat.oversees.data.network.search.model

import com.google.gson.annotations.SerializedName

data class TripRequest(
    @SerializedName("items")
    val items: List<TripItemRequest>
)
