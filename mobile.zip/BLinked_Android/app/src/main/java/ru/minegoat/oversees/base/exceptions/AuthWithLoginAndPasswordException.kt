package ru.minegoat.oversees.base.exceptions

class AuthWithLoginAndPasswordException : AuthException(MESSAGE) {

    private companion object {
        private const val MESSAGE = "User shared pref not contains password and (or) login"
    }
}