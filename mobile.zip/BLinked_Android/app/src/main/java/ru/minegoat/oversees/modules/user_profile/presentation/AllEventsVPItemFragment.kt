package ru.minegoat.oversees.modules.user_profile.presentation

import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.FragmentAllEventsVPItemBinding
import ru.minegoat.oversees.modules.master_profile.presentation.EventType
import ru.minegoat.oversees.modules.master_profile.presentation.EventsAdapter

class AllEventsVPItemFragment : Fragment(R.layout.fragment_all_events_v_p_item) {

    private val binding by viewBinding(FragmentAllEventsVPItemBinding::bind)
    private val type by lazy {
        val intType =
            arguments?.getInt(TYPE, EventType.UPCOMING.ordinal) ?: EventType.UPCOMING.ordinal
        EventType.values()[intType]
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rvEvents.adapter = EventsAdapter(type)
    }

    companion object {
        private const val TYPE = "event_type"

        fun newInstance(type: EventType) =
            AllEventsVPItemFragment().apply { arguments = bundleOf(TYPE to type.ordinal) }
    }
}