package ru.minegoat.oversees.data.network.chat

import io.reactivex.Completable
import ru.minegoat.oversees.data.network.chat.model.ChatResponse

class ChatManageApiImpl : ChatManageApi {
    override fun createChat(chatNetwork: ChatResponse): Completable {
        TODO("Not yet implemented")
    }

    override fun addToChat(chatId: String, userId: String): Completable {
        TODO("Not yet implemented")
    }

    override fun removeFromChat(chatId: String, userId: String): Completable {
        TODO("Not yet implemented")
    }
}