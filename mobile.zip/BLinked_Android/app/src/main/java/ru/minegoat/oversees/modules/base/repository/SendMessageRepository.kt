package ru.minegoat.oversees.modules.base.repository


import io.reactivex.Completable
import io.reactivex.Single
import ru.minegoat.oversees.modules.base.model.SendMessageModelUi
import ru.minegoat.oversees.modules.base.model.toNetwork
import ru.minegoat.oversees.modules.base.network.SendMessageApi
import javax.inject.Inject

class SendMessageRepository @Inject constructor(
    private val api: SendMessageApi,
) {
    fun connectUsMessage(sendMessageModelUi: SendMessageModelUi): Completable {
        return api.sendMessage(sendMessageModelUi.toNetwork())
    }
}