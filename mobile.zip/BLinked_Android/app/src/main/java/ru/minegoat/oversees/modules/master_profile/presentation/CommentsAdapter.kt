package ru.minegoat.oversees.modules.master_profile.presentation

import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.chip.Chip
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.ItemFeedbackFromClientBinding
import ru.minegoat.oversees.databinding.ItemFeedbackFromMasterBinding
import ru.minegoat.oversees.domain.feedback.Comment
import ru.minegoat.oversees.domain.user.FeedbackType

class FeedbackAdapter(private val isMaster: Boolean) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var mastersComments = mutableListOf<Comment>()
    var usersComments = mutableListOf<Comment>()

    inner class MasterViewHolder(root: View) : RecyclerView.ViewHolder(root) {

        private val binding by viewBinding(ItemFeedbackFromMasterBinding::bind)

        fun bind(comment: Comment) {
            binding.apply {
                tvName.text = comment.user.name
                for (i in 0 until comment.tags.size)
                    (cgMaster.getChildAt(i) as Chip).text = comment.tags[i]
                checkLength(comment.content, tvComment)
                tvDate.text = comment.date.toString()
                ratingView.setRating(comment.rating)
            }
        }
    }

    inner class ClientViewHolder(root: View) : RecyclerView.ViewHolder(root) {

        private val binding by viewBinding(ItemFeedbackFromClientBinding::bind)

        fun bind(comment: Comment) {
            binding.apply {
                tvName.text = comment.user.name
                for (i in 0 until comment.tags.size)
                    (cgClient.getChildAt(i) as Chip).text = comment.tags[i]
                checkLength(comment.content, tvComment)
                tvRating.text = "4.7"
                tvDate.text = comment.date.toString()
                ratingView.setRating(comment.rating)
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder.itemViewType == MASTER_VIEW_TYPE) {
            val viewHolder = holder as MasterViewHolder
            viewHolder.bind(mastersComments[position])
        } else {
            val viewHolder = holder as ClientViewHolder
            viewHolder.bind(usersComments[position])
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        if (viewType == MASTER_VIEW_TYPE) {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_feedback_from_master, parent, false)
            MasterViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_feedback_from_client, parent, false)
            ClientViewHolder(view)
        }

    override fun getItemViewType(position: Int) =
        if (isMaster) MASTER_VIEW_TYPE else CLIENT_VIEW_TYPE

    override fun getItemCount() = if (isMaster) mastersComments.size else usersComments.size

    private fun TextView.expandedText(text: String) {
        val ellipsis = resources.getString(R.string.more_type_2)
        val ellipsisColor = resources.getColor(R.color.primary_100, context.theme)
        val shortenedText = text.substring(0..MAX_LENGTH)
        val lastSpaceIndex = shortenedText.lastIndexOf(" ")
        val resultText =
            SpannableString("${shortenedText.substring(0 until lastSpaceIndex)}... $ellipsis")
        resultText.setSpan(
            ForegroundColorSpan(ellipsisColor),
            resultText.length - ellipsis.length,
            resultText.length,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        this.text = resultText
    }

    private fun checkLength(text: String, tvComment: TextView) {
        if (text.length > MAX_LENGTH) {
            tvComment.expandedText(text)
            tvComment.setOnClickListener {
                if (tvComment.text.length > MAX_LENGTH + ELLIPSIS_LENGTH)
                    tvComment.expandedText(text)
                else
                    tvComment.text = text
            }
        } else
            tvComment.text = text
    }

    companion object {
        private const val MASTER_VIEW_TYPE = 1
        private const val CLIENT_VIEW_TYPE = 2
        private const val ELLIPSIS_LENGTH = 7
        private const val MAX_LENGTH = 100
    }
}