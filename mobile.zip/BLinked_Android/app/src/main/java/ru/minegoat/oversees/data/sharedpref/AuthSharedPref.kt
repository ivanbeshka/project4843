package ru.minegoat.oversees.data.sharedpref

import android.content.Context
import java.time.LocalDateTime
import javax.inject.Inject

class AuthSharedPref @Inject constructor(context: Context) {

    private val preferences = context.getSharedPreferences(SHARED_PREF_KEY, Context.MODE_PRIVATE)

    var userId: String?
        get() {
            return preferences.getString(USER_ID, null)
        }
        set(value) {
            value?.let {
                preferences.edit()
                    .putString(USER_ID, it)
                    .apply()
            }
        }

    var token: String?
        get() {
            return preferences.getString(TOKEN_KEY, null)
        }
        set(value) {
            value?.let {
                preferences.edit()
                    .putString(TOKEN_KEY, it)
                    .apply()
            }
        }

    var tokenExpiresAt: LocalDateTime?
        get() {
            val stringDateTime = preferences.getString(TOKEN_EXPIRES_AT_KEY, null)
            stringDateTime?.let {
                return LocalDateTime.parse(it)
            }
            return null
        }
        set(value) {
            value?.let {
                preferences.edit()
                    .putString(TOKEN_EXPIRES_AT_KEY, it.toString())
                    .apply()
            }
        }

    var login: String?
        get() {
            return preferences.getString(LOGIN_KEY, null)
        }
        set(value) {
            value?.let {
                preferences.edit()
                    .putString(LOGIN_KEY, it)
                    .apply()
            }
        }

    var password: String?
        get() {
            return preferences.getString(PASSWORD_KEY, null)
        }
        set(value) {
            value?.let {
                preferences.edit()
                    .putString(PASSWORD_KEY, it)
                    .apply()
            }
        }

    var isDeleted: Boolean
        get() {
            return preferences.getBoolean(IS_ACC_DELETED, false)
        }
        set(value) {
            value.let {
                preferences.edit()
                    .putBoolean(IS_ACC_DELETED, it)
                    .apply()
            }
        }

    var isMaster: Boolean?
    get(){
        return preferences.getBoolean(IS_MASTER_KEY, false)
    }
    set(value) {
        value?.let {
            preferences.edit()
                .putBoolean(IS_MASTER_KEY, it)
                .apply()
        }
    }

    fun clear() {
        preferences.edit().clear().apply()
    }


    private companion object {
        private const val SHARED_PREF_KEY = "auth_shared_pref"
        private const val USER_ID = "user_id"
        private const val TOKEN_KEY = "token"
        private const val LOGIN_KEY = "login"
        private const val PASSWORD_KEY = "password"
        private const val TOKEN_EXPIRES_AT_KEY = "token_expires_at"
        private const val IS_ACC_DELETED = "is_acc_deleted"
        private const val IS_MASTER_KEY = "is_master"
    }
}