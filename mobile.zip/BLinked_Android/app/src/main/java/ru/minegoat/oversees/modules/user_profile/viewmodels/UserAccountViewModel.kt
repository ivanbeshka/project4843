package ru.minegoat.oversees.modules.user_profile.viewmodels

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.Completable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.base.helpers.file_manager.FileManager
import ru.minegoat.oversees.base.viewmodels.*
import ru.minegoat.oversees.data.repository.user.UserRepository
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import ru.minegoat.oversees.domain.user.RequestMasterStatus
import ru.minegoat.oversees.domain.user.ShortUser
import ru.minegoat.oversees.modules.user_profile.repository.AccDataRepository

class UserAccountViewModel @AssistedInject constructor(
    private val userRepository: UserRepository,
    private val accDataRepository: AccDataRepository,
    private val authSharedPref: AuthSharedPref
) : RxViewModel() {

    private val userLiveData = MutableLiveData<ScreenState<ShortUser>>()
    val user: LiveData<ScreenState<ShortUser>> = userLiveData

    private val userRequestStatus =
        MutableLiveData<ScreenState<RequestMasterStatus>>()
    val status: LiveData<ScreenState<RequestMasterStatus>> = userRequestStatus

    private val _logout = MutableLiveData<ScreenState<Boolean>>()
    val logout: LiveData<ScreenState<Boolean>> get()= _logout


    fun saveUserStatus(requestMasterStatus: RequestMasterStatus) {
        userRepository.saveUserRequestToMaster(
            userStatus = requestMasterStatus
        ).subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { userRequestStatus.value = LoadingScreenState() }
            .subscribeBy(
                onComplete = {
                    userRequestStatus.value = SuccessScreenState(
                        requestMasterStatus
                    )
                },
                onError = {
                    userRequestStatus.value = ErrorScreenState(it)
                }
            ).disposeOnFinish()
    }


    fun getUserStatus(userId: String) {
        return userRepository.getUserRequestStatus(userId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { userRequestStatus.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    userRequestStatus.value = SuccessScreenState(
                        it
                    )
                },
                onError = {
                    userRequestStatus.value = ErrorScreenState(it)
                }
            ).disposeOnFinish()
    }


    fun getUserInfo(userId: String) {
        return userRepository.getUser(userId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { userLiveData.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    Log.d("AccountViewModel", "getUserProfile: $it")
                    userLiveData.value = SuccessScreenState(it)
                },
                onError = {
                    it.printStackTrace()
                    userLiveData.value = ErrorScreenState(it)
                },
            )
            .disposeOnFinish()

    }

    fun logout() = accDataRepository.clearAllDataFromDB()

//        Completable.create {
//            try {
////                .blockingGet()
//                authSharedPref.clear()
//                it.onComplete()
//            } catch (e:Exception){
//                it.onError(e)
//            }
//        }


    @AssistedFactory
    interface Factory {
        fun create(): UserAccountViewModel
    }
}