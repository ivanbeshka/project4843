package ru.minegoat.oversees.domain

import ru.minegoat.oversees.domain.user.ShortUser

data class ShortTrip (
    val name: String? = null,
    val objId: String,
    val owner: ShortUser,
    val startDate: Long? = null,
    val endDate: Long? = null,
    val tags: String? = null,
    val mainImage: String? = null,
    val reviewsNumber: Int? = null,
    val shortMilestones: List<ShortMilestone>? = null,
    val cost: String? = null,
    val users: List<ShortUser>? = null,
)