package ru.minegoat.oversees.modules.user_profile.model

data class ProgressData(
    val name: String?,
    val sign: Int?,
    val progressLevel: Int?,
    val info: List<Any?>?
)
