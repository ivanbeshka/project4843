package ru.minegoat.oversees.modules.base.model
import ru.minegoat.oversees.modules.base.network.model.SendConnectUs
import ru.minegoat.oversees.modules.base.network.model.SendConnectUsMessage


data class SendMessageModelUi(
    val additional: String,
    val name: String,
    val description: String,
    val type: String,
)

fun SendMessageModelUi.toNetwork(): SendConnectUs {
    return SendConnectUs(
        listOf(
            SendConnectUsMessage(
                additional = additional,
                name = name,
                description = description,
                type = type
            )
        )
    )
}