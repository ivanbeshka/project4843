package ru.minegoat.oversees.data.network.syncer.model

import com.google.gson.annotations.SerializedName

data class SyncItemObjRequest(
    @SerializedName("sessionID")
    val sessionID: String,
    @SerializedName("lastSuccessfulSyncDate")
    val lastSuccessfulSync: Long
)
