package ru.minegoat.oversees.modules.user_profile.presentation

import android.media.metrics.Event
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.paging.DifferCallback
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding
import com.google.android.flexbox.FlexboxLayout
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.loadImageFromOurApi
import ru.minegoat.oversees.databinding.ItemEventNewBinding
import ru.minegoat.oversees.databinding.ItemMonthBinding
import ru.minegoat.oversees.modules.user_profile.model.EventsUi

class DetailEventAdapter(
    private val onClick: (masterId: String) -> Unit
) : ListAdapter<EventsUi, DetailEventAdapter.DetailEventHolder>(DiffCallback) {

    sealed class DetailEventHolder(binding: ViewBinding) : RecyclerView.ViewHolder(binding.root) {

        class EventHolder(private val binding: ItemEventNewBinding) : DetailEventHolder(binding) {
            fun bind(event: EventsUi.EventUi, onClick: (eventId: String) -> Unit) {
                binding.apply {
                    tvEventName.text = event.name
                    tvLocation.text = event.location
                    tvEventPrice.text = event.price
                    tvEventType.text = event.type
                    tvCountMasters.text = event.countMasters.toString()
                    viewLike.ivLike.isSelected = event.isLiked
                    tvEventDate.text = event.date
                    if (event.isStarted) {
                        chipStarted.visibility = View.VISIBLE
                    } else {
                        chipStarted.visibility = View.GONE
                    }
                    if (event.isOnline) {
                        chipOnline.visibility = View.VISIBLE
                        chipInternal.visibility = View.GONE
                    } else {
                        chipOnline.visibility = View.GONE
                        chipInternal.visibility = View.VISIBLE
                    }

                    for (tag in event.tags) {
                        val textView = TextView(itemView.context)
                        textView.layoutParams = FlexboxLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                        textView.setTextAppearance(R.style.Subtitle_S)

                        textView.setTextColor(itemView.context.getColor(R.color.primary_100))
                        textView.text = tag

                        fblEventHashtags.addView(textView)
                    }

                    event.avatarUrl?.let {
                        loadImageFromOurApi(
                            binding.ivEventImage,
                            it
                        )
                    }

                }
            }
        }

        class MonthHolder(private val binding: ItemMonthBinding) : DetailEventHolder(binding) {
            fun bind(month: EventsUi.MonthUi) {
                binding.tvDate.text = month.month + ", " + month.year
            }
        }
    }

    companion object {
        private val DiffCallback = object : DiffUtil.ItemCallback<EventsUi>() {
            override fun areItemsTheSame(oldItem: EventsUi, newItem: EventsUi): Boolean {
                return if (oldItem is EventsUi.EventUi && newItem is EventsUi.EventUi) {
                    (oldItem.eventId == newItem.eventId)
                } else
                    if (oldItem is EventsUi.MonthUi && newItem is EventsUi.MonthUi) {
                        oldItem.year == newItem.year &&
                                oldItem.month == oldItem.month
                    } else false
            }

            override fun areContentsTheSame(oldItem: EventsUi, newItem: EventsUi): Boolean {
                return if (oldItem is EventsUi.EventUi && newItem is EventsUi.EventUi) {
                    (oldItem.name == newItem.name &&
                            oldItem.type == newItem.type &&
                            oldItem.price == newItem.price &&
                            oldItem.tags == newItem.tags &&
                            oldItem.isStarted == newItem.isStarted &&
                            oldItem.isOnline == newItem.isOnline &&
                            oldItem.isLiked == newItem.isLiked &&
                            oldItem.avatarUrl == newItem.avatarUrl &&
                            oldItem.countMasters == newItem.countMasters &&
                            oldItem.date == newItem.date &&
                            oldItem.location == newItem.location
                            )
                } else
                    if (oldItem is EventsUi.MonthUi && newItem is EventsUi.MonthUi) {
                        return true
                    } else false
            }

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DetailEventHolder {
        if (viewType == R.layout.item_event_new){
            val binding = ItemEventNewBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
            return DetailEventHolder.EventHolder(binding)
        }
        else{
            val binding = ItemMonthBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
            return DetailEventHolder.MonthHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: DetailEventHolder, position: Int) {
        if (holder is DetailEventHolder.EventHolder) {
                val item  = getItem(position) as EventsUi.EventUi
                holder.bind(item, onClick)
        }
        else
        if (holder is DetailEventHolder.MonthHolder){
            val item = getItem(position) as EventsUi.MonthUi
            holder.bind(item)
        }
    }

    override fun getItemViewType(position: Int): Int {
        return when(getItem(position)){
            is EventsUi.EventUi -> R.layout.item_event_new
            is EventsUi.MonthUi -> R.layout.item_month
        }
    }

}