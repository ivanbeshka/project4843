package ru.minegoat.oversees.domain.user

import android.content.Context
import ru.minegoat.oversees.R

enum class Sex {
    UNDEFINED,
    MAN,
    WOMAN;

    val res: Int
        get() {
            return when (this) {
                MAN -> R.string.man
                WOMAN -> R.string.woman
                UNDEFINED -> R.string.sex_undefined
            }
        }

    companion object {
        fun fromStringByRes(string: String, context: Context): Sex {
            return when (string) {
                context.getString(R.string.sex_undefined) -> UNDEFINED
                context.getString(R.string.man) -> MAN
                context.getString(R.string.woman) -> WOMAN
                else -> throw IllegalStateException()
            }
        }
    }
}