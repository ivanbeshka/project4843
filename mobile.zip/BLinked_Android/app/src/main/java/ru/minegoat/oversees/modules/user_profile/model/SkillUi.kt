package ru.minegoat.oversees.modules.user_profile.model


   data class SkillUi(
        val objId: String,
        val tags: List<String>,
        val name: String
    )


