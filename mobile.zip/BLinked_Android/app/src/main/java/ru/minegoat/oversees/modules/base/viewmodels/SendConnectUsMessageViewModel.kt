package ru.minegoat.oversees.modules.base.viewmodels

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.base.viewmodels.*
import ru.minegoat.oversees.data.repository.user.UserRepository
import ru.minegoat.oversees.domain.auth.Phone
import ru.minegoat.oversees.domain.user.CountryPhone
import ru.minegoat.oversees.domain.user.RequestMasterStatus
import ru.minegoat.oversees.domain.user.SocialNetwork
import ru.minegoat.oversees.domain.user.SocialNetworkName
import ru.minegoat.oversees.modules.base.model.SendMessageModelUi
import ru.minegoat.oversees.modules.base.repository.SendMessageRepository

class SendConnectUsMessageViewModel @AssistedInject constructor(
    private val sendMessageRepository: SendMessageRepository,
    private val userRepository: UserRepository
) : RxViewModel() {

    private val newMessage = MutableLiveData<SendMessageModelUi>()
    val newMessageLiveData = newMessage

    private val isSendMessage = MutableLiveData<ScreenState<Boolean>>()
    val isSend: LiveData<ScreenState<Boolean>> = isSendMessage

    private val userRequestStatus =
        MutableLiveData<ScreenState<RequestMasterStatus>>()
    val status: LiveData<ScreenState<RequestMasterStatus>> = userRequestStatus

    private val list: List<SocialNetwork> = listOf(
        SocialNetwork(SocialNetworkName.INSTAGRAM, "http://instagram.com/"),
        SocialNetwork(SocialNetworkName.VK, "http://vk.com/"),
        SocialNetwork(SocialNetworkName.TELEGRAM, "http://tg.me/")
    )

    fun getInstagram(): SocialNetwork {
        return list[0]
    }

    fun getVk () : SocialNetwork {
        return list[1]
    }

    fun getTelegram() : SocialNetwork {
        return list[2]
    }

    var phone: Phone = Phone("RU", "+7", "")

    private val _isCountryPhoneSet = MutableLiveData<CountryPhone>()
    val isCountryPhoneSet: LiveData<CountryPhone> = _isCountryPhoneSet

    fun setCountryPhone(countryPhone: CountryPhone) {
        _isCountryPhoneSet.postValue(countryPhone)
    }

    fun cancelRequest(userId: String)= userRepository.cancelRequest(userId)

    fun sendMessage(sendMessageModelUi: SendMessageModelUi) {
        sendMessageRepository.connectUsMessage(sendMessageModelUi)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe {
                isSendMessage.value = LoadingScreenState()
                newMessage.value = sendMessageModelUi
            }
            .subscribeBy(
                onComplete = {
                    isSendMessage.value = SuccessScreenState(true)
                    newMessage.value = sendMessageModelUi
                    Log.d("message", "Success")
                },
                onError = {
                    isSendMessage.value = ErrorScreenState(it)
                    it.printStackTrace()
                    Log.d("message", "Error")
                }
            ).disposeOnFinish()
    }

    fun getUserStatus(userId: String) {
        return userRepository.getUserRequestStatus(userId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { userRequestStatus.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    userRequestStatus.value = SuccessScreenState(
                        it
                    )
                },
                onError = {
                    userRequestStatus.value = ErrorScreenState(it)
                }
            ).disposeOnFinish()
    }

    @AssistedFactory
    interface Factory {
        fun create(): SendConnectUsMessageViewModel
    }
}



