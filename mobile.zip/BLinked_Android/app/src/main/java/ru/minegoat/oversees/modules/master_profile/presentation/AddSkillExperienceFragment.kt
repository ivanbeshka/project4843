package ru.minegoat.oversees.modules.master_profile.presentation

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.chip.Chip
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.databinding.FragmentAddSkillExperienceBinding
import ru.minegoat.oversees.domain.user.MasterSkill
import ru.minegoat.oversees.modules.user_profile.di.UserProfileComponentHolder
import ru.minegoat.oversees.modules.user_profile.presentation.UserProfileFragment

class AddSkillExperienceFragment : Fragment(R.layout.fragment_add_skill_experience) {

    private val binding by viewBinding(FragmentAddSkillExperienceBinding::bind)

    private val component by featureComponent(UserProfileComponentHolder)

    private val skillViewModel by lazyViewModel {
        component.skillsViewModel().create()
    }

    private val addUserSkillViewModel by lazyViewModel {
        component.addUserSkillViewModel().create()
    }

    private val userProfileViewModel by lazyViewModel {
        component.userProfileViewModel().create()
    }

    private val editUserViewModel by lazyViewModel {
        component.editUserProfileViewModel().create()
    }

    var newMasterSkill: MasterSkill? = null
    var masterSkills: List<MasterSkill>? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        userProfileViewModel.getUserProfile(UserProfileFragment.ProfileType.MY)

        userProfileViewModel.user.observe(viewLifecycleOwner) { state ->
            state.on(success = {
                editUserViewModel.setUser(it)
                it.skills?.let { skills ->
                    masterSkills = skills
                }
            }, error = {
                //todo check internet connection
                Log.e("SkillsViewModel", "getUserProfile: ${it.message}", it)
            })
        }

        etExperienceChangeListeners()
        setOnToolbarClickListeners()
        arguments?.getString(SKILL_ID_BUNDLE_KEY)?.let {
            getSkill(it)
        }


        with(binding) {
            readyButton.setOnClickListener {
                saveUserSkill()
                findNavController().navigate(R.id.action_addSkillExperienceFragment_to_userTechniquesFragment)
            }
        }
    }

    private fun getSkill(skillId: String) {
        with(binding) {
            skillViewModel.getSkillById(skillId).observe(viewLifecycleOwner) { state ->
                state.on(
                    success = { skill ->
                        newMasterSkill = MasterSkill(
                            objId = skill.objId,
                        )
                        tvSkillName.text = skill.name
                        skill.tags?.let {
                            initTags(it)
                        }
                    },
                    error = {
                        Log.d("SkillsViewModel", "getSkillById ${it.message}")
                    }
                )
            }
        }
    }

    private fun saveUserSkill() {
        newMasterSkill?.let {

            val newMasterSkills = masterSkills?.toMutableList()
            val experience = binding.skillExperienceEditText.text.toString()
            val masterSkill = MasterSkill(it.objId, experience)

            addUserSkillViewModel.setNewMasterSkill(masterSkill)
            newMasterSkills?.add(masterSkill)

            editUserViewModel.setUser(skills = newMasterSkills)
            editUserViewModel.saveUserProfileForSkills()
//            addUserSkillViewModel.saveNewMasterSkill(experience)
        }
    }

    private fun setOnToolbarClickListeners() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigate(R.id.action_addSkillExperienceFragment_to_userTechniquesFragment)
        }
    }

    private fun initTags(tags: List<String>) {
        val layoutInflater = LayoutInflater.from(context)
        for (tag in tags) {
            val chip =
                layoutInflater.inflate(
                    R.layout.item_tag_chip,
                    binding.tagsGroup,
                    false
                ) as Chip
            chip.text = "$tag"
            chip.isClickable = true
            binding.tagsGroup.addView(chip)
        }
    }

    private fun etExperienceChangeListeners() {
        binding.skillExperienceEditText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                s?.let {
                    binding.readyButton.isVisible = s.isNotEmpty()
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.readyButton.isVisible = count > 0
            }
        })
    }

    companion object {
        const val SKILL_ID_BUNDLE_KEY = "skill_name_bundle"
    }
}