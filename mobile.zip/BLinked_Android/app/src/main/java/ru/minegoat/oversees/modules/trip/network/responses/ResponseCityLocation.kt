package ru.minegoat.oversees.modules.trip.network.responses

import com.google.gson.annotations.SerializedName

data class ResponseCityLocation(
    @SerializedName("address")
    val address: String?,
    @SerializedName("cityLocation")
    val cityLocation: Any?,
    @SerializedName("codeIATA")
    val codeIATA: Any?,
    @SerializedName("countryCode")
    val countryCode: String?,
    @SerializedName("countryLocation")
    val countryLocation: ResponseLocationCountry?,
    @SerializedName("externalPlaceId")
    val externalPlaceId: String?,
    @SerializedName("internationalAddress")
    val internationalAddress: String?,
    @SerializedName("internationalName")
    val internationalName: String?,
    @SerializedName("lat")
    val lat: Double?,
    @SerializedName("lon")
    val lon: Double?,
    @SerializedName("name")
    val name: String?,
    @SerializedName("objID")
    val objID: String?,
    @SerializedName("phoneNumber")
    val phoneNumber: Any?,
    @SerializedName("searchTags")
    val searchTags: Any?,
    @SerializedName("timeZone")
    val timeZone: String?,
    @SerializedName("type")
    val type: String?,
    @SerializedName("website")
    val website: Any?
)