package ru.minegoat.oversees.base.utils

import com.google.android.gms.maps.model.LatLng

fun latitudeLongitudeToLatLng(latitude: Double?, longitude: Double?): LatLng? {
    return if (latitude != null && longitude != null) {
        LatLng(latitude, longitude)
    } else {
        null
    }
}