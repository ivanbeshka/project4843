package ru.minegoat.oversees.modules.search.presentation

import android.annotation.SuppressLint
import android.app.ActionBar.LayoutParams
import android.graphics.Rect
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.core.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResultListener
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.databinding.FragmentSearchBinding
import ru.minegoat.oversees.domain.ShortTrip
import ru.minegoat.oversees.domain.user.ShortUser
import ru.minegoat.oversees.domain.user.Skill
import ru.minegoat.oversees.modules.map.presentation.search.SearchLocationsFragment
import ru.minegoat.oversees.modules.search.di.SearchComponentHolder
import ru.minegoat.oversees.modules.search.model.FilterType
import ru.minegoat.oversees.modules.search.model.SelectedFilter
import ru.minegoat.oversees.modules.user_profile.presentation.UserProfileFragment

class SearchFragment : Fragment() {

    private val component by featureComponent(SearchComponentHolder)

    private val viewModel by lazyViewModel {
        component.searchViewModel().create()
    }

    private var eventsAdapter : EventsAdapter? = null
    private var mastersAdapter : MastersAdapter? = null
    private var skillsAdapter : SkillsAdapter? = null

    private val filterNameToId by lazy {
        mapOf(
            resources.getString(R.string.places) to R.string.places,
            resources.getString(R.string.techniques) to R.string.techniques,
            resources.getString(R.string.masters) to R.string.masters,
            resources.getString(R.string.events) to R.string.events
        )
    }

    override fun onDestroyView() {
        eventsAdapter = null
        mastersAdapter = null
        skillsAdapter = null
        super.onDestroyView()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val binding = FragmentSearchBinding.inflate(inflater, container, false)

        eventsAdapter = createEventsAdapter()
        mastersAdapter = createMastersAdapter()
        //skillsAdapter = createSkillsAdapter()

        with(binding) {
            setViewPagerMargins(
                vpEvents,
                resources.getDimension(R.dimen.fragment_search_events_visible_part_of_next_item),
                resources.getDimension(R.dimen.fragment_search_events_current_item_margins)
            )

            setViewPagerMargins(
                vpMasters,
                resources.getDimension(R.dimen.fragment_search_masters_visible_part_of_next_item),
                resources.getDimension(R.dimen.fragment_search_masters_current_item_margins)
            )

            setViewPagerMargins(
                vpSkills,
                resources.getDimension(R.dimen.fragment_search_masters_visible_part_of_next_item),
                resources.getDimension(R.dimen.fragment_search_masters_current_item_margins)
            )

            setFiltersGroupCheckedChangeListener(binding)
            setSubfiltersGroupCheckedStateChangedListener(binding)

            binding.viewSearch.tilSearch.setOnClickListener {
                navigateToSearchLocationsFragment(binding)
            }
            binding.viewSearch.etSearch.setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    navigateToSearchLocationsFragment(binding)
                }
            }
            setSearchLocationResultListener(binding)

            viewModel.getSelectedSubFilters().observe(viewLifecycleOwner){
                it?.let { selectedFilters ->
                    setSelectedFiltersViews(binding, selectedFilters)
                }
            }

            viewModel.getSelectedFilter().observe(viewLifecycleOwner){
                it?.let { filterType ->
                    when (filterType){
                        FilterType.PLACES -> {
                            binding.viewSearch.etSearch.clearFocus()
                            binding.viewSearch.tilSearch.clearFocus()
                            binding.subfiltersGroup.removeAllViews()
                        }
                        FilterType.EVENTS -> setSubFilters(binding)
                        FilterType.MASTERS -> setSubFilters(binding)
                        FilterType.TECHNIQUES -> setSubFilters(binding)
                    }
                }
            }

            tvSeeAllEvents.setOnClickListener {
                println("Здесь будет переход в список всех мероприятий")
            }

            tvSeeAllMasters.setOnClickListener {
                println("Здесь будет переход в список всех мастеров")
            }

            tvSeeAllSkills.setOnClickListener {
                println("Здесь будет переход в список всех техник")
            }

            vpEvents.adapter = eventsAdapter
            loadEvents(binding, "62dbb9eb3ff8a7eab1928acc")

            vpMasters.adapter = mastersAdapter
            loadMasters(binding)

            vpSkills.adapter = skillsAdapter
            loadSkills(binding)

        }

        return binding.root
    }

    private fun setViewPagerMargins(viewPager: ViewPager2, visiblePartOfNextItem: Float, currentItemMargins: Float){
        @SuppressLint("WrongConstant")
        viewPager.offscreenPageLimit = OFFSCREEN_PAGE_LIMIT
        val pageTranslationX = visiblePartOfNextItem + currentItemMargins

        viewPager.setPageTransformer { page: View, position: Float ->
            page.translationX = -pageTranslationX * position
        }
        viewPager.addItemDecoration(
            HorizontalMarginItemDecoration(
                currentItemMargins.toInt()
            )
        )
    }

    private fun setSearchLocationResultListener(binding: FragmentSearchBinding) {
        setFragmentResultListener(SearchLocationsFragment.REQUEST_KEY_LOCATION_MAP) { _, bundle ->
            val objID = bundle.getString(SearchLocationsFragment.BUNDLE_KEY_LOCATION_ID)
            objID?.let { id ->
                viewModel.getLocationById(id).observe(viewLifecycleOwner) { state ->
                    state.on(
                        success = {
                            binding.viewSearch.etSearch.setText(it.name)
                            it.name?.let { locationName ->
                                addSelectedFilter(binding, SelectedFilter(FilterType.PLACES, locationName))
                            }
                            loadEvents(binding, it.objID)
                        },
                        error = {
                            Log.d("Error", "onGetLocation: ${it.message}")
                        }
                    )
                }
            }
        }
    }

    private fun getSelectedFilter(binding: FragmentSearchBinding) : FilterType? {
        val checkedId = binding.filtersGroup.checkedChipId
        val selectedFilterText = binding.filtersGroup.findViewById<Chip>(checkedId).text.toString()
        val selectedResourceId = filterNameToId[selectedFilterText]

        selectedResourceId?.let {
            return FilterType.getValueByStringResource(it)
        }

        return null
    }

    private fun navigateToSearchLocationsFragment(binding: FragmentSearchBinding){
        getSelectedFilter(binding)?.let {
            if (it == FilterType.PLACES){
                findNavController().navigate(R.id.action_searchFragment_to_searchLocationFragment)
            }
        }
    }

    private fun loadEvents(binding: FragmentSearchBinding, locationId: String){
        setEventsIsLoading(binding, true)
        viewModel.getShortTripList(locationId)
            .observe(viewLifecycleOwner) { state ->
                state.on(
                    success = { tripList ->
                        val tripsToDisplay = mutableListOf<ShortTrip>()
                        tripList.forEach {
                            tripsToDisplay.add(it)
                        }
                        eventsAdapter?.let { adapter ->
                            adapter.data = tripsToDisplay.toList()
                        }
                        setEventsIsLoading(binding, false)
                    },
                    error = {
                        Log.d("Error", "onLoadingTrips ${it.message}")
                    }
                )
            }
    }

    private fun setEventsIsLoading(binding: FragmentSearchBinding, isLoading: Boolean){
        eventsAdapter?.let{ eventsAdapter ->
            binding.pbEventsLoading.isVisible = isLoading
            binding.tvSeeAllEvents.isVisible = !isLoading && eventsAdapter.itemCount > 0
        }
    }

    private fun loadMasters(binding: FragmentSearchBinding){
        setMastersIsLoading(binding, true)
        viewModel.getMastersList()
            .observe(viewLifecycleOwner) { state ->
                state.on(
                    success = { tripList ->
                        val mastersToDisplay = mutableListOf<ShortUser>()
                        tripList.forEach {
                            if (it.isMaster!=null && it.isMaster==false){
                                mastersToDisplay.add(it)
                            }
                        }
                        mastersAdapter?.let { adapter ->
                            adapter.data = mastersToDisplay.toList()
                        }
                        setMastersIsLoading(binding, false)
                    },
                    error = {
                        Log.d("Error", "onLoadingMasters ${it.message}")
                    }
                )
            }
    }

    private fun setMastersIsLoading(binding: FragmentSearchBinding, isLoading: Boolean){
        mastersAdapter?.let{ mastersAdapter ->
            binding.pbMastersLoading.isVisible = isLoading
            binding.tvSeeAllMasters.isVisible = !isLoading && mastersAdapter.itemCount > 0
        }
    }

    private fun loadSkills(binding: FragmentSearchBinding){
        setSkillsIsLoading(binding, true)
        viewModel.getSkillsList()
            .observe(viewLifecycleOwner) { state ->
                state.on(
                    success = { tripList ->
                        val skillsToDisplay = mutableListOf<Skill>()
                        tripList.forEach {
                            skillsToDisplay.add(it)
                        }
                        skillsAdapter?.let { adapter ->
                            adapter.data = skillsToDisplay.toList()
                        }
                        setSkillsIsLoading(binding, false)
                    },
                    error = {
                        Log.d("Error", "onLoadingSkills ${it.message}")
                    }
                )
            }
    }

    private fun setSkillsIsLoading(binding: FragmentSearchBinding, isLoading: Boolean){
        skillsAdapter?.let{ skillsAdapter ->
            binding.pbSkillsLoading.isVisible = isLoading
            binding.tvSeeAllSkills.isVisible = !isLoading && skillsAdapter.itemCount > 0
        }
    }

    private fun removeSelectedFilter(binding: FragmentSearchBinding, selectedFilter: SelectedFilter){
        binding.selectedFiltersGroup.removeView(
            binding.selectedFiltersGroup.children.find { view ->
                (view as Chip).text.equals(selectedFilter.filterValue)
        })

        viewModel.removeSelectedSubFilter(selectedFilter)

        binding.subfiltersGroup.children.forEach { view ->
            val chip = view as Chip
            if (chip.isChecked && chip.text.equals(selectedFilter.filterValue)){
                chip.isChecked = false
            }
        }

        setFilterMargins(
            binding.selectedFiltersGroup,
            resources.getDimensionPixelSize(R.dimen.fragment_search_filters_group_margins)
        )
    }

    private fun setSelectedFiltersViews(binding: FragmentSearchBinding, selectedFilters: List<SelectedFilter>){
        binding.selectedFiltersGroup.removeAllViews()

        for (selectedFilter in selectedFilters){
            val chip = layoutInflater.inflate(
                R.layout.view_selected_filter_chip,
                binding.subfiltersGroup,
                false
            ) as Chip

            chip.setTextAppearance(R.style.SelectedFilterChipStyle)
            chip.id = binding.selectedFiltersGroup.size
            chip.text = selectedFilter.filterValue
            chip.isCheckable = false
            chip.setOnCloseIconClickListener {
                removeSelectedFilter(binding, selectedFilter)
            }

            binding.selectedFiltersGroup.addView(chip)

            setFilterMargins(
                binding.selectedFiltersGroup,
                resources.getDimensionPixelSize(R.dimen.fragment_search_filters_group_margins)
            )
        }
    }

    private fun addSelectedFilter(binding: FragmentSearchBinding, selectedFilter: SelectedFilter){
        if (viewModel.isSubFilterSelected(selectedFilter)){
            return
        }

        if (selectedFilter.filterType == FilterType.PLACES){
            viewModel.getSelectedSubFilters().value?.forEach { filter ->
                if (filter.filterType == FilterType.PLACES){
                    viewModel.removeSelectedSubFilter(filter)
                }
            }
        }

        viewModel.addSelectedSubFilter(selectedFilter)
    }

    private fun setFilterMargins(group: ChipGroup, spaceSizeDp: Int){
        for ((index, view) in group.children.withIndex()) {
            val layoutParams = ChipGroup.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)

            if (index == FIRST_ELEMENT_INDEX){
                layoutParams.marginStart = spaceSizeDp
            }
            else if (index == group.size - 1){
                layoutParams.marginEnd = spaceSizeDp
            }

            view.layoutParams = layoutParams
        }
    }

    private fun setSubfiltersGroupCheckedStateChangedListener(binding: FragmentSearchBinding){
        binding.subfiltersGroup.setOnCheckedStateChangeListener { _, _ ->
            binding.subfiltersGroup.children.forEach { view ->
                getSelectedFilter(binding)?.let { selectedFilterType ->
                    val chip = view as Chip
                    val selectedFilter = SelectedFilter(selectedFilterType, chip.text)

                    if (!chip.isChecked){
                        removeSelectedFilter(binding, selectedFilter)
                    }
                    else{
                        addSelectedFilter(binding, selectedFilter)
                    }
                }
            }
        }
    }

    private fun setSubFilters(binding: FragmentSearchBinding){
        getSelectedFilter(binding)?.let { selectedFilterType ->
            binding.subfiltersGroup.removeAllViews()

            val filters = arrayOf("Подфильтр 1", "Подфильтр 2", "Подфильтр 3", "Подфильтр 4", "Еще")

            for ((i, name) in filters.withIndex()) {
                val chip = layoutInflater.inflate(
                    R.layout.view_filter_chip,
                    binding.subfiltersGroup,
                    false
                ) as Chip

                chip.setTextAppearance(R.style.FilterChipStyle)
                chip.id = i
                chip.text = name
                chip.isCheckable = i < filters.size-1
                chip.isChecked = viewModel.isSubFilterSelected(SelectedFilter(selectedFilterType, name))

                binding.subfiltersGroup.addView(chip)
            }

            setFilterMargins(
                binding.subfiltersGroup,
                resources.getDimensionPixelSize(R.dimen.fragment_search_filters_group_margins)
            )
        }
    }

    private fun setFiltersGroupCheckedChangeListener(binding: FragmentSearchBinding){
        binding.filtersGroup.setOnCheckedStateChangeListener { group, _ ->
            val checkedId = group.checkedChipId

            if (checkedId == ELEMENT_NOT_SELECTED_INDEX){
                binding.subfiltersGroup.removeAllViews()
                return@setOnCheckedStateChangeListener
            }

            getSelectedFilter(binding)?.let {
                viewModel.setSelectedFilter(it)
            }
        }
    }

    private fun createEventsAdapter(): EventsAdapter {
        return EventsAdapter {
                objID -> println("Здесь будет переход в детальный экран путешествия $objID")
        }
    }

    private fun createMastersAdapter(): MastersAdapter {
        return MastersAdapter { objID ->
            SearchFragmentDirections.actionSearchFragmentToUserProfileFragment().let { action ->
                findNavController().navigate(
                    action.actionId,
                    bundleOf(
                        UserProfileFragment.PROFILE_TYPE_KEY to UserProfileFragment.ProfileType.OTHER.ordinal,
                        UserProfileFragment.OTHER_PROFILE_ID_KEY to objID
                    )
                )
            }
        }
    }

//    private fun createSkillsAdapter(): SkillsAdapter {
//        return SkillsAdapter {
//                objID -> println("Здесь будет переход в детальный экран техники $objID")
//        }
//    }

    companion object{
        const val FIRST_ELEMENT_INDEX = 0
        const val ELEMENT_NOT_SELECTED_INDEX = -1
        const val OFFSCREEN_PAGE_LIMIT = 2
    }
}

class HorizontalMarginItemDecoration(private val horizontalMarginInPx: Int) : RecyclerView.ItemDecoration() {
    override fun getItemOffsets(
        outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State
    ) {
        outRect.right = horizontalMarginInPx
        outRect.left = horizontalMarginInPx
    }
}