package ru.minegoat.oversees.modules.search.presentation

import android.os.Bundle
import android.view.View
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.databinding.FragmentBottomSheetChooseSkillTypeBinding
import ru.minegoat.oversees.modules.search.di.SearchComponentHolder


class BottomSheetChooseSkillType :
    BottomSheetDialogFragment(R.layout.fragment_bottom_sheet_choose_skill_type) {

    private val binding by viewBinding(FragmentBottomSheetChooseSkillTypeBinding::bind)

    private var adapter: SkillsAdapter? = null
    private val component by featureComponent(SearchComponentHolder)

    private val viewModel by lazyViewModel {
        component.searchViewModel().create()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rcPopularTypes.adapter = adapter
        loadTypes()
    }

    private fun loadTypes() {
        viewModel.getAllTrips().observe(viewLifecycleOwner) { state ->
            state.on(success = { trip ->
                trip.map {shortTrip ->
                    adapter?.let {

                    }
                }
            }, error = {

            })
        }
    }

}