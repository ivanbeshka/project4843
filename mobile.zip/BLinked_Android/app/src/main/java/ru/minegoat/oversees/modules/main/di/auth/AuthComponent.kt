package ru.minegoat.oversees.modules.main.di.auth

import dagger.Component
import ru.minegoat.oversees.base.di.AppComponent
import ru.minegoat.oversees.base.di.components.DiComponent
import ru.minegoat.oversees.modules.main.viewmodels.NeedUpdateTokenViewModel
import ru.minegoat.oversees.modules.main.viewmodels.RegisterViewModel

@AuthScope
@Component(dependencies = [AppComponent::class])
interface AuthComponent : DiComponent {

    fun authViewModel(): RegisterViewModel.Factory
    fun needUpdateTokenViewModel(): NeedUpdateTokenViewModel.Factory
}