package ru.minegoat.oversees.modules.map.di

import javax.inject.Scope

@Scope
annotation class MapScope
