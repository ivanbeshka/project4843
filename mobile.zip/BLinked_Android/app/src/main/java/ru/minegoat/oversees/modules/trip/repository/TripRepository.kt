package ru.minegoat.oversees.modules.trip.repository

import io.reactivex.Single
import ru.minegoat.oversees.data.network.search.model.TripRequest
import ru.minegoat.oversees.data.repository.user.UserRepository
import ru.minegoat.oversees.domain.ShortTrip
import ru.minegoat.oversees.domain.search.SearchForm
import ru.minegoat.oversees.domain.search.toNetwork
import ru.minegoat.oversees.domain.trip.Milestone
import ru.minegoat.oversees.domain.trip.Trip
import ru.minegoat.oversees.domain.user.ShortUser
import ru.minegoat.oversees.modules.trip.network.TripApi
import ru.minegoat.oversees.modules.trip.network.responses.ResponseShortTrip
import ru.minegoat.oversees.modules.trip.network.responses.toBusiness
import javax.inject.Inject
import kotlin.math.ceil
import kotlin.math.floor

class TripRepository @Inject constructor(
    private val api: TripApi,
    private val userRepository: UserRepository,
) {
    suspend fun getTrip(objId: String): Trip? {
        return try {
            val response = api.getTrip(objId).body()
            response?.toBusiness()?.let {
                enrichFreeTimeTrip(it)
            }
        } catch (ex: Exception) {
            null
        }
    }

    fun getShortTripList(objId: String): Single<List<ShortTrip>> {
        return api.getTripList(objId).flattenAsObservable {
            it.items
        }.flatMap { trip ->
            userRepository.getUser(trip.ownerId).defaultIfEmpty(
                ShortUser.emptyUser()
            ).toObservable().map { owner ->
                trip.toBusiness(owner)
            }
        }.toList()
    }

    fun getAllShortTripList(): Single<List<ShortTrip>> {
        return api.getTripList("62e8a85b1a6223cc3804108e").flattenAsObservable {
            it.items
        }.flatMap { trip ->
            userRepository.getUser(trip.ownerId).defaultIfEmpty(
                ShortUser.emptyUser()
            ).toObservable().map { owner ->
                trip.toBusiness(owner)
            }
        }.toList()
    }

    fun sendSearchForm(
        searchForm: SearchForm,
    ): Single<MutableList<ShortTrip>>? {
        return api.sendSearchRequest(
            tripRequest = TripRequest(
                items = searchForm.toNetwork()
            )
        ).flattenAsObservable {
            it.items
        }.flatMap { trip ->
            userRepository.getUser(trip.ownerId).defaultIfEmpty(
                ShortUser.emptyUser()
            ).toObservable().map { owner ->
                trip.toBusiness(owner)
            }
        }.toList()
    }

    private fun enrichFreeTimeTrip(trip: Trip): Trip {
        trip.apply {
            val list = milestones?.sortedBy { it.date }?.toMutableList()
            var i = 0
            while (i < (milestones?.size ?: 0) - 1) {
                val diff =
                    floor((list?.get(i + 1)?.date ?: 0) / 60 / 60 / 24f) -
                            ceil((list?.get(i)?.date ?: 0) / 60 / 60 / 24f)
                if (diff >= 1) {
                    list?.add(
                        i + 1, Milestone(
                            duration = "$diff",
                            type = Milestone.freeTime,
                            location = list[i].location
                        )
                    )
                    i++
                }
                i++
            }
            milestones = list
        }
        return trip
    }
}