package ru.minegoat.oversees.modules.user_profile.di

import javax.inject.Scope

@Scope
annotation class UserProfileScope
