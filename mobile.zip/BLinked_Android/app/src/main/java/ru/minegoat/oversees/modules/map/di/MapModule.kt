package ru.minegoat.oversees.modules.map.di

import dagger.Module

@Module
class MapModule {

}