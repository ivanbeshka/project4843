package ru.minegoat.oversees.modules.trip.di

import dagger.Module
import dagger.Provides
import retrofit2.Retrofit
import ru.minegoat.oversees.data.repository.user.UserRepository
import ru.minegoat.oversees.modules.trip.network.TripApi
import ru.minegoat.oversees.modules.trip.repository.TripRepository

@Module
class TripModule {

    @TripScope
    @Provides
    fun provideTripRepository(api: TripApi, userRepository: UserRepository): TripRepository =
        TripRepository(api, userRepository)

    @TripScope
    @Provides
    fun provideTripApi(retrofit: Retrofit) : TripApi =
        retrofit.create(TripApi::class.java)
}