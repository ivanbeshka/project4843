package ru.minegoat.oversees.modules.search.model

import ru.minegoat.oversees.R

enum class FilterType {
    PLACES,
    TECHNIQUES,
    MASTERS,
    EVENTS;

    companion object {
        fun getValueByStringResource(resource: Int) : FilterType {
            return when (resource){
                R.string.places -> PLACES
                R.string.techniques -> TECHNIQUES
                R.string.masters -> MASTERS
                R.string.events -> EVENTS
                else -> throw IllegalArgumentException()
            }
        }
    }
}

