package ru.minegoat.oversees.modules.user_profile.di

import dagger.Component
import ru.minegoat.oversees.base.di.AppComponent
import ru.minegoat.oversees.base.di.components.DiComponent
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import ru.minegoat.oversees.modules.master_profile.viewmodels.*
import ru.minegoat.oversees.modules.user_profile.viewmodels.*

@UserProfileScope
@Component(dependencies = [AppComponent::class], modules = [UserProfileModule::class])
interface UserProfileComponent : DiComponent {

    fun userProfileViewModel(): UserProfileViewModel.Factory
    fun editUserProfileViewModel(): EditUserProfileViewModel.Factory
    fun checkPhoneNumViewModel(): CheckPhoneNumViewModel.Factory
    fun checkPhoneNumBottomSheetViewModel(): CheckPhoneNumBottomSheetViewModel.Factory
    fun editAvatarViewModel(): EditAvatarViewModel.Factory
    fun accountViewModel(): UserAccountViewModel.Factory
    fun skillsViewModel(): SkillsViewModel.Factory
    fun addUserSkillViewModel(): AddUserSkillViewModel.Factory
    fun editMasterProfileViewModel(): EditMasterProfileViewModel.Factory
    fun masterInfoViewModel(): MasterInfoViewModel.Factory
    fun createSkillViewModel(): CreateSkillViewModel.Factory
    fun userDocViewModel(): UserDocViewModel.Factory

    fun authSharedPref(): AuthSharedPref
}