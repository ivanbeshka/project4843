package ru.minegoat.oversees.domain.karma

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class KAttribute(
    val type: KAttributeType,
    val sum : Int,
): Parcelable


