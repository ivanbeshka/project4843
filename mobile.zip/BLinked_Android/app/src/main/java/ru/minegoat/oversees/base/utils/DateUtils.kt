package ru.minegoat.oversees.base.utils

import android.content.Context
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.extensions.secToMils
import java.text.SimpleDateFormat
import java.time.Month
import java.time.format.TextStyle
import java.util.*
import java.util.concurrent.TimeUnit

object DateUtils {

    private val ruLocale = Locale("ru", "RU")
    private val dateFormat = SimpleDateFormat("dd.MM.yyyy", ruLocale)
    private val timeFormat = SimpleDateFormat("HH:mm", ruLocale)
    private val dateWithoutYear = SimpleDateFormat("d MMMM", ruLocale)


    fun getDateBySeconds(sec: Long): String =
        dateFormat.format(Date(sec.secToMils()))

    fun getDateForChat(sec: Long): String {
        val calendar = Calendar.getInstance()

        calendar.timeInMillis = sec.secToMils()
        val chatYear = calendar.get(Calendar.YEAR)
        val chatDay = calendar.get(Calendar.DAY_OF_YEAR)

        calendar.timeInMillis = Date().time
        val currentYear = calendar.get(Calendar.YEAR)
        val currentDay = calendar.get(Calendar.DAY_OF_YEAR)

        if (chatYear == currentYear) {
            if (chatDay == currentDay) {
                return "Сегодня"
            }
            return dateWithoutYear.format(Date(sec.secToMils()))
        } else {
            return getDateBySeconds(sec)
        }
    }

    fun getTimeBySec(sec: Long): String =
        timeFormat.format(Date(sec.secToMils()))

    fun getDateBySecondsWithMonth(sec: Long): String {
        val dateStr = dateFormat.format(Date(sec.secToMils()))
        val month = Month.of(dateStr.substring(3,5).toInt())
            .getDisplayName(TextStyle.FULL, Locale("ru")).substring(0, 3)
        return "${dateStr.substring(0, 2).toInt()} $month"
    }

    fun getTimeStamp(duration: Int, context: Context): String {
        val days: Int = TimeUnit.MILLISECONDS.toDays(duration * 1000L).toInt()
        return "$days ${
            when (days) {
                1 -> context.getString(R.string.days)
                in 2..4 -> context.getString(R.string.days_type_2)
                else -> context.getString(R.string.days_type_3)
            }
        }"
    }

}