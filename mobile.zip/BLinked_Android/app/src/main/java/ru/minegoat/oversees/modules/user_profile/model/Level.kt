package ru.minegoat.oversees.modules.user_profile.model

import android.content.Context
import ru.minegoat.oversees.R

enum class Level {
    FIRST,
    SECOND,
    THIRD;

    val res: Int
        get() {
            return when (this) {
                FIRST -> R.string.first_level
                SECOND -> R.string.second_level
                THIRD -> R.string.third_level
            }
        }

    companion object {
        fun fromStringByRes(string: String, context: Context): Level {
            return when (string) {
                context.getString(R.string.first_level) -> FIRST
                context.getString(R.string.second_level) -> SECOND
                context.getString(R.string.third_level) -> THIRD
                else -> throw IllegalStateException()
            }
        }
    }
}