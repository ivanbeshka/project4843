package ru.minegoat.oversees.modules.master_profile.di

import dagger.Module
import dagger.Provides
import retrofit2.Retrofit
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import ru.minegoat.oversees.modules.master_profile.repository.MasterInfoRepository
import ru.minegoat.oversees.modules.user_profile.di.UserProfileScope
import ru.minegoat.oversees.modules.user_profile.network.UserProfileApi

@Module
class MasterModule {

    @MasterScope
    @Provides
    fun provideMasterInfoRepository(
        ds: RealmDataStorage
    ): MasterInfoRepository =
        MasterInfoRepository(ds)

    @MasterScope
    @Provides
    fun provideUserProfileApi(retrofit: Retrofit): UserProfileApi =
        retrofit.create(UserProfileApi::class.java)
}