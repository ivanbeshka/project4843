package ru.minegoat.oversees.modules.main.di.fixture

import dagger.Component
import ru.minegoat.oversees.modules.main.viewmodels.LocationsFixtureViewModel
import ru.minegoat.oversees.base.di.AppComponent
import ru.minegoat.oversees.base.di.components.DiComponent
import ru.minegoat.oversees.modules.main.viewmodels.MessagesFixtureViewModel

@FixtureScope
@Component(dependencies = [AppComponent::class], modules = [FixtureModule::class])
interface FixtureComponent : DiComponent {
    fun locationsFixtureViewModel(): LocationsFixtureViewModel.Factory

    fun messagesFixtureViewModel(): MessagesFixtureViewModel.Factory
}