package ru.minegoat.oversees.modules.main.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.base.helpers.auth.Authenticator
import ru.minegoat.oversees.base.viewmodels.*

class RegisterViewModel @AssistedInject constructor(
    private val authenticator: Authenticator
) : RxViewModel() {

    private val isRegister = MutableLiveData<ScreenState<Boolean>>()

    fun register() {
        authenticator.register()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { isRegister.value = LoadingScreenState() }
            .subscribeBy(
                onSuccess = {
                    isRegister.value = SuccessScreenState(it)
                },
                onError = {
                    isRegister.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()
    }

    fun getIsRegister(): LiveData<ScreenState<Boolean>> =
        isRegister

    @AssistedFactory
    interface Factory {
        fun create(): RegisterViewModel
    }
}