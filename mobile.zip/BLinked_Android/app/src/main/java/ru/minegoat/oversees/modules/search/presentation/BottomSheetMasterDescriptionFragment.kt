package ru.minegoat.oversees.modules.search.presentation

import androidx.fragment.app.Fragment
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.FragmentBottomSheetMasterDescriptionBinding

class BottomSheetMasterDescriptionFragment : Fragment(R.layout.fragment_bottom_sheet_master_description) {
    private val binding by viewBinding(FragmentBottomSheetMasterDescriptionBinding::bind)
}