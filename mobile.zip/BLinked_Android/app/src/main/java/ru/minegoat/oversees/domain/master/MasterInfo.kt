package ru.minegoat.oversees.domain.master

import io.realm.kotlin.ext.toRealmList
import io.realm.kotlin.types.ObjectId
import ru.minegoat.oversees.data.db.master.MasterInfoRealm

data class MasterInfo(
    val objId: String = "",
    val masterTypes: List<MasterType> = listOf(),
    val path: String = "",
    val masterId: String = ""
)

fun MasterInfo.toMasterInfoRealm(): MasterInfoRealm =
    MasterInfoRealm(
        objID = if (objId!="") objId else ObjectId.create().toString(),
        masterTypesIds =  masterTypes.map {
            it.objID
        }.toRealmList(),
        path = path,
        masterId = masterId
    )


