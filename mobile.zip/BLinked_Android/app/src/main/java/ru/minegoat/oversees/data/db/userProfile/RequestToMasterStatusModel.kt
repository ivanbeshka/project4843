package ru.minegoat.oversees.data.db.userProfile

import io.realm.kotlin.types.ObjectId
import io.realm.kotlin.types.RealmObject
import io.realm.kotlin.types.annotations.PrimaryKey
import ru.minegoat.oversees.domain.user.RequestMasterStatus

class RequestToMasterStatusModel : RealmObject {
    @PrimaryKey
    var id: ObjectId = ObjectId.create()
    val objId: String
        get() {
            return id.toString()
        }
    var userId: Int = 0
    var isSend: Boolean = false
    var invitedMaster: String? = null
    var message: String? = null
    var phone: String? = null
    var phoneCode: String? = null
    var imageUrl: String? = null
    var socialNetworks: String? = null
}

fun RequestToMasterStatusModel.toRequestMasterStatus() : RequestMasterStatus {
    return RequestMasterStatus(
        userId = userId.toString(),
        isSend = isSend,
        invitedMaster = invitedMaster,
        message = message,
        phone = phone,
        phoneCode = phoneCode,
        imageUrl = imageUrl,
        socialNetworks = socialNetworks
    )
}