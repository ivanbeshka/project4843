package ru.minegoat.oversees.modules.user_profile.presentation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.FragmentOpenUserFileBinding

class OpenUserFileFragment : Fragment(R.layout.fragment_open_user_file) {

    private val binding by viewBinding(FragmentOpenUserFileBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        arguments?.let {
            binding.ivDocumentImage.setImageResource(it.getInt("image"))
        }
        binding.btnGoBack.setOnClickListener(){
            findNavController().navigateUp()
        }
    }

}