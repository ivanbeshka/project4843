package ru.minegoat.oversees.base.utils.image

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.media.MediaMetadataRetriever
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.os.ParcelFileDescriptor.MODE_READ_ONLY
import android.util.Size
import androidx.core.net.toFile
import io.reactivex.Single
import ru.minegoat.oversees.R
import ru.minegoat.oversees.domain.document.MediaType


object ThumbnailsUtils {

    fun getThumbnail(uri: Uri, context: Context): Single<Bitmap> {
        return when (MediaType.fromFileName(uri.path.toString())) {
            MediaType.IMAGE -> getImageThumbnail(uri, context)
            MediaType.VIDEO -> getVideoTrumbnail(uri, context)
            MediaType.PDF   -> getPDFThumbnail(uri, context)
            MediaType.DOC   -> getDocThumbnail(uri, context)
            MediaType.OTHER -> Single.create { it.onError(UnsupportedOperationException()) }
        }
    }

    private fun getImageThumbnail(uri: Uri, context: Context): Single<Bitmap> =
            Single.create {
                try {
                    val bitmap = BitmapFactory.decodeFile(uri.path)
                    val size = getSize(bitmap.width, bitmap.height, context)
                    val newBitmap = ThumbnailUtils.extractThumbnail(bitmap, size.width, size.height)
                    it.onSuccess(newBitmap)
                } catch (e: Exception) {
                    it.onError(e)

                }

            }

    private fun getPDFThumbnail(uri: Uri, context: Context): Single<Bitmap> =
            Single.create {
                try {
                    val doc = PdfRenderer(ParcelFileDescriptor.open(uri.toFile(), MODE_READ_ONLY))
                    val bitmap = Bitmap.createBitmap(context.resources.getInteger(R.integer.thumbnail_width),
                                                     context.resources.getInteger(R.integer.thumbnail_height),
                                                     Bitmap.Config.ARGB_8888
                    )
                    doc.openPage(0)
                        .render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    it.onSuccess(bitmap)
                } catch (e: Exception) {
                    it.onError(e)
                }
            }

    private fun getDocThumbnail(uri: Uri, context: Context): Single<Bitmap> =
            Single.create {
                try {
                    val bitmap = BitmapFactory.decodeResource(context.resources, R.drawable.thumbnail_word)
                    it.onSuccess(bitmap)
                } catch (e: Exception) {
                    it.onError(e)
                }

            }
}

private fun getVideoTrumbnail(uri: Uri, context: Context): Single<Bitmap> =
        Single.create {
            try {
                val bitmap = MediaMetadataRetriever().apply {
                    setDataSource(uri.path)
                }.getFrameAtTime(0)
                if (bitmap != null) {
                    val size = getSize(bitmap.width, bitmap.height, context)
                    val newBitmap = ThumbnailUtils.extractThumbnail(bitmap, size.width, size.height)
                    it.onSuccess(newBitmap)
                } else
                    it.onError(Throwable("Video conversation Error"))
            } catch (e: Exception) {
                it.onError(e)
            }
        }

private fun getSize(width: Int, height: Int, context: Context): Size =
        if (width > height)
            Size(context.resources.getInteger(R.integer.thumbnail_width),
                 context.resources.getInteger(R.integer.thumbnail_height) * height / width
            )
        else
            Size(context.resources.getInteger(R.integer.thumbnail_width) * width / height,
                 context.resources.getInteger(R.integer.thumbnail_height)
            )