package ru.minegoat.oversees.modules.search.presentation

enum class SearchType {
    TECHIC,
    MASTERS
}