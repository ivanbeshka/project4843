package ru.minegoat.oversees.data.network.user.model

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.user.SocialNetwork
import ru.minegoat.oversees.domain.user.SocialNetworkName

data class ResponseSocialNetwork(
    @SerializedName("name")
    val name: String,
    @SerializedName("link")
    val link: String
)

fun ResponseSocialNetwork.toSocialNetwork(): SocialNetwork {
    return SocialNetwork(
        name = SocialNetworkName.valueOf(name.lowercase()),
        link = link
    )
}

