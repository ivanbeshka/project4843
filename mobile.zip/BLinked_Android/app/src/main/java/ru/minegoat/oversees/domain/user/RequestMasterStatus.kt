package ru.minegoat.oversees.domain.user

data class RequestMasterStatus(
    val userId: String,
    val isSend: Boolean,
    var invitedMaster: String?,
    var message: String?,
    var phone: String?,
    var phoneCode: String?,
    var imageUrl: String?,
    var socialNetworks: String?
)
