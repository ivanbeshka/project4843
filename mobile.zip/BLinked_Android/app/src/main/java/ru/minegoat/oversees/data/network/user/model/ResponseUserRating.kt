package ru.minegoat.oversees.data.network.user.model

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.user.UserRating

data class ResponseUserRating(
    @SerializedName("ratingLevels")
    val ratingLevels: List<ResponseRatingLevel>
)

fun ResponseUserRating.toUserRating():UserRating{
    return UserRating(
        ratingLevels = this.ratingLevels.map {
            it.toUserRatingLevel()
        }
    )
}
