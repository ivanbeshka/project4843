package ru.minegoat.oversees.modules.trip.network.responses

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.trip.MealTimetable

data class ResponseMealTimetable(
    @SerializedName("type")
    val type: String?,
    @SerializedName("startTime")
    var startTime: Int?,
    @SerializedName("endTime")
    var endTime: Int?,
    @SerializedName("checked")
    val checked: Boolean?,
)

fun ResponseMealTimetable.toBusiness(): MealTimetable {
    return MealTimetable(
        checked = checked,
        startTime = startTime,
        endTime = endTime,
        type = type,
    )
}