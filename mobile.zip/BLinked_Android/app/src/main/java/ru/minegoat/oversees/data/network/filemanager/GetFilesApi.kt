package ru.minegoat.oversees.data.network.filemanager

import io.reactivex.Single
import okhttp3.ResponseBody
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Streaming

interface GetFilesApi {
    @Streaming
    @GET("image/{name}")
    fun getImage(@Path("name") name: String): Single<ResponseBody>
}