package ru.minegoat.oversees.data.db.comment

import io.realm.kotlin.types.EmbeddedRealmObject
import ru.minegoat.oversees.domain.user.ShortUser
import ru.minegoat.oversees.domain.user.UserRole

class ShortUserRealm() : EmbeddedRealmObject {

    var userId: String = ""

    var role: UserRole? = null

    var name: String? = null

    var avatar: String? = null

    var isMaster: Boolean = false

    constructor(
        userId: String = "",
        role: UserRole? = null,
        name: String? = null,
        avatar: String? = null,
        isMaster: Boolean = false
    ) : this() {
        this.userId = userId
        this.role = role
        this.name = name
        this.avatar = avatar
        this.isMaster = isMaster
    }

    companion object {
        fun emptyUser(): ShortUserRealm {
            return ShortUserRealm(
                userId = ""
            )
        }
    }
}

fun ShortUserRealm.toShortUser() =
    ShortUser(
        userId = this.userId,
        role = this.role,
        name = this.name,
        avatar = this.avatar,
        isMaster = this.isMaster
    )