package ru.minegoat.oversees.data.network.auth.model

import com.google.gson.annotations.SerializedName

data class CheckPhone(
    @SerializedName("result")
    val result: String
)

fun CheckPhone.isPhoneExisted(): Boolean {
    return result == USER_EXISTED
}

private const val USER_EXISTED = "UserExisted"