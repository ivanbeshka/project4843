package ru.minegoat.oversees.modules.master_profile.presentation

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.chip.Chip
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.ItemUserSkillBinding
import ru.minegoat.oversees.domain.user.Skill

class UserSkillsAdapter(
    private val onClick: OnClick
) : RecyclerView.Adapter<UserSkillsAdapter.UserSkillsViewHolder>() {


    private val differ = AsyncListDiffer(this, SkillListDiffUtilCallback())
    var data: List<Skill>
        get() = differ.currentList
        set(value) = differ.submitList(value)

    interface OnClick{
        fun show(skill: Skill)
        fun executeAction(skill: Skill)
    }

    inner class UserSkillsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val binding by viewBinding(ItemUserSkillBinding::bind)

        fun bind(skill: Skill){
            with(binding) {
                tvSkillName.text = skill.name
                forwardButton.isVisible = false
                clSkillItem.isClickable = false
                deleteSkillButton.isVisible = true
                skillExperienceTextView.isVisible = true
                skillExperienceTextView.text =
                    "${itemView.context.resources.getString(R.string.skill_experience)} ${skill.experience}"
                deleteSkillButton.setOnClickListener { onClick.executeAction(skill) }
                val layoutInflater = LayoutInflater.from(itemView.context)
                for (tag in skill.tags!!) {
                    val chip =
                        layoutInflater.inflate(R.layout.item_tag_chip, tagsGroup, false) as Chip
                    chip.text = tag
                    chip.isClickable = true
                    tagsGroup.addView(chip)
                }
                skillInfoButton.setOnClickListener { onClick.show(skill) }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserSkillsViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.item_user_skill, parent, false)
        return UserSkillsViewHolder(itemView)
    }

    override fun getItemCount() = data.size

    override fun onBindViewHolder(holder: UserSkillsViewHolder, position: Int) {
        holder.bind(data[position])
    }

    private class SkillListDiffUtilCallback : DiffUtil.ItemCallback<Skill>() {
        override fun areItemsTheSame(oldItem: Skill, newItem: Skill): Boolean {
            return oldItem.objId == newItem.objId
        }

        override fun areContentsTheSame(oldItem: Skill, newItem: Skill): Boolean {
            return oldItem == newItem
        }
    }
}