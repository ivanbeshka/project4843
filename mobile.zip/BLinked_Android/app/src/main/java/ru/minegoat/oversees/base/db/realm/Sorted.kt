package ru.minegoat.oversees.base.db.realm

import io.realm.kotlin.query.Sort

class Sorted(val key: String, val ascending: Sort)