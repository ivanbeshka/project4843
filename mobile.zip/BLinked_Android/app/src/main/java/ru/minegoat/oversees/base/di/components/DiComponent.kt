package ru.minegoat.oversees.base.di.components

interface DiComponent