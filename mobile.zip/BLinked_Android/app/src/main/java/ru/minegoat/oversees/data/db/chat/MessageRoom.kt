package ru.minegoat.oversees.data.db.chat

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey
import ru.minegoat.oversees.domain.chat.Message

@Entity(tableName = "messages")
data class MessageRoom(
    @PrimaryKey
    var objID: String,
    @ColumnInfo(name = "owner_id")
    var ownerId: String,
    @ColumnInfo(name = "owner_name")
    var ownerName: String,
    @ColumnInfo(name = "chat_id")
    var chatId: String,
    @ColumnInfo(name = "text")
    var text: String,
    @ColumnInfo(name = "dateTime")
    var dateTime: Long,
    @ColumnInfo(name = "content_url")
    var contentUrl: String? = null,
) {
    @Ignore
    var isEmpty: Boolean = false

    constructor(
        isEmpty: Boolean,
        objID: String,
        ownerId: String,
        ownerName: String,
        chatId: String,
        text: String,
        dateTime: Long,
        contentUrl: String? = null,
    ) : this(
        objID = objID,
        ownerId = ownerId,
        ownerName = ownerName,
        chatId = chatId,
        text = text,
        dateTime = dateTime,
        contentUrl = contentUrl
    ) {
        this.isEmpty = isEmpty
    }

    companion object {
        fun empty(): MessageRoom {
            return MessageRoom(
                isEmpty = true,
                objID = "",
                ownerId = "",
                ownerName = "",
                chatId = "",
                text = "",
                dateTime = 0
            )
        }
    }
}

fun MessageRoom.toMessage(): Message {
    return Message(
        objID = objID,
        ownerId = ownerId,
        ownerName = ownerName,
        chatId = chatId,
        text = text,
        dateTimeSec = dateTime,
        contentUrl = contentUrl
    )
}