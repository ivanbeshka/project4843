package ru.minegoat.oversees.modules.search.presentation

import android.view.LayoutInflater

import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import ru.minegoat.oversees.base.utils.ui.loadImageFromOurApi
import ru.minegoat.oversees.databinding.ItemEventBinding
import ru.minegoat.oversees.domain.ShortTrip
import ru.minegoat.oversees.modules.search.utlis.getWordForm

class EventsAdapter(
    private val onEventClick: (objID: String) -> Unit
) : RecyclerView.Adapter<EventsAdapter.ViewHolder>() {

    private val differ = AsyncListDiffer(this, EventDiffUtilCallback())
    var data: List<ShortTrip>
        get() = differ.currentList
        set(value) = differ.submitList(value)

    inner class ViewHolder(val binding: ItemEventBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemEventBinding.inflate(inflater, parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val trip = data[position]
        holder.binding.trip = trip

        setMastersData(holder.binding, trip)

        holder.binding.cvEvent.setOnClickListener {
            onEventClick(trip.objId)
        }

    }

    fun setMastersData(binding: ItemEventBinding, trip: ShortTrip){
        var mastersCount = 1
        binding.tvMastersCount.text = trip.owner.name ?: "1 Мастер"

        trip.users?.let { users ->
            mastersCount += users.size

            val masterAvatarViews = arrayOf(binding.cvMasterAvatar2, binding.cvMasterAvatar3)

            for ((index, user) in users.withIndex()){
                user.avatar?.let { avatarUrl ->
                    masterAvatarViews[index].isVisible = true
                    loadImageFromOurApi(masterAvatarViews[index], avatarUrl)
                }
                if (index == 1){
                    break
                }
            }
            binding.tvMastersCount.text = "$mastersCount ${getWordForm(mastersCount, arrayOf("Мастеров", "Мастер", "Мастера"))}"
        }


    }

    override fun getItemCount(): Int {
        return data.size
    }

    private class EventDiffUtilCallback : DiffUtil.ItemCallback<ShortTrip>() {
        override fun areItemsTheSame(oldItem: ShortTrip, newItem: ShortTrip): Boolean {
            return oldItem.objId == newItem.objId
        }

        override fun areContentsTheSame(oldItem: ShortTrip, newItem: ShortTrip): Boolean {
            return oldItem == newItem
        }
    }

}