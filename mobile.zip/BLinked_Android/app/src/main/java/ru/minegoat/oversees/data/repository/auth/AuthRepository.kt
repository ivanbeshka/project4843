package ru.minegoat.oversees.data.repository.auth

import android.util.Log
import io.reactivex.Completable
import io.reactivex.Single
import ru.minegoat.oversees.base.exceptions.AuthWithLoginAndPasswordException
import ru.minegoat.oversees.base.exceptions.UserNotAuthorizedException
import ru.minegoat.oversees.data.network.auth.AuthApi
import ru.minegoat.oversees.data.network.auth.model.isPhoneExisted
import ru.minegoat.oversees.data.network.auth.model.toUserAuth
import ru.minegoat.oversees.data.network.user.UserApi
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import ru.minegoat.oversees.domain.auth.Phone
import ru.minegoat.oversees.domain.auth.split
import java.math.BigInteger
import java.security.MessageDigest
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthRepository @Inject constructor(
    private val authSharedPref: AuthSharedPref,
    private val authApi: AuthApi,
    private val userApi: UserApi
) {

    fun authorize(): Completable {
        return Completable.fromSingle(
            authApi.register()
                .doOnSuccess {
                    Log.d("", "authorize: $it")
                    val userAuthNetwork = it.items.firstOrNull()

                    if (userAuthNetwork == null) {
                        throw UserNotAuthorizedException()
                    } else {
                        val userAuth = userAuthNetwork.toUserAuth()
                        Log.d("AuthRepository", "authorize: $userAuth")

                        Log.d("AuthRepository", "authorize: $userAuth")

                        authSharedPref.userId = userAuth.id.toString()
                        authSharedPref.token = userAuth.apiToken
                        authSharedPref.tokenExpiresAt = userAuth.apiTokenExpiresAt
                        authSharedPref.password = userAuth.password
                        authSharedPref.login = userAuth.username
                    }
                }
        )
    }

    fun recoverUser(phone: Phone): Completable {
        return Completable.fromSingle(
            authApi.recoverUser(phone.split())
                .doOnSuccess {
                    val recoverData = it.items[0]
                    authSharedPref.token = recoverData.apiToken
                    authSharedPref.login = recoverData.username
                    authSharedPref.password = recoverData.password
                }
        )
    }

    fun saveUserId(): Completable {
        return Completable.fromSingle(
            userApi.getMyUser()
                .doOnSuccess {
                    val user = it.items[0]
                    authSharedPref.userId = user.id
                }
        )
    }

    fun isPhoneExisted(phone: Phone): Single<Pair<Boolean, Phone>> {
        return authApi.checkUserPhone(phone.split())
            .map {
                it.items.first().isPhoneExisted() to phone
            }
    }

    fun authorizeWithLoginAndPass(): Completable {
        val login = authSharedPref.login
        val password = authSharedPref.password

        if (login != null && password != null) {
            val sha2Pass = bin2hex(getHash(password))

            return Completable.fromSingle(
                authApi.loginWithUsernameAndPass(login, sha2Pass)
                    .doOnSuccess { tokenResponse ->
                        val token = tokenResponse.items.firstOrNull()
                        token?.let {
                            authSharedPref.token = it.token
                        }
                    }
            )
        }

        return Completable.error(AuthWithLoginAndPasswordException())
    }

    private fun getHash(password: String): ByteArray {
        val digest = MessageDigest.getInstance(SHA_256)
        digest.reset()
        return digest.digest(password.toByteArray())
    }

    private fun bin2hex(data: ByteArray): String {
        return String.format(HEX_FORMAT, BigInteger(SIGNUM, data))
    }

    private companion object {
        private const val SHA_256 = "SHA-256"
        private const val HEX_FORMAT = "%02x"
        private const val SIGNUM = 1
    }
}