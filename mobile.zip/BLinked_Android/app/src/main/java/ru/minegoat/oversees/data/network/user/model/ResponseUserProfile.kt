package ru.minegoat.oversees.data.network.user.model

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.data.network.karma.KAttributeNetwork
import ru.minegoat.oversees.data.network.karma.KarmaNetwork
import ru.minegoat.oversees.data.network.karma.toKarma
import ru.minegoat.oversees.domain.karma.KAttribute
import ru.minegoat.oversees.domain.karma.KAttributeType
import ru.minegoat.oversees.domain.karma.Karma
import ru.minegoat.oversees.data.network.skill.responses.toMasterSkill
import ru.minegoat.oversees.domain.auth.Phone
import ru.minegoat.oversees.domain.user.Sex
import ru.minegoat.oversees.domain.user.User

data class ResponseUserProfile(
    @SerializedName("items")
    val items: List<ResponseUserProfileItem>
)

fun ResponseUserProfile.toUser(): User {
    val user = this.items[0]

    val phoneSplit = user.phone?.split(" ")
    val phone = if (phoneSplit != null) {
        Phone(phoneSplit[0], phoneSplit[1].removePrefix("+"), phoneSplit[2])
    } else {
        null
    }

    return User(
        userId = user.id,
        name = user.name,
        role = null, //todo
        phone = phone,
        description = user.userDescription,
        isGuide = user.isGuide,
        avatarUrl = user.avatarURL,
        isMaster = user.isMaster,
        homeLocationId = user.homeLocationID,
        sex = user.sex?.let { Sex.valueOf(it.uppercase()) },
        socialNetworks = user.socialNetworks.map { it.toSocialNetwork() },
        skills = user.skills?.map { it.toMasterSkill() } ?: emptyList(),
        userRating = user.userRating.toUserRating(),
        karma = user.karma.toKarma(),
    )
}