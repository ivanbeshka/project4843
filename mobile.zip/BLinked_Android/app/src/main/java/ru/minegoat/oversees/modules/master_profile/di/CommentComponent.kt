package ru.minegoat.oversees.modules.master_profile.di

import dagger.Component
import ru.minegoat.oversees.base.di.AppComponent
import ru.minegoat.oversees.base.di.components.DiComponent
import ru.minegoat.oversees.modules.master_profile.viewmodels.CommentViewModel

@CommentScope
@Component(dependencies = [AppComponent::class], modules = [CommentModule::class])
interface CommentComponent: DiComponent {

    fun commentViewModel(): CommentViewModel.Factory
}