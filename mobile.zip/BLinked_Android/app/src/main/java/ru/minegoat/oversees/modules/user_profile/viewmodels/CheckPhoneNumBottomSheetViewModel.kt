package ru.minegoat.oversees.modules.user_profile.viewmodels

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.rxkotlin.subscribeBy
import ru.minegoat.oversees.base.viewmodels.RxViewModel
import ru.minegoat.oversees.data.repository.location.LocationRepository
import ru.minegoat.oversees.domain.user.CountryFlags
import ru.minegoat.oversees.domain.user.CountryPhone


class CheckPhoneNumBottomSheetViewModel @AssistedInject constructor(
    private val locationRepository: LocationRepository
) : RxViewModel() {

    private var countryList = emptyList<CountryPhone>()

    private val _countryPhones: MutableLiveData<List<CountryPhone>> = MutableLiveData()
    val countryPhones: LiveData<List<CountryPhone>> get() = _countryPhones

    init {
        locationRepository.getPhoneNumbers()
            .subscribeBy(
                onSuccess = {
//                    countryList = CountryPhone.getDefault


                    countryList = it
                        .filter {
                            it.name != null && it.phoneNumber != null && it.countryCode != null }
                        .map {
                            CountryPhone(it.name.toString(),"${if (it.phoneNumber.toString()[0] != '+') '+' else ""}${it.phoneNumber.toString()}", CountryFlags.valueOf(it.countryCode.toString().uppercase())) }
                        .sortedBy {
                            it.countryName
                        }
                    _countryPhones.postValue(countryList)
                },
                onError = {
                    Log.d("TAG", "getCountryCodes error: ${it.message}")
                }
            ).disposeOnFinish()
    }


    fun filterCountries(find: String) {
        _countryPhones.postValue(countryList.filter { it.countryName.contains (find, true) })
    }


    @AssistedFactory
    interface Factory {
        fun create(): CheckPhoneNumBottomSheetViewModel
    }
}

