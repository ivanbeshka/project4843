package ru.minegoat.oversees.modules.chat.presentation

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import androidx.core.view.isInvisible
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.DateUtils
import ru.minegoat.oversees.base.utils.extensions.milsToSec
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.base.utils.ui.loadImage
import ru.minegoat.oversees.databinding.FragmentChatBinding
import ru.minegoat.oversees.domain.trip.Trip
import ru.minegoat.oversees.domain.chat.Chat
import ru.minegoat.oversees.domain.chat.ChatLinkedObjType
import ru.minegoat.oversees.modules.chat.di.ChatComponentHolder

class ChatFragment: Fragment(R.layout.fragment_chat) {

    private val component by featureComponent(ChatComponentHolder)

    private val viewModel by lazyViewModel {
        component.chatViewModel().create()
    }

    private val args: ChatFragmentArgs by navArgs()
    private val chatId by lazy { args.chatId }

    private val binding by viewBinding(FragmentChatBinding::bind)

    private var messagesAdapter: MessageListAdapter? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.getChat(chatId).observe(viewLifecycleOwner) { state ->
            state.on(
                success = {
                    binding.chat = it
                    initLinkedObj(it)
                    viewModel.subscribeOnNewMessages(it.objID)
                }
            )
        }

        initMsgs()

        binding.etMsgInput.doOnTextChanged { text, _, _, _ ->
            binding.fabSendMsg.isInvisible = text.isNullOrBlank()
        }

        binding.ivBack.setOnClickListener {
            findNavController().navigateUp()
        }

        binding.fabSendMsg.setOnClickListener {
            viewModel.sendMsg(binding.etMsgInput.text.toString(), chatId)
            binding.etMsgInput.setText("")
        }
    }

    private fun initLinkedObj(it: Chat) {
        when (it.linkedObj.getType()) {
            ChatLinkedObjType.TRIP -> {
                val trip = it.linkedObj as Trip
                setChatTripDates(trip)

                trip.mainImage?.let { mainImage ->
                    binding.ivLinkedObjIcon.scaleType = ImageView.ScaleType.CENTER_CROP
                    loadImage(binding.ivLinkedObjIcon, mainImage)
                }
            }
            ChatLinkedObjType.SERVICE -> {

            }
        }
    }

    private fun initMsgs() {
        messagesAdapter = MessageListAdapter()
        binding.rvMessages.adapter = messagesAdapter
        (binding.rvMessages.layoutManager as LinearLayoutManager).apply {
            stackFromEnd = true
            reverseLayout = true
        }

        messagesAdapter?.registerAdapterDataObserver(
            object : RecyclerView.AdapterDataObserver() {
                override fun onItemRangeInserted(positionStart: Int, itemCount: Int) {
                    val lm = binding.rvMessages.layoutManager as LinearLayoutManager

                    val firstVisiblePosition = lm.findFirstVisibleItemPosition()
                    if (firstVisiblePosition == LAST_MSG_POSITION || firstVisiblePosition == NO_MSGS) {
                        binding.rvMessages.scrollToPosition(NEW_MSG_POSITION)
                    }
                }
            }
        )

        val disposable = viewModel.getMessages(chatId).subscribe {
            messagesAdapter?.submitData(lifecycle, it)
        }
        viewModel.provideDisposable(disposable)

            //todo
//        binding.rvMessages.addItemDecoration(DateHeaderItemDecoration(binding.rvMessages) {
//            messagesAdapter?.getItemViewType(it) == MessageListAdapter.MessageItemType.DATE.ordinal
//        })
    }

    private fun setChatTripDates(trip: Trip) {
        trip.name?.let { tripName ->
            binding.tvLinkedObjName.text = tripName
        }

        val startDate = trip.startDate?.let { startDate ->
            DateUtils.getDateBySeconds(
                startDate.milsToSec()
            )
        } ?: EMPTY_STRING
        val endDate = trip.endDate?.let { endDate ->
            DateUtils.getDateBySeconds(
                endDate.milsToSec()
            )
        } ?: EMPTY_STRING

        binding.tvLinkedObjDateTime.text =
            "$startDate ${resources.getString(R.string.arrow_delimiter)} $endDate"
    }

    override fun onDestroyView() {
        messagesAdapter = null
        super.onDestroyView()
    }

    private companion object {
        private const val EMPTY_STRING = ""
        private const val NEW_MSG_POSITION = 0
        private const val LAST_MSG_POSITION = 0
        private const val NO_MSGS = -1
    }
}