package ru.minegoat.oversees.data.db.chat

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import ru.minegoat.oversees.domain.chat.Chat
import ru.minegoat.oversees.domain.chat.IChatLinkedObj
import ru.minegoat.oversees.domain.chat.toMessageUi
import ru.minegoat.oversees.modules.chat.model.ChatItemUi
import ru.minegoat.oversees.modules.chat.model.ShortChatUi
import ru.minegoat.oversees.modules.chat.presentation.ChatListVPItemFragment.ChatListType

@Entity(tableName = "chats")
data class ChatRoom(
    @PrimaryKey
    val objID: String,
    @ColumnInfo(name = "name")
    val name: String,
    @ColumnInfo(name = "owner_id")
    val ownerId: String,
    @ColumnInfo(name = "members_ids")
    val membersIds: List<String>,
    @ColumnInfo(name = "linked_obj")
    val linkedObj: ChatLinkedObjRoom,
    @ColumnInfo(name = "messages_ids")
    val messagesIds: List<String> = listOf(),
    @ColumnInfo(name = "icon_url")
    var iconUrl: String? = null
)

fun ChatRoom.toChat(linkedObj: IChatLinkedObj): Chat {
    return Chat(
        objID = objID,
        name = name,
        linkedObj = linkedObj,
        ownerId = ownerId,
        membersIds = messagesIds,
        messagesIds = messagesIds,
        iconUrl = iconUrl
    )
}

fun ChatRoom.toChatItem(lastMessage: MessageRoom, myUserId: String): ChatItemUi {
    return ChatItemUi(
        //todo chatListType
        chat = ShortChatUi(objID, name, ChatListType.ALL, iconUrl),
        lastMessage = lastMessage.toMessage().toMessageUi(myUserId),
        unreadMessagesCount = 0 //todo
    )
}