package ru.minegoat.oversees.data.db.userProfile.converters

import android.util.Log
import androidx.room.ProvidedTypeConverter
import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import ru.minegoat.oversees.domain.user.User
import ru.minegoat.oversees.domain.user.UserRating
import ru.minegoat.oversees.domain.user.UserRatingLevel
import java.lang.reflect.Type

@ProvidedTypeConverter
class RatingConverter {
    val gson = Gson()

    @TypeConverter
    fun toUserRating(data: String?): UserRating?{
        if (data == null){
            return null
        }

        return gson.fromJson(data, UserRating::class.java)
    }
    @TypeConverter
    fun toString(rating: UserRating?) : String{
        val json = gson.toJson(rating)
        Log.d("RatingConvert", json)
        return json
    }

}