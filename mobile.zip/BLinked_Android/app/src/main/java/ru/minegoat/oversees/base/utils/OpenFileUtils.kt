package ru.minegoat.oversees.base.utils

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import androidx.core.net.toFile
import ru.minegoat.oversees.BuildConfig

object OpenFileUtils {

    const val mimePDF = "application/pdf"
    const val mimeDOC = "application/msword"
    const val mimeJPG = "image/jpeg"
    const val mimeTIF = "image/tiff"
    const val mimePNG = "image/png"
    const val mimeMP4 = "video/mp4"
    const val mimeAVI = "video/x-msvideo"

    fun showFile(uri: Uri, context: Context) {
        val providerUri = FileProvider.getUriForFile(context, "${BuildConfig.APPLICATION_ID}.provider", uri.toFile())

        val intent = Intent(Intent.ACTION_VIEW).apply {
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            setDataAndType(providerUri, getMimeType(providerUri.toString()))
        }
        val pm: PackageManager = context.packageManager
        if (intent.resolveActivity(pm) != null) {
            context.startActivity(intent)
        }
    }
    fun getMimeType(url: String?): String? {
        var type: String? = null
        val extension = MimeTypeMap.getFileExtensionFromUrl(url)
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
        }
        return type
    }
}