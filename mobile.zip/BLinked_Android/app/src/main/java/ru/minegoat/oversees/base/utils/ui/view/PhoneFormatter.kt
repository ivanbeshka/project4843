package ru.minegoat.oversees.base.utils.ui.view

import com.google.i18n.phonenumbers.PhoneNumberUtil
import java.util.*

fun String.toPhone(countryCode: String):String{
    val phoneUtil = PhoneNumberUtil.getInstance()
    val number = phoneUtil.parse(this, countryCode)
    val phone = phoneUtil.format(number, PhoneNumberUtil.PhoneNumberFormat.NATIONAL)
    var clearPhone = ""
    try{
        clearPhone = phone.drop(phone.indexOf("("))
    } catch(e:java.lang.Exception) {
        clearPhone = phone
    }
    return clearPhone
}

fun String.toNormalizedPhone():String =
    this.replace(Regex("[^0123456789]"),"")