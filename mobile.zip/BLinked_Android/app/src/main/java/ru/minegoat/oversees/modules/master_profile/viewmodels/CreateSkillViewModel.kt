package ru.minegoat.oversees.modules.master_profile.viewmodels

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.base.viewmodels.RxViewModel
import ru.minegoat.oversees.data.repository.skill.SkillRepository
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import ru.minegoat.oversees.domain.user.Skill
import ru.minegoat.oversees.domain.user.toSkillRealm

class CreateSkillViewModel @AssistedInject constructor(
    private val skillRepository: SkillRepository,
    private val authSharedPref: AuthSharedPref
) : RxViewModel() {

    private val newSkill = MutableLiveData<Skill>()
    val newSkillLiveData: LiveData<Skill>
        get() = newSkill

    private val tags = MutableLiveData<MutableList<String>>()
    val tagsLiveData: LiveData<MutableList<String>>
        get() = tags

    fun setNewSkill(skill: Skill) {
        if (newSkill.value == null) {
            newSkill.value = skill
        }
    }

    fun addNewTag(tag: String){
        val tagList = tags.value
        if(tagList != null){
            tagList.add(tag)
            tags.value = tagList!!
        }else{
            tags.value = listOf(tag).toMutableList()
        }
    }

    fun removeTag(tag: String){
        tags.value?.remove(tag)
    }

    fun saveNewSkill() {
        newSkill.value?.let { skill ->
            val userId = authSharedPref.userId
            skillRepository.saveSkill(skill = skill.toSkillRealm())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                    onComplete = { Log.d("SkillsViewModel", "save new skill: COMPLETE") },
                    onError = { Log.d("SkillsViewModel", "save new skill: ERROR") }
                )
        }
    }

    fun setNewSkillData(
        name: String? = null,
        description: String? = null,
        skillTags: List<String>? = null
    ) {
        val skill = newSkill.value
        skill?.copy(
            name = name ?: skill.name,
            skillDescription = description ?: skill.skillDescription,
            tags = skillTags ?: skill.tags
        )?.let {
            newSkill.value = it
        }
    }

    @AssistedFactory
    interface Factory {
        fun create(): CreateSkillViewModel
    }
}