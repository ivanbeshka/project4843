package ru.minegoat.oversees.data.db.trip

import io.realm.kotlin.types.RealmObject
import ru.minegoat.oversees.domain.trip.Trip

class TripRealm : RealmObject {
}

fun TripRealm.toTrip(): Trip {
    return Trip("ffdlkfjlfdsjf") //todo
}