package ru.minegoat.oversees.data.db.document

import android.net.Uri
import io.realm.kotlin.types.ObjectId
import io.realm.kotlin.types.RealmObject
import io.realm.kotlin.types.annotations.Index
import io.realm.kotlin.types.annotations.PrimaryKey
import ru.minegoat.oversees.domain.document.Document
import ru.minegoat.oversees.domain.document.MediaType
import ru.minegoat.oversees.domain.document.toMediaType

class DocumentRealm() : RealmObject {

    @PrimaryKey
    var id: ObjectId = ObjectId.create()
    val objID: String //(computed value)
        get() {
            return id.toString()
        }

    var userFileName: String = ""

    var storageFileName: String = ""

    private var _mediaType: Int = MediaType.OTHER.ordinal
    var mediaType: MediaType
        get() {
            _mediaType.let {
                return it.toMediaType
            }
        }
        set(value) {
            value.let {
                _mediaType = it.ordinal
            }
        }

    @Index
    var linkedObjId: String = ""

    constructor(
        objId: String,
        linkedObjId: String = "",
        userFileName: String = "",
        storageFileName: String = "",
        mediaType: MediaType = MediaType.OTHER
    ) : this() {
        this.id = ObjectId.Companion.from(objID)
        this.linkedObjId = linkedObjId
        this.userFileName = userFileName
        this.storageFileName = storageFileName
        this.mediaType = mediaType

    }
}

fun DocumentRealm.toDocument(): Document =
        Document(
            objID = this.objID,
            linkedObjId = this.linkedObjId,
            userFileName = this.userFileName,
            storageFileName = this.storageFileName,
            mediaType = this.mediaType,
            uri = Uri.parse(this.storageFileName)
        )