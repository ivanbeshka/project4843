package ru.minegoat.oversees.modules.chat.model

import ru.minegoat.oversees.modules.chat.presentation.ChatListVPItemFragment.ChatListType

class UnreadMsgCountForTabs {

    val data = mutableListOf<UnreadMsgCountTabUi>()

    init {
        val typesCount = ChatListType.values().size

        for (i in 0 until typesCount) {
            data.add(UnreadMsgCountTabUi(ChatListType.values()[i], INIT_UNREAD_MSGS_COUNT))
        }
    }

    fun setUnreadMsgCountForType(unreadMsgCountTab: UnreadMsgCountTabUi) {

        data[unreadMsgCountTab.type.ordinal] = unreadMsgCountTab
    }

    fun getByType(type: ChatListType): UnreadMsgCountTabUi {
        return data[type.ordinal]
    }

    data class UnreadMsgCountTabUi(
        val type: ChatListType,
        val count: Int
    )

    override fun toString(): String {
        return data.joinToString(" ") { it.toString() }
    }

    companion object {
        const val INIT_UNREAD_MSGS_COUNT = 0
    }
}