package ru.minegoat.oversees.modules.user_profile.viewmodels

import android.net.Uri
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.rxkotlin.subscribeBy
import ru.minegoat.oversees.base.helpers.file_manager.FileManager
import ru.minegoat.oversees.base.viewmodels.ErrorScreenState
import ru.minegoat.oversees.base.viewmodels.RxViewModel
import ru.minegoat.oversees.base.viewmodels.ScreenState
import ru.minegoat.oversees.base.viewmodels.SuccessScreenState
import ru.minegoat.oversees.data.repository.document.DocumentRepository
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import ru.minegoat.oversees.domain.document.Document
import java.io.FileNotFoundException

class UserDocViewModel @AssistedInject constructor(
    private val repo: DocumentRepository,
    private val fileManager: FileManager,
    authSharePrefs: AuthSharedPref
) : RxViewModel() {

    private val docList: MutableList<Document> = mutableListOf()

    private val _documentList: MutableLiveData<List<Document>> = MutableLiveData()
    val documentList: LiveData<List<Document>> = _documentList

    private val _photoUri: MutableLiveData<Uri> = MutableLiveData()
    val photoUri: LiveData<Uri> = _photoUri

    private val _addResult: MutableLiveData<ScreenState<Boolean>> = MutableLiveData()
    val addResult: LiveData<ScreenState<Boolean>> = _addResult

    private val _renameResult: MutableLiveData<ScreenState<Boolean>> = MutableLiveData()
    val renameResult: LiveData<ScreenState<Boolean>> = _renameResult

    private val _deleteResult: MutableLiveData<ScreenState<Boolean>> = MutableLiveData()
    val deleteResult: LiveData<ScreenState<Boolean>> = _deleteResult

    lateinit var currentDoc: Document

    private val linkedObjId = authSharePrefs.userId ?: ""

    init {
        repo.getDocs(linkedObjId)
            .subscribeBy(
                onSuccess = {
                    docList.addAll(0, it)
                    _documentList.postValue(docList)
                },
                onError = {
                    Log.d("TAG", "UserDocViewModel: Error reading of User account's documents")
                }
            ).disposeOnFinish()
    }

    fun getPhotoUri() =
        fileManager.createUriForNewPhoto(false).subscribeBy(
            onSuccess = {
                _photoUri.postValue(it)
            },
            onError = {
                throw it
            }
        )

    fun addDocs(uriList: List<Uri>) =
        fileManager.getFilesFromPick(*uriList.toTypedArray(), isCache = false).subscribeBy(
            onSuccess = {
                val docs = it.map {
                    Document.fromUri(it).apply {
                        userFileName = fileManager.getFileName(uri)
                    }
                }
                repo.saveDocs(*docs.toTypedArray(), linkedObjId = linkedObjId).subscribeBy(
                    onSuccess = { documents ->
                        docList.addAll(docList.size, documents)
                        _documentList.postValue(docList)
                        _addResult.postValue(SuccessScreenState(true))
                    },
                    onError = { e ->
                        _addResult.postValue(ErrorScreenState(e))
                    }
                ).disposeOnFinish()
            },
            onError = { e ->
                _addResult.postValue(ErrorScreenState(e))
            }
        ).disposeOnFinish()

    fun renameDoc(oldName: String, newName: String) {
        for (i in docList.indices) {
            if (docList[i].userFileName == oldName) {
                repo.updateDocName(docList[i].objID, newName).subscribeBy(
                    onComplete = {
                        docList[i].userFileName = newName
                        _documentList.postValue(docList)
                        _renameResult.postValue(SuccessScreenState(true))
                    },
                    onError = { e ->
                        _renameResult.postValue(ErrorScreenState(e))
                    }
                ).disposeOnFinish()
                return
            }
        }
        _deleteResult.postValue(ErrorScreenState(Throwable(FileNotFoundException())))
    }

    fun deleteDoc(path: String) {
        for (i in docList.indices) {
            if (docList[i].storageFileName == path) {
                repo.removeDoc(docList[i].objID).subscribeBy(
                    onComplete = {
                        docList.removeAt(i)
                        _documentList.postValue(docList)
                        _deleteResult.postValue(SuccessScreenState(true))
                    },
                    onError = { e ->
                        _deleteResult.postValue(ErrorScreenState(e))
                    }
                ).disposeOnFinish()

                return
            }
        }
        _deleteResult.postValue(ErrorScreenState(Throwable(FileNotFoundException())))
    }

    @AssistedFactory
    interface Factory {
        fun create(): UserDocViewModel
    }
}