package ru.minegoat.oversees.modules.user_profile.presentation

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import com.bumptech.glide.Glide
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.subscribeBy
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.image.ThumbnailsUtils
import ru.minegoat.oversees.databinding.ItemLoadDocumentBinding
import ru.minegoat.oversees.domain.document.Document

class DocumentsAdapter(
    val listener: DocumentsRecyclerLongClickListener,
) : RecyclerView.Adapter<DocumentsAdapter.DocumentViewHolder>() {

    private val compositeDisposable = CompositeDisposable()

    private val differCallback = object : DiffUtil.ItemCallback<Document>() {
        override fun areItemsTheSame(oldItem: Document, newItem: Document): Boolean =
                oldItem.objID == newItem.objID

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: Document, newItem: Document): Boolean =
                oldItem.userFileName == newItem.userFileName
    }

    val differ = AsyncListDiffer(this, differCallback)

    var data: List<Document>
        get() = differ.currentList
        set(value) = differ.submitList(value)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DocumentViewHolder =
            DocumentViewHolder(LayoutInflater.from(parent.context)
                    .inflate(R.layout.item_load_document, parent, false))

    override fun getItemCount(): Int = data.size

    override fun onBindViewHolder(holder: DocumentViewHolder, position: Int) =
            holder.bind(data[position])


    inner class DocumentViewHolder(root: View) : RecyclerView.ViewHolder(root) {

        private val binding by viewBinding(ItemLoadDocumentBinding::bind)

        fun bind(document: Document) = with(binding) {
            tvFilename.text = checkFileNameLength(document.userFileName)
            compositeDisposable.add(ThumbnailsUtils.getThumbnail(document.uri, ivFileImage.context).subscribeBy(
                    onSuccess = {
                        Glide
                                .with(ivFileImage)
                                .load(it)
                                .into(ivFileImage)
                    },
                    onError = {}
            ))
            cardViewDocuments.setOnLongClickListener { view ->
                view?.run {
                    listener.onLongClick(
                            view,
                            bindingAdapterPosition,
                            differ.currentList[bindingAdapterPosition]
                    )
                }
                true
            }
            cardViewDocuments.setOnClickListener { view ->
                view?.run {
                    listener.onClick(
                            view,
                            bindingAdapterPosition,
                            differ.currentList[bindingAdapterPosition]
                    )
                }
            }
        }
    }

    override fun onViewDetachedFromWindow(holder: DocumentViewHolder) {
        compositeDisposable.clear()
        super.onViewDetachedFromWindow(holder)
    }

    fun checkFileNameLength(fileName: String): String {
        val format = fileName.substringAfterLast(".")
        if (fileName.length > 23) {
            return "${fileName.substring(0, 16).removeSuffix(format)}...$format"
        }
        return fileName
    }
}