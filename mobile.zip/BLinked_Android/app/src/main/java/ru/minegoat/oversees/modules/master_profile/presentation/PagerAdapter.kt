package ru.minegoat.oversees.modules.master_profile.presentation

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter

class PagerAdapter(
    fragmentManager: FragmentManager, lifecycle: Lifecycle
): FragmentStateAdapter(fragmentManager, lifecycle) {
    override fun getItemCount(): Int = countPage

    override fun createFragment(position: Int): Fragment {
        return when(position) {
            0 -> DescriptionTechnicFragment()
            1 -> MastersTechnicFragment()
            2 -> EventsTechnicFragment()
            else -> throw Throwable("Invalid position $position")
        }
    }

    companion object {
        const val countPage = 3
    }
}