package ru.minegoat.oversees.data.db.comment

import io.realm.kotlin.ext.realmListOf
import io.realm.kotlin.types.ObjectId
import io.realm.kotlin.types.RealmList
import io.realm.kotlin.types.RealmObject
import io.realm.kotlin.types.annotations.Index
import io.realm.kotlin.types.annotations.PrimaryKey
import ru.minegoat.oversees.domain.feedback.Comment
import ru.minegoat.oversees.domain.feedback.CommentType
import ru.minegoat.oversees.domain.feedback.toCommentType
import ru.minegoat.oversees.domain.user.ShortUser

class CommentRealm() : RealmObject {

    @PrimaryKey
    var id: ObjectId = ObjectId.create()
    val objID: String
        get() {
            return id.toString()
        }

    @Index
    var linkedObjId: String = ""

    var tags: RealmList<String> = realmListOf()
    var userId: String = ""

    var images: RealmList<String> = realmListOf()
    var date: Long = 0

    private var _type: Int = CommentType.NOTE.ordinal
    var type: CommentType
        get() {
            _type.let {
                return it.toCommentType
            }
        }
        set(value) {
            value.let {
                _type = it.ordinal
            }
        }

    var content: String = ""

    var user: ShortUserRealm? = ShortUserRealm.emptyUser()

    var rating: Int = 0

    constructor(
        objId: String,
        linkedObjId: String = "",
        tags: RealmList<String> = realmListOf(),
        userId: String = "",
        images: RealmList<String> = realmListOf(),
        date: Long = 0,
        type: CommentType = CommentType.NOTE,
        content: String = "",
        user: ShortUserRealm? = ShortUserRealm.emptyUser(),
        rating: Int = 0
    ) : this() {
        this.id = ObjectId.Companion.from(objID)
        this.linkedObjId = linkedObjId
        this.userId = userId
        this.tags = tags
        this.images = images
        this.date = date
        this.type = type
        this.content = content
        this.user = user
        this.rating = rating
    }
}

fun CommentRealm.toComment() =
    Comment(
        objId = this.objID,
        tags = this.tags.toList(),
        userId = this.userId,
        images = this.images.toList(),
        date = this.date,
        type = this.type,
        content = this.content,
        user = this.user?.toShortUser() ?: ShortUser.emptyUser(),
        rating = this.rating
    )