package ru.minegoat.oversees.modules.trip.network.responses

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.trip.Trip

data class ResponseTrip(
    @SerializedName("items")
    val items: List<ResponseTripItem>?
)

fun ResponseTrip.toBusiness(): Trip? {
    return items?.first()?.toBusiness()
}