package ru.minegoat.oversees.modules.map.di

import ru.minegoat.oversees.App
import ru.minegoat.oversees.base.di.holders.FeatureComponentHolder

object MapComponentHolder : FeatureComponentHolder<MapComponent>() {
    override fun build(): MapComponent {
        return DaggerMapComponent.builder()
            .appComponent(App.component)
            .mapModule(MapModule())
            .build()
    }
}