package ru.minegoat.oversees.modules.user_profile.presentation

import android.app.Dialog
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.core.os.bundleOf
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.DialogDeleteAccountBinding

class DialogDeleteAccountFragment : DialogFragment(R.layout.dialog_delete_account) {

    private lateinit var binding: DialogDeleteAccountBinding

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        binding = DialogDeleteAccountBinding.inflate(layoutInflater)

        binding.apply {
            btAccept.setOnClickListener {
                setFragmentResult(
                    REQUEST_ACTION_KEY,
                    bundleOf(ACTION_BUNDLE_KEY to true)
                )
                findNavController().navigateUp()
            }

            btCancel.setOnClickListener {
                findNavController().navigateUp()
            }
        }
        return AlertDialog.Builder(requireActivity())
            .setView(binding.root)
            .create()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        dialog?.window?.setBackgroundDrawableResource(R.drawable.shape_logout)
    }

    companion object {
        const val REQUEST_ACTION_KEY = "DialogDeleteAccountFragment_request_action"
        const val ACTION_BUNDLE_KEY = "DialogDeleteAccountFragment_action_bundle_key"
    }
}