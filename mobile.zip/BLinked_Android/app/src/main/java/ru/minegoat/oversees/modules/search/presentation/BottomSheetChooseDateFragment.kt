package ru.minegoat.oversees.modules.search.presentation

import android.content.res.Resources
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import androidx.core.os.bundleOf
import androidx.core.view.children
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.kizitonwose.calendar.core.CalendarDay
import com.kizitonwose.calendar.core.CalendarMonth
import com.kizitonwose.calendar.core.DayPosition
import com.kizitonwose.calendar.core.daysOfWeek
import com.kizitonwose.calendar.view.MonthDayBinder
import com.kizitonwose.calendar.view.MonthHeaderFooterBinder
import com.kizitonwose.calendar.view.ViewContainer
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.ContinuousSelectionHelper.getSelection
import ru.minegoat.oversees.base.utils.ui.fragment.DateSelection
import ru.minegoat.oversees.databinding.CalendarDayLayoutBinding
import ru.minegoat.oversees.databinding.CalendarHeaderBinding
import ru.minegoat.oversees.databinding.FragmentBottomSheetChooseDateBinding
import java.time.LocalDate
import java.time.Month
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.*

class BottomSheetChooseDateFragment :
    BottomSheetDialogFragment(R.layout.fragment_bottom_sheet_choose_date) {

    private val binding by viewBinding(FragmentBottomSheetChooseDateBinding::bind)


    private val today = LocalDate.now()
    private val months = mapOf(
        1 to "Январь",
        2 to "Февраль",
        3 to "Март",
        4 to "Апрель",
        5 to "Май",
        6 to "Июнь",
        7 to "Июль",
        8 to "Август",
        9 to "Сентябрь",
        10 to "Октябрь",
        11 to "Ноябрь",
        12 to "Декабрь",
    )

    private var selection = DateSelection()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.llCalendar.minimumHeight = Resources.getSystem().displayMetrics.heightPixels

        val daysOfWeek = daysOfWeek()
        binding.legendLayout.root.children
            .map { it as TextView }
            .forEachIndexed { index, textView ->
                val dayOfWeek = daysOfWeek[index]
                val title = dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault())
                textView.text =
                    title.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
            }

        configureBinders()
        val currentMonth = YearMonth.now()
        binding.calendarView.setup(
            currentMonth,
            currentMonth.plusMonths(12),
            daysOfWeek.first(),
        )
        binding.calendarView.scrollToMonth(currentMonth)
        binding.buttonSelect.isEnabled = selection.daysBetween != null
        binding.ivCloseIcon.setOnClickListener {
            findNavController().previousBackStackEntry?.savedStateHandle?.set(SET_RESULT_DATE_START, "${selection.startDate} - ${selection.endDate}")
            dismiss()
        }
    }

    private fun configureBinders() {
        val clipLevelHalf = 5000
        val rangeStartBackground =
            ResourcesCompat.getDrawable(resources, R.drawable.bg_calendar_selection_start, null)
                .also {
                    if (it != null) {
                        it.level = clipLevelHalf
                    }
                }
        val rangeEndBackground =
            ResourcesCompat.getDrawable(resources, R.drawable.bg_calendar_selection_end, null)
                .also {
                    if (it != null) {
                        it.level = clipLevelHalf
                    }
                }
        val rangeMiddleBackground =
            ResourcesCompat.getDrawable(resources, R.drawable.bg_calendar_selection_middle, null)
        val singleBackground =
            ResourcesCompat.getDrawable(resources, R.drawable.bg_calendar_selected_single, null)

        class DayViewContainer(view: View) : ViewContainer(view) {
            lateinit var day: CalendarDay
            val binding = CalendarDayLayoutBinding.bind(view)

            init {
                view.setOnClickListener {
                    if (day.position == DayPosition.MonthDate &&
                        (day.date == today || day.date.isAfter(today))
                    ) {
                        selection = getSelection(
                            clickedDate = day.date,
                            dateSelection = selection,
                        )
                        if (selection.daysBetween != null) {
                            if (selection.daysBetween!!.toInt() == 1) {
                                this@BottomSheetChooseDateFragment.binding.buttonSelect.text =
                                    "Выбрать (${selection.daysBetween!!.toInt() + 1} дня)"
                            } else {
                                this@BottomSheetChooseDateFragment.binding.buttonSelect.text =
                                    "Выбрать (${selection.daysBetween!!.toInt() + 1} дней)"
                            }
                        } else {
                            this@BottomSheetChooseDateFragment.binding.buttonSelect.text =
                                "Выбрать (1 день)"
                        }
                        this@BottomSheetChooseDateFragment.binding.calendarView.notifyCalendarChanged()
                    }
                }
            }
        }

        binding.calendarView.dayBinder = object : MonthDayBinder<DayViewContainer> {
            override fun create(view: View) = DayViewContainer(view)
            override fun bind(container: DayViewContainer, data: CalendarDay) {
                container.day = data
                val textView = container.binding.tvDayText
                val roundBgView = container.binding.exFourRoundBackgroundView
                val continuousBgView = container.binding.exFourContinuousBackgroundView

                textView.text = null
                roundBgView.visibility = View.INVISIBLE
                continuousBgView.visibility = View.INVISIBLE
                val (startDate, endDate) = selection

                when (data.position) {
                    DayPosition.MonthDate -> {
                        textView.text = data.date.dayOfMonth.toString()
                        if (data.date.isBefore(today)) {
                            textView.setTextColor(resources.getColor(R.color.gray_60, null))
                        } else {
                            when {
                                startDate == data.date && endDate == null -> {
                                    textView.setTextColor(resources.getColor(R.color.gray_90, null))
                                    if (singleBackground != null) {
                                        roundBgView.applyBackground(singleBackground)
                                    }
                                }
                                data.date == startDate -> {
                                    textView.setTextColor(resources.getColor(R.color.gray_90, null))
                                    if (rangeStartBackground != null) {
                                        continuousBgView.applyBackground(rangeStartBackground)
                                    }
                                    if (singleBackground != null) {
                                        roundBgView.applyBackground(singleBackground)
                                    }
                                }
                                startDate != null && endDate != null && (data.date > startDate && data.date < endDate) -> {
                                    textView.setTextColor(resources.getColor(R.color.gray_90, null))
                                    if (rangeMiddleBackground != null) {
                                        continuousBgView.applyBackground(rangeMiddleBackground)
                                    }
                                }
                                data.date == endDate -> {
                                    textView.setTextColor(resources.getColor(R.color.gray_90, null))
                                    if (rangeEndBackground != null) {
                                        continuousBgView.applyBackground(rangeEndBackground)
                                    }
                                    if (singleBackground != null) {
                                        roundBgView.applyBackground(singleBackground)
                                    }
                                }
                                data.date == today -> {
                                    textView.setTextColor(resources.getColor(R.color.orange, null))
                                }
                                else -> textView.setTextColor(
                                    resources.getColor(
                                        R.color.gray_90,
                                        null
                                    )
                                )
                            }
                        }
                    }
                    DayPosition.InDate -> {
                        if (singleBackground != null) {
                            textView.setTextColor(
                                resources.getColor(
                                    R.color.gray_60,
                                    null
                                )
                            )
                        }
                    }
                    DayPosition.OutDate -> {
                        if (singleBackground != null) {
                            textView.setTextColor(
                                resources.getColor(
                                    R.color.gray_60,
                                    null
                                )
                            )
                        }
                    }
                }
            }

            private fun View.applyBackground(drawable: Drawable) {
                visibility = View.VISIBLE
                background = drawable
            }
        }

        class MonthViewContainer(view: View) : ViewContainer(view) {
            val textView = CalendarHeaderBinding.bind(view).tvHeaderText
        }
        binding.calendarView.monthHeaderBinder =
            object : MonthHeaderFooterBinder<MonthViewContainer> {
                override fun create(view: View) = MonthViewContainer(view)
                override fun bind(container: MonthViewContainer, data: CalendarMonth) {
                    val month =
                        Month.of(data.yearMonth.monthValue)
                            .getDisplayName(TextStyle.FULL_STANDALONE, Locale("ru")).toInt()
                    val monthDate = months[month] + " " + data.yearMonth.year
                    container.textView.text = monthDate
                }
            }
    }

    companion object {
        const val SET_RESULT_KEY = "SET_RESULT_KEY"
        const val SET_RESULT_DATE_START = "SET_RESULT_DATE_START"
        const val SET_RESULT_DATE_END = "SET_RESULT_DATE_END"
    }
}