package ru.minegoat.oversees.modules.master_profile.presentation

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import ru.minegoat.oversees.R

class DialogCarmaAdd : DialogFragment(R.layout.dialog_carma_add) {


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        dialog?.window?.setBackgroundDrawableResource(R.drawable.shape_dialog_background_carma)
        return super.onCreateView(inflater, container, savedInstanceState)
    }

}