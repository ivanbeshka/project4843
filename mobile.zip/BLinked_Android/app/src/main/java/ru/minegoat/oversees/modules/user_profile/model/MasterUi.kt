package ru.minegoat.oversees.modules.user_profile.model


data class MasterUi(
    val userId: String,
    val name: String,
    val soname: String,
    val carmaPoints : Int,
    val tags : List<String>,
    val avatarUrl: String? = null
)