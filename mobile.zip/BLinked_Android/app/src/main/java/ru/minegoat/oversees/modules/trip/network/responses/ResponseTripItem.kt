package ru.minegoat.oversees.modules.trip.network.responses

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.trip.Trip

data class ResponseTripItem(
    @SerializedName("objID")
    val objID: String,
    @SerializedName("name")
    val name: String?,
    @SerializedName("owner")
    val owner: ResponseUser?,
    @SerializedName("startDate")
    val startDate: Long?,
    @SerializedName("endDate")
    val endDate: Long?,
    @SerializedName("duration")
    val duration: Int?,
    @SerializedName("tripDescription")
    val tripDescription: String?,
    @SerializedName("tags")
    val tags: String?,
    @SerializedName("users")
    val users: List<ResponseUser>?,
    @SerializedName("mainImage")
    val mainImage: String?,
    @SerializedName("milestones")
    val milestones: List<ResponseMilestone>?,
    @SerializedName("cost")
    val cost: String?,
    @SerializedName("attentionTagsNumber")
    val attentionTagsNumber: Int?,
    @SerializedName("badTagsNumber")
    val badTagsNumber: Int?,
    @SerializedName("goodTagsNumber")
    val goodTagsNumber: Int?,
    @SerializedName("imagesNumber")
    val imagesNumber: Int?,
    @SerializedName("reviewsNumber")
    val reviewsNumber: Int?,
)

fun ResponseTripItem.toBusiness(): Trip {
    return Trip(
        objId = objID,
        ownerId = owner?.toBusiness()?.userId,
        name = name,
        startDate = startDate,
        endDate = endDate,
        mainImage = mainImage,
        locked = false,
        duration = duration,
        tripDescription = tripDescription,
        users = users?.map { it.toBusiness() },
        tags = tags,
        milestones = milestones?.map { it.toBusiness() },
        visibility = true,
        cost = cost,
        attentionTagsNumber = attentionTagsNumber,
        badTagsNumber = badTagsNumber,
        goodTagsNumber = goodTagsNumber,
        imagesNumber = imagesNumber,
        reviewsNumber = reviewsNumber,
    )
}