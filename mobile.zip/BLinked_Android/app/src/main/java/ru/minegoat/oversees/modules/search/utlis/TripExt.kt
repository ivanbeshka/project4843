package ru.minegoat.oversees.modules.search.utlis

import android.annotation.SuppressLint
import ru.minegoat.oversees.domain.ShortTrip
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@SuppressLint("SimpleDateFormat")
private fun formatDate(date: Date): String {
    return SimpleDateFormat("dd.MM.yyyy").format(date)
}

fun getWordForm(value: Int, wordForms: Array<String>) : String{
    if (arrayOf(11, 12, 13, 14).contains(value % 100) || arrayOf(5, 6, 7, 8, 9, 0).contains(value % 10))
        return wordForms[0]
    return if (value % 10 == 1) wordForms[1] else wordForms[2]
}

fun formatTripDate(trip: ShortTrip): String{
    val tripStartDate = if (trip.startDate != null) trip.startDate * 1000 else 0
    val tripEndDate = if (trip.endDate != null) trip.endDate * 1000 else 0

    val startDate = Date(tripStartDate)
    val endDate = Date(tripEndDate)
    val daysCount = TimeUnit.MILLISECONDS.toDays(tripEndDate - tripStartDate) + 1
    return "${formatDate(startDate)} - ${formatDate(endDate)} | $daysCount ${getWordForm(daysCount.toInt(), arrayOf("дней", "день", "дня"))}"
}

fun getTripLocation(trip: ShortTrip): String{
    return trip.shortMilestones?.get(0)?.locationName ?: "Название локации"
}