package ru.minegoat.oversees.modules.trip.presentation.compose

import android.annotation.SuppressLint
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.minegoat.oversees.R
import ru.minegoat.oversees.domain.trip.Milestone
import ru.minegoat.oversees.domain.trip.Trip
import ru.minegoat.oversees.modules.trip.model.TripDetailTab
import ru.minegoat.oversees.modules.trip.viewmodels.TripViewModel
import ru.minegoat.oversees.base.utils.DateUtils
import ru.minegoat.oversees.base.utils.image.ImageDecoder

val LocalTrip: ProvidableCompositionLocal<Trip?> = compositionLocalOf { null }
val LocalTripSelectedHeader = compositionLocalOf { mutableStateOf(0) }
val LocalTripViewModel: ProvidableCompositionLocal<TripViewModel?> = compositionLocalOf { null }

@Composable
fun TripScreen() {
    Scaffold(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .padding(it)
                .fillMaxSize()
        ) {
            val trip = LocalTrip.current
            if (trip != null)
                LazyColumn {
                    item {
                        TripHeader(trip)
                    }
                    item {
                        TripBody(trip)
                    }
                }
            else {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
fun TripHeader(trip: Trip) {
    Box(
        modifier = Modifier
            .height(dimensionResource(id = R.dimen.trip_mainimage_height))
            .fillMaxWidth()
    ) {
        val mainImage = trip.mainImage
        val bitmap = mainImage?.let { ImageDecoder.decodeImage(it) }
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop
            )
            //trip header details
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(dimensionResource(id = R.dimen.trip_medium_padding)),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                trip.name?.let {
                    Text(
                        text = it,
                        fontSize = dimensionResource(id = R.dimen.trip_header_name_text_size).value.sp,
                        maxLines = 1,
                        color = colorResource(id = android.R.color.white)
                    )
                }
                if (trip.endDate != 0L && trip.startDate != 0L)
                    if (trip.startDate != null && trip.endDate != null && trip.duration != null)
                    Text(
                        text = "${DateUtils.getDateBySeconds(trip.startDate)} " +
                                "- ${DateUtils.getDateBySeconds(trip.endDate)} | " +
                                DateUtils.getTimeStamp(trip.duration, LocalContext.current),
                        fontSize = dimensionResource(id = R.dimen.trip_header_desc_text_size).value.sp,
                        color = colorResource(id = R.color.disabled_text)
                    )
                if (trip.tags?.isNotEmpty() == true)
                    Text(
                        text = trip.tags,
                        fontSize = dimensionResource(id = R.dimen.trip_header_desc_text_size).value.sp,
                        color = colorResource(id = R.color.disabled_text)
                    )
            }
            TripHeaderTabs(selectedIndex = LocalTripSelectedHeader.current)
        } else {
            Text(
                text = stringResource(id = R.string.loading_error),
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}

@SuppressLint("UnrememberedMutableState")
@Composable
fun TripHeaderTabs(
    selectedIndex: MutableState<Int> = mutableStateOf(0),
    tabs: ArrayList<TripDetailTab> = arrayListOf(
        TripDetailTab.Detail,
        TripDetailTab.Review,
        TripDetailTab.Blog
    )
) {
    val offset: Float = 2f / (tabs.size - 1)
    val pos by animateFloatAsState(offset * selectedIndex.value - 1f)
    val tabAlign = derivedStateOf { BiasAlignment(horizontalBias = pos, verticalBias = 0f) }

    var textHeight by remember { mutableStateOf(0) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(dimensionResource(id = R.dimen.trip_medium_padding)),
        contentAlignment = Alignment.TopCenter
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.7f)
                .background(colorResource(id = R.color.gray_alpha_40)),
            contentAlignment = tabAlign.value
        ) {
            //thumb
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(percent = 20))
                    .background(color = colorResource(id = android.R.color.white))
                    .fillMaxWidth(1f / tabs.size)
                    .height(with(LocalDensity.current) { textHeight.toDp() }),
            )
        }
        Row(
            modifier = Modifier
                .fillMaxWidth(0.7f)
                .border(
                    width = 1.dp,
                    color = colorResource(id = android.R.color.black),
                    shape = RoundedCornerShape(percent = 20),
                )
                .clip(RoundedCornerShape(percent = 50))
                .onGloballyPositioned { textHeight = it.size.height },
            horizontalArrangement = Arrangement.SpaceAround,
        ) {
            //tabs
            tabs.forEachIndexed { index, tab ->
                Text(
                    text = stringResource(id = tab.name),
                    modifier = Modifier
                        .weight(1f)
                        .clickable(
                            interactionSource = MutableInteractionSource(),
                            indication = null
                        ) {
                            if (tab.enabled) selectedIndex.value = index
                        }
                        .padding(dimensionResource(id = R.dimen.trip_medium_padding)),
                    textAlign = TextAlign.Center,
                    color = colorResource(id = if (!tab.enabled) R.color.disabled_text else android.R.color.black),
                    fontSize = dimensionResource(id = R.dimen.trip_tab_text_size).value.sp,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun TripBody(trip: Trip) {
    Box(modifier = Modifier.fillMaxSize()) {
        Column {
            trip.milestones?.forEach { milestone ->
                TripMilestone(milestone)
            }
        }
    }
}

@Composable
fun TripMilestone(milestone: Milestone) {
    Row {
        Text(text = milestone.toString(), modifier = Modifier.padding(6.dp))
    }
}


