package ru.minegoat.oversees.modules.master_profile.viewmodels

import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import ru.minegoat.oversees.base.viewmodels.RxViewModel
import ru.minegoat.oversees.domain.user.MasterSkill


class AddUserSkillViewModel @AssistedInject constructor() : RxViewModel() {

    private val newMasterSkill = MutableLiveData<MasterSkill>()

    fun setNewMasterSkill(skill: MasterSkill) {
        if (newMasterSkill.value == null) {
            newMasterSkill.value = skill
        }
    }

    @AssistedFactory
    interface Factory {
        fun create(): AddUserSkillViewModel
    }
}