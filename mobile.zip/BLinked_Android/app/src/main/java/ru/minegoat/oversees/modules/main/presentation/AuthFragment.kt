package ru.minegoat.oversees.modules.main.presentation

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.base.utils.ui.fragment.showToast
import ru.minegoat.oversees.databinding.FragmentAuthBinding
import ru.minegoat.oversees.modules.main.di.auth.AuthComponentHolder

class AuthFragment : Fragment(R.layout.fragment_auth) {

    private val component by featureComponent(AuthComponentHolder)

    private val viewModel by lazyViewModel {
        component.authViewModel().create()
    }

    private val binding by viewBinding(FragmentAuthBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.register() //todo

        binding.btnRepeat.setOnClickListener {
            viewModel.register()
        }

        viewModel.getIsRegister().observe(viewLifecycleOwner) { state ->
            Log.d("AuthFragment", "onViewCreated: $state")
            state.on(
                success = {
                    if (it) {
                        findNavController().navigate(R.id.action_authFragment_to_trips)
                    } else {
                        showToast(R.string.account_not_created)
                    }
                },
                error = {
                    showToast(R.string.account_not_created)
                }
            )
        }
    }
}