package ru.minegoat.oversees.modules.user_profile.presentation

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.viewbinding.ViewBinding
import ru.minegoat.blinked.modules.user_profile.presentation.DetailMasterAdapter
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.SpaceDividerItemDecoration
import ru.minegoat.oversees.databinding.FragmentDetailInfoEventsBinding
import ru.minegoat.oversees.databinding.FragmentDetailInfoMastersBinding
import ru.minegoat.oversees.databinding.FragmentDetailInfoSkillsBinding
import ru.minegoat.oversees.modules.user_profile.model.DetailType
import ru.minegoat.oversees.modules.user_profile.model.EventsUi
import ru.minegoat.oversees.modules.user_profile.model.MasterUi
import ru.minegoat.oversees.modules.user_profile.model.SkillUi

class DetailInfoItemFragment : Fragment(){
    private lateinit var binding : ViewBinding

    private lateinit var type : DetailType

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val intType = arguments?.getInt(TYPE, DetailType.EVENTS.ordinal)?:  DetailType.EVENTS.ordinal
        type = DetailType.values()[intType]

        binding = when(type){
            DetailType.EVENTS ->{
                FragmentDetailInfoEventsBinding
                    .inflate(inflater, container, false)
            }
            DetailType.SKILLS ->{
                FragmentDetailInfoSkillsBinding
                    .inflate(inflater, container, false)
            }
            DetailType.MASTERS -> {
                FragmentDetailInfoMastersBinding
                    .inflate(inflater, container, false)
            }
        }
        return  binding.root
    }

    //TODO : REMOVE TEMP_ITEMS AND ADD VIEW_MODEL

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        when (type){
            DetailType.EVENTS ->{
                initEvents {
                    Toast.makeText(requireContext(), "Переход к мероприятию", Toast.LENGTH_SHORT)
                }
                genereteEvents()
            }
            DetailType.MASTERS ->{
                initMasters {
                    Toast.makeText(requireContext(), "Переход к мастеру", Toast.LENGTH_SHORT)
                }
                generateMasters()
            }
            DetailType.SKILLS -> {
                initSkills {
                    Toast.makeText(requireContext(), "Переход к технике", Toast.LENGTH_SHORT)
                }
                genereteSkills()
            }
        }
    }


    private fun generateMasters(){
        val binding = this.binding as FragmentDetailInfoMastersBinding
        val master = MasterUi(
            "1",
            "Михаил",
            "Капустин",
            1520,
            listOf("Первооткрыватель", "Крутой"),
        )
        val masters = listOf(master, master)
        val adapter = binding.rvShortMasters.adapter as DetailMasterAdapter
        adapter.submitList(masters)
        binding.tvMasterCount.text= getString(R.string.masters_passed_count, masters.size.toString())
    }

    private fun genereteSkills(){
        val binding = this.binding as FragmentDetailInfoSkillsBinding
        val skill = SkillUi(
            "1",
            listOf("Воля", "Разум"),
            "Навык"
        )
        val skills = listOf(skill, skill)
        val adapter= binding.rvShortSkills.adapter as DetailSkillAdapter
        adapter.submitList(skills)
        binding.tvSkillCount.text = getString(R.string.technique_learn_count, skills.size.toString())
    }

    private fun genereteEvents(){
        val binding = this.binding as FragmentDetailInfoEventsBinding
        val month = EventsUi.MonthUi(
            "Январь",
            "2023"
        )
        val event = EventsUi.EventUi(
            "1",
            "Путешествие на водоем",
            "Путешествие",
            "23 января - 25 января 2023",
            "Москва, Россия",
            "1500 руб.",
            "3 мастера" ,
            listOf("Прогулка", "Путь"),
            isOnline = true,
            isLiked = true,
            isStarted = true
        )
        val events = listOf<EventsUi>(month, event)

        val adapter = binding.rvShortEvents.adapter as DetailEventAdapter
        adapter.submitList(events)
        binding.tvEventsCount.text = getString(R.string.events_visited_count,
            events.count (predicate = {
                it is EventsUi.EventUi
        }
            ).toString()
        )
    }

    private fun initSkills( onClick: (skillId: String) -> Unit){
        val binding = this.binding as FragmentDetailInfoSkillsBinding

        binding.rvShortSkills.adapter = DetailSkillAdapter(onClick)
        binding.rvShortSkills.addItemDecoration(
            SpaceDividerItemDecoration(
                resources.getDimensionPixelSize(R.dimen.space_divider_17dp),
                LinearLayout.VERTICAL
            )
        )
    }

    private fun initEvents(onClick: (eventId: String) -> Unit){
        val binding = this.binding as FragmentDetailInfoEventsBinding

        binding.rvShortEvents.adapter = DetailEventAdapter(onClick)
        binding.rvShortEvents.addItemDecoration(
            SpaceDividerItemDecoration(
                resources.getDimensionPixelSize(R.dimen.space_divider_16dp),
                LinearLayout.VERTICAL
            )
        )
    }

    private fun initMasters(onClick: (masterId: String) -> Unit){
        val binding = this.binding as FragmentDetailInfoMastersBinding

        binding.rvShortMasters.adapter = DetailMasterAdapter(onClick )
        binding.rvShortMasters.addItemDecoration(
            SpaceDividerItemDecoration(
                resources.getDimensionPixelSize(R.dimen.space_divider_16dp),
                LinearLayout.VERTICAL
            )
        )
    }

    companion object{
        private const val TYPE = "detail_type"

        fun newInstance(type: DetailType) : Fragment{
           return DetailInfoItemFragment().apply {
                arguments = bundleOf(TYPE to type.ordinal)
            }
        }
    }
}