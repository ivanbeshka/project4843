package ru.minegoat.oversees.modules.master_profile.di

import ru.minegoat.oversees.App
import ru.minegoat.oversees.base.di.holders.FeatureComponentHolder

object CommentComponentHolder : FeatureComponentHolder<CommentComponent>() {
    override fun build(): CommentComponent {
        return DaggerCommentComponent.builder()
            .appComponent(App.component)
            .commentModule(CommentModule())
            .build()
    }
}