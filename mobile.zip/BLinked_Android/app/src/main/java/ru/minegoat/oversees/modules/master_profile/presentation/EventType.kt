package ru.minegoat.oversees.modules.master_profile.presentation

enum class EventType {
    UPCOMING,
    PAST
}