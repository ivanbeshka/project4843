package ru.minegoat.oversees.modules.user_profile.presentation

import android.content.ContentResolver
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.BlendModeColorFilterCompat
import androidx.core.graphics.BlendModeCompat
import androidx.core.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResultListener
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import com.bumptech.glide.Glide
import com.google.android.material.chip.Chip
import com.google.android.material.tabs.TabLayout
import ru.minegoat.oversees.BuildConfig
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.createShortDynamicLinkTask
import ru.minegoat.oversees.base.utils.image.TakePictureWithUriReturnContract
import ru.minegoat.oversees.base.utils.ui.activity.lazyViewModel
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.base.utils.ui.fragment.showToast
import ru.minegoat.oversees.base.utils.ui.loadImageFromOurApi
import ru.minegoat.oversees.base.viewmodels.ErrorScreenState
import ru.minegoat.oversees.base.viewmodels.SuccessScreenState
import ru.minegoat.oversees.databinding.FragmentUserProfileBinding
import ru.minegoat.oversees.databinding.ViewChipWhiteBinding
import ru.minegoat.oversees.databinding.ViewProgressBarBinding
import ru.minegoat.oversees.domain.karma.Karma
import ru.minegoat.oversees.domain.user.RatingLevelName
import ru.minegoat.oversees.domain.user.RatingTypeName
import ru.minegoat.oversees.domain.user.RatingTypes
import ru.minegoat.oversees.domain.user.User
import ru.minegoat.oversees.modules.main.di.auth.AuthComponentHolder
import ru.minegoat.oversees.modules.master_profile.presentation.EventsListsAdapter
import ru.minegoat.oversees.modules.user_profile.di.UserProfileComponentHolder
import ru.minegoat.oversees.modules.user_profile.model.ImageData
import ru.minegoat.oversees.modules.user_profile.presentation.utils.createShareUserUri
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.abs


class UserProfileFragment : Fragment(R.layout.fragment_user_profile) {

    private var userId: String? = null

    private val component by featureComponent(UserProfileComponentHolder)

    private val binding by viewBinding(FragmentUserProfileBinding::bind)

    private val viewModel by lazyViewModel {
        component.userProfileViewModel().create()
    }

    private val skillsViewModel by lazyViewModel {
        component.skillsViewModel().create()
    }

    private val editAvatarViewModel by lazyViewModel {
        component.editAvatarViewModel().create()
    }

    private val profileType by lazy {
        arguments?.getInt(PROFILE_TYPE_KEY, ProfileType.MY.ordinal)
            ?.let {
                ProfileType.values()[it]
            } ?: ProfileType.MY

    }
    private val otherUserId by lazy {
        arguments?.getString(OTHER_PROFILE_ID_KEY)
    }

    private var isMaster = false

    private var systemUiVisibility: Int? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setDefaultValues()
        workToToolbar()
        workToAvatar()
        workToMasterType()
        workToLocation()
        workToMasterHistory()
        workToCarma()
        onReadFeedback()
        workToEvents()
        onAllEvents()
        onMoreButton()
        onPickData()
        onSubscribeData()

    }

    override fun onResume() {
        if (profileType == ProfileType.MY)
            userId?.let {
                viewModel.getMasterTypeByUserId(it)
            }
        else if (profileType == ProfileType.OTHER)
            otherUserId?.let {
                viewModel.getMasterTypeByUserId(it)
            }
        onSubscribeUserProfile()
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
        systemUiVisibility?.run {
            requireActivity().window.decorView.systemUiVisibility = this
        }
    }

    private fun setDefaultValues() {
        systemUiVisibility = requireActivity().window.decorView.systemUiVisibility

        binding.apply {
            userEventsProgress.imageSrc =
                ContextCompat.getDrawable(requireContext(), R.drawable.ic_compass_18x18)
            setProgress(userEventsProgress, 0, 10)
            userMastersProgress.imageSrc =
                ContextCompat.getDrawable(requireContext(), R.drawable.ic_master_18x18)
            setProgress(userMastersProgress, 0, 30)
            userTechnicsProgress.imageSrc =
                ContextCompat.getDrawable(requireContext(), R.drawable.ic_flash_18x18)
            setProgress(userTechnicsProgress, 0, 20)

        }
    }

    private fun workToToolbar() {
        with(binding) {
            toolbar.setNavigationOnClickListener {
                findNavController().navigate(R.id.action_userProfileFragment_to_userAccountFragment)
            }

            toolbar.setOnMenuItemClickListener {
                when (it.itemId) {
                    R.id.edit -> {
                        if (isMaster) {
                            findNavController().navigate(
                                R.id.action_userProfileFragment_to_editMasterProfileFragment
                            )
                            true
                        } else {
                            findNavController().navigate(
                                R.id.action_userProfileFragment_to_editUserProfileFragment
                            )
                            true
                        }
                    }
                    R.id.share -> {
                        shareUser()
                        true
                    }
                    else -> false
                }
            }
            appBarLayout.apply {
                requireActivity().window.decorView.systemUiVisibility = 0
                addOnOffsetChangedListener { _, verticalOffset ->
                    if ((collapsingToolbar.height + verticalOffset) < (2 * ViewCompat.getMinimumHeight(
                            collapsingToolbar
                        ))
                    ) {
                        requireActivity().window.decorView.systemUiVisibility =
                            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    } else {
                        requireActivity().window.decorView.systemUiVisibility = 0
                    }
                }
            }
            collapsingToolbar.setExpandedTitleTypeface(
                Typeface.create(
                    collapsingToolbar.expandedTitleTypeface, Typeface.BOLD
                )
            )
        }
    }

    private fun workToAvatar() {
        with(binding) {
            if (profileType == ProfileType.OTHER) loadPhotoButton.visibility = View.GONE
            loadPhotoButton.setOnClickListener {
                findNavController().navigate(R.id.action_userProfileFragment_to_changeAvatarBottomSheet)
            }
            editAvatarViewModel.imageUriLiveData.observe(viewLifecycleOwner) { uri ->
                if (ProfileType.MY == profileType) loadPhotoButton.visibility = View.GONE
                viewModel.saveUser(imageToImageData = {
                    val imageByteArray = uri?.let { uri ->
                        val imageBitmap =
                            Glide.with(requireContext()).asBitmap().load(uri).submit().get()

                        val stream = ByteArrayOutputStream()
                        imageBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                        stream.toByteArray()
                    }
                    ImageData(
                        imageByteArray,
                        uri?.toString()?.split(URI_DELIMITER)?.last()?.replace("%", "")
                    )
                })
            }
        }
    }

    private fun workToMasterType() {
        viewModel.masterInfo.observe(viewLifecycleOwner) {
            it.on(
                success = { masterInfo ->
                    binding.masterStory.text = masterInfo.path
                    with(binding.masterTypeGroup) {
                        for (i in childCount - 1 downTo 1) {
                            if (this[i] is Chip) {
                                val chip = this[i] as Chip
                                var isExist = false
                                for (j in masterInfo.masterTypes.indices) {
                                    if (masterInfo.masterTypes[j].name == chip.tag) {
                                        isExist = true
                                        break
                                    }
                                }
                                if (!isExist) {
                                    this.removeViewAt(i)
                                }
                            }
                        }
                        masterInfo.masterTypes.forEach { masterType ->
                            var isExist = false
                            for (view in children) {
                                if (view is Chip) {
                                    if (view.tag == masterType.name) {
                                        isExist = true
                                        break
                                    }
                                }
                            }
                            if (!isExist) {
                                ViewChipWhiteBinding.inflate(layoutInflater).apply {
                                    root.tag = masterType.name
                                    this.chip.isCloseIconVisible = false
                                    val text = "#${masterType.name}"
                                    chip.text = text
                                    chip.setOnClickListener {
                                        masterType.masterTypeDescription?.let { text ->
                                            showToast(text)
                                        }

                                    }
                                    binding.masterTypeGroup.addView(root as View, childCount)
                                }

                            }
                        }
                    }
                },
                error = {}
            )
        }
    }

    private fun workToLocation() {
        viewModel.locationNameLiveData.observe(viewLifecycleOwner) { state ->
            state.on(
                success = {
                    binding.apply {
                        if (isMaster) {
                            masterLocationPanel.visibility = View.VISIBLE
                            masterLocation.text = it
                        } else {
                            userLocationPanel.visibility = View.VISIBLE
                            userLocation.text = it
                        }

                    }

                }
            )
        }
    }

    private fun workToSkills(user: User) {
        user.skills?.run {
            binding.masterSkillsPanel.isVisible = user.skills.isNotEmpty()
            skillsViewModel.getUserSkills(map { it.objId }).observe(viewLifecycleOwner) {
                if (it is SuccessScreenState) {
                    val skillsList = it.data
                    with(binding.masterSkillsGroup) {
                        for (i in childCount - 1 downTo 0) {
                            if (this[i] is Chip) {
                                val chip = this[i] as Chip
                                var isExist = false
                                for (j in skillsList.indices) {
                                    if (skillsList[j].name == chip.tag) {
                                        isExist = true
                                        break
                                    }
                                }
                                if (!isExist) {
                                    this.removeViewAt(i)
                                }
                            }
                        }
                        skillsList.forEach { skill ->
                            var isExist = false
                            for (view in children) {
                                if (view is Chip) {
                                    if (view.tag == skill.name) {
                                        isExist = true
                                        break
                                    }
                                }
                            }
                            if (!isExist) {
                                ViewChipWhiteBinding.inflate(layoutInflater).apply {
                                    root.tag = skill.name
                                    this.chip.isCloseIconVisible = false
                                    val text = "${skill.name}"
                                    chip.text = text
                                    chip.setOnClickListener {
                                        skill.skillDescription?.run {
                                            if (skill.skillDescription.isNotEmpty())
                                                showToast(this)
                                        }


                                    }
                                    binding.masterSkillsGroup.addView(root as View, childCount)
                                }

                            }
                        }
                    }
                } else if (it is ErrorScreenState) {

                }
            }

        }

    }

    private fun workToMasterHistory() {
        binding.masterStoryMoreButton.setOnClickListener {
            binding.run {
                if (masterStory.isExpanded) {
                    masterStoryMoreButton.text = getString(R.string.more)
                } else {
                    masterStoryMoreButton.text = getString(R.string.hide)
                }
                masterStory.toggle()
            }

        }
    }

    private fun workToCarma(karma: Karma? = null) {
        binding.masterCarmaCard.setOnClickListener {
            findNavController().navigate(UserProfileFragmentDirections.actionUserProfileFragmentToBottomSheetCarma(karma))
        }
    }

    private fun onReadFeedback() {
        binding.masterFeedbackReedButton.setOnClickListener {
            findNavController().navigate(R.id.action_userProfileFragment_to_feedbackFragment)
        }
    }

    private fun workToEvents() {
        with(binding) {
            eventsList.layoutManager = object : LinearLayoutManager(requireContext()) {
                override fun canScrollHorizontally(): Boolean {
                    return false
                }
            }.apply {
                orientation = RecyclerView.HORIZONTAL
            }
            eventsList.adapter = EventsListsAdapter()

            masterEventsTabButtons.addOnTabSelectedListener(object :
                TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab: TabLayout.Tab?) {
                    val currentPos = masterEventsTabButtons.selectedTabPosition
                    eventsList.scrollToPosition(currentPos)
                }

                override fun onTabUnselected(tab: TabLayout.Tab?) {
                }

                override fun onTabReselected(tab: TabLayout.Tab?) {
                }

            })
        }

    }

    private fun onAllEvents() {
        binding.eventsAllButton.setOnClickListener {
            findNavController().navigate(R.id.action_userProfileFragment_to_allEventsFragment)
        }
    }

    private fun setRatings(user: User) {
        with(binding) {
            user.userRating?.run {
                var commonRating = Int.MAX_VALUE
                ratingLevels.forEach {
                    it.name?.run {
                        if (level < commonRating) commonRating = level
                    }
                    when (it.type) {
                        RatingTypeName.TRIPS -> {
                            it.name?.run {
                                userEventsLevelCounter.text =
                                    getText(R.string.user_events_level).toString().format(level)
                                userEventsLevelRank.text = getText(res)
                                userEventsProgress.maxProgress = "${it.scale}"
                                var minValue = RatingTypes.getMinPoints(level, it.type)
                                if (minValue < 0) minValue = 0
                                userEventsProgress.currentProgress = "${it.points - minValue}"
                                userEventsProgress.progressBarPercent =
                                    (it.points - minValue) * 100 / it.scale
                            }
                        }
                        RatingTypeName.MASTERS -> {
                            it.name?.run {
                                userMastersLevelCounter.text =
                                    getText(R.string.user_master_level).toString().format(level)
                                userMastersLevelRank.text = getText(res)
                                userMastersProgress.maxProgress = "${it.scale}"
                                var minValue = RatingTypes.getMinPoints(level, it.type)
                                if (minValue < 0) minValue = 0
                                userMastersProgress.currentProgress = "${it.points - minValue}"
                                userMastersProgress.progressBarPercent =
                                    (it.points - minValue) * 100 / it.scale
                            }
                        }
                        RatingTypeName.SKILLS -> {
                            it.name?.run {
                                userTechnicsLevelCounter.text =
                                    getText(R.string.user_technics_level).toString().format(level)
                                userTechnicsLevelRank.text = getText(res)
                                userTechnicsProgress.maxProgress = "${it.scale}"
                                var minValue = RatingTypes.getMinPoints(level, it.type)
                                if (minValue < 0) minValue = 0
                                userTechnicsProgress.currentProgress = "${it.points - minValue}"
                                userTechnicsProgress.progressBarPercent =
                                    (it.points - minValue) * 100 / it.scale
                            }
                        }
                        else -> {}
                    }
                }
                userDiscoverLevelCounter.text =
                    getText(R.string.user_level).toString().format(commonRating)
                userDiscoverLevelRank.text = getText(RatingLevelName.fromLevel(commonRating).res)
                chipUserDiscoverLevelRank.text =
                    getText(RatingLevelName.fromLevel(commonRating).res)
            }
        }
    }

    private fun onMoreButton() {
        binding.userMoreButton.setOnClickListener {
            val action =
                UserProfileFragmentDirections.actionUserProfileFragmentToDetailInfoFragment()
            findNavController().navigate(action)
        }
    }

    private fun onSubscribeData() {
        viewModel.isUserSaved.observe(viewLifecycleOwner) { state ->
            state.on(

                success = {
                    viewModel.getUserProfile(profileType)
                },
                error = {
                    showToast(R.string.oops_something_went_wrong)
                }
            )
        }
    }


    private fun setProgress(panel: ViewProgressBarBinding, currentProgress: Int, maxProgress: Int) {
        with(panel) {
            this.currentProgress = currentProgress.toString()
            this.maxProgress = maxProgress.toString()
            this.progressBarPercent = (currentProgress * 100 / maxProgress)
        }
    }

    //TODO: ПОСТАВИТЬ СТРОКОВЫЕ РЕСУРСЫ
    private fun shareUser() {
        userId?.let {
            val uri = createShareUserUri(it)
            val linkTask = createShortDynamicLinkTask(uri)

            linkTask.addOnCompleteListener(this.requireActivity()) {
                if (it.isSuccessful) {
                    val link = it.result.shortLink
                    val message = "$link"

                    val sendIntent = Intent(Intent.ACTION_SEND)
                        .putExtra(Intent.EXTRA_TEXT, message)
                    sendIntent.type = "text/plain"
                    startActivity(Intent.createChooser(sendIntent, "Share"))
                } else {
                    Log.e("SHARE_USER", it.exception?.message ?: "Unknown Error")
                }
            }
        }

    }


    private fun setMasterContent(user: User, profileType: ProfileType) {
        with(binding) {
            userContainer.visibility = View.GONE
            masterContainer.visibility = View.VISIBLE

            if (user.karma != null) {
                masterCarmaCounter.text = user.karma.attribute.sumOf { it.sum }.toString()
                workToCarma(user.karma)
            }

            if (profileType == ProfileType.MY) {
                callToMasterPanel.visibility = View.GONE
                leaveMasterReviewButton.visibility = View.GONE
                if (isMaster) {
                    loadPhotoButton.visibility =
                        if (user.avatarUrl != null) View.GONE else View.VISIBLE
                }
            } else {
                callToMasterPanel.visibility = View.VISIBLE
                leaveMasterReviewButton.visibility = View.VISIBLE
            }
        }


    }

    private fun setUserContent(user: User) {
        binding.userContainer.visibility = View.VISIBLE
        binding.masterContainer.visibility = View.GONE

        binding.dontLoadedTextView.visibility =
            if (user.isCustomer && user.avatarUrl == null) View.VISIBLE else View.GONE


        //TODO: SWAP TO REAL DATA OF PROGRESS
        binding.apply {
            if (user.karma != null) {
                userCarmaCounter.text = user.karma.attribute.sumOf { it.sum }.toString()
            }
            userDiscoverLevelCounter.text = getString(R.string.user_level).format(1)
            setProgress(userEventsProgress, 1, 10)
            setProgress(userMastersProgress, 2, 30)
            setProgress(userTechnicsProgress, 2, 20)

        }
    }

    private fun onSubscribeUserProfile() {
        viewModel.getUserProfile(profileType, otherUserId)
        viewModel.user.observe(viewLifecycleOwner) { state ->
            state.on(
                loading = {
                    binding.apply {
                        body.visibility = View.GONE
                        appBarLayout.visibility = View.GONE
                        loading.visibility = View.VISIBLE
                    }
                },
                success = { user ->
                    user.isMaster?.let {
                        isMaster = it
                    }

                    viewModel.getMasterTypeByUserId(user.userId)

                    initUserName(user.name, user.soname)

                    user.avatarUrl?.let {
                        loadImageFromOurApi(
                            binding.avatarIcon,
                            it
                        )
                        binding.loadPhotoButton.visibility = View.GONE
                    }

                    user.homeLocationId?.let {
                        viewModel.getLocationById(it)
                    }

                    workToSkills(user)

                    if (!user.description.isNullOrEmpty()) {
                        binding.aboutMe.text = user.description
                        binding.aboutMe.visibility - View.VISIBLE
                    } else
                        binding.aboutMe.visibility - View.GONE

                    this.userId = user.userId

                    if (isMaster) {
                        setMasterContent(user, profileType)
                    } else {
                        setUserContent(user)
                        setRatings(user)
                    }
                    binding.apply {
                        loading.visibility = View.GONE
                        body.visibility = View.VISIBLE
                        appBarLayout.visibility = View.VISIBLE
                    }
                },
                error = {}
            )
        }
    }

    private fun initUserName(name: String?, surname: String?) {
        val toolbarFullTitle = if (surname != null) {
            "$name $surname"
        } else {
            name
        }
        binding.appBarLayout.addOnOffsetChangedListener { appBarLayout, verticalOffset ->
            if (abs(verticalOffset) == appBarLayout.totalScrollRange) {
                // Collapsed
                binding.collapsingToolbar.title = toolbarFullTitle?.split(" ")?.first()
            } else if (verticalOffset == 0) {
                // Expanded
                setToolbarIconsColor(Color.WHITE)
                binding.collapsingToolbar.title = toolbarFullTitle
            } else {
                setToolbarIconsColor(Color.BLACK)

                // Somewhere in between
            }
        }
    }

    private fun onPickData() {
        val picChooserContract =
            registerForActivityResult(ActivityResultContracts.GetContent()) { imageUri ->
                imageUri?.let {
                    editAvatarViewModel.setImageUri(it)
                }
            }

        val takePictureContract =
            registerForActivityResult(TakePictureWithUriReturnContract()) { (success, imageUri) ->
                if (success) {
                    imageUri.let {
                        editAvatarViewModel.setImageUri(it)
                    }
                }
            }

        setFragmentResultListener(ChooseEditPhotoAction.REQUEST_EDIT_PHOTO_ACTION_KEY) { _, bundle ->
            val action = bundle.getInt(ChooseEditPhotoAction.EDIT_PHOTO_ACTION_BUNDLE_KEY)
            when (ChooseEditPhotoAction.EditPhotoAction.values()[action]) {
                ChooseEditPhotoAction.EditPhotoAction.CHOOSE -> {
                    picChooserContract.launch(IMAGE)
                }
                ChooseEditPhotoAction.EditPhotoAction.TAKE -> {
                    takePictureContract.launch(getTmpFileUri())
                }
                ChooseEditPhotoAction.EditPhotoAction.DELETE -> {
                    deleteUserAva()
                }
            }
        }
    }

    private fun getTmpFileUri(): Uri {
        val tmpFile =
            File.createTempFile(
                EditUserAvatarFragment.TEMP_FILE_NAME_PREFIX,
                EditUserAvatarFragment.PNG, requireContext().cacheDir
            ).apply {
                createNewFile()
                deleteOnExit()
            }

        return FileProvider.getUriForFile(
            requireContext(),
            "${BuildConfig.APPLICATION_ID}${EditUserAvatarFragment.PROVIDER}",
            tmpFile
        )
    }

    private fun deleteUserAva() {
        val imageUri = Uri.Builder().scheme(ContentResolver.SCHEME_ANDROID_RESOURCE)
            .authority(resources.getResourcePackageName(R.drawable.ic_ava_default))
            .appendPath(resources.getResourceTypeName(R.drawable.ic_ava_default))
            .appendPath(resources.getResourceEntryName(R.drawable.ic_ava_default)).build()

        editAvatarViewModel.setImageUri(imageUri)
    }

    private fun setToolbarIconsColor(colorRes: Int) {
        for (i in 0 until binding.toolbar.menu.size) {
            val icon = binding.toolbar.menu.getItem(i).icon
            icon?.mutate()
            icon?.colorFilter = BlendModeColorFilterCompat.createBlendModeColorFilterCompat(
                colorRes, BlendModeCompat.SRC_ATOP
            )
        }

        binding.toolbar.setNavigationIconTint(colorRes)
    }

    enum class ProfileType {
        MY,
        OTHER
    }

    companion object {
        const val PROFILE_TYPE_KEY = "profile_type_key"
        const val OTHER_PROFILE_ID_KEY = "other_profile_id_key"
        private const val IMAGE = "image/*"
        private const val URI_DELIMITER = "/"
    }
}