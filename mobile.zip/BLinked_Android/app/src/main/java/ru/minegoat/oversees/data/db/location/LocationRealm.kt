package ru.minegoat.oversees.data.db.location

import io.realm.kotlin.types.ObjectId
import io.realm.kotlin.types.RealmObject
import io.realm.kotlin.types.annotations.PrimaryKey
import ru.minegoat.oversees.base.helpers.syncer.SyncAction
import ru.minegoat.oversees.base.helpers.syncer.SyncStatus
import ru.minegoat.oversees.base.utils.latitudeLongitudeToLatLng
import ru.minegoat.oversees.domain.location.Location
import ru.minegoat.oversees.domain.location.LocationType
import java.util.*

//TODO fix extends bugs with storable
class LocationRealm() : RealmObject {
    var syncStatus: SyncStatus? = null
    var syncStatusDateTime: Date? = null
    var syncAction: SyncAction? = null

    @PrimaryKey
    var id: ObjectId = ObjectId.create()
    val objID: String //(computed value)
        get() {
            return id.toString()
        }

    var name: String? = null
    var latitude: Double? = null
    var longitude: Double? = null

    private var _type: String? = null
    var type: LocationType?
        get() {
            _type?.let {
                return LocationType.valueOf(it)
            }
            return null
        }
        set(value) {
            value?.let {
                _type = it.name
            }
        }

    var descriptionLocation: String? = null

    var cityLocationRealm: LocationRealm? = null
//    val cityLocation: Location //computed value
//        get() {
//            return toLocation()
//        }

    var countryLocationRealm: LocationRealm? = null
//    val countryLocation: Location //computed value
//        get() {
//            return toLocation()
//        }

    var timeZoneIdentifier: String? = null
//    val timeZone: TimeZone //computed value
//        get() {
//            //TODO
//            return TimeZone.getDefault()
//        }

    var codeIATA: String? = null
    var countryCode: String? = null
    var externalID: String? = null
    var address: String? = null
    var phoneNumber: String? = null
    var website: String? = null
    var internationalName: String? = null
    var internationalAddress: String? = null
    var ownerID: String? = null
    var isUsing: Boolean = false
    var wildCity: Boolean = false

    constructor(
        objID: String,
        name: String? = null,
        latitude: Double? = null,
        longitude: Double? = null,
        type: LocationType? = null,
        descriptionLocation: String? = null,
        cityLocationRealm: LocationRealm? = null,
        countryLocationRealm: LocationRealm? = null,
        timeZoneIdentifier: String? = null,
        codeIATA: String? = null,
        countryCode: String? = null,
        externalID: String? = null,
        address: String? = null,
        phoneNumber: String? = null,
        website: String? = null,
        internationalName: String? = null,
        internationalAddress: String? = null,
        ownerID: String? = null,
        isUsing: Boolean = false,
        wildCity: Boolean = false
    ) : this() {
        this.id = ObjectId.Companion.from(objID)
        this.name = name
        this.latitude = latitude
        this.longitude = longitude
        this.type = type
        this.descriptionLocation = descriptionLocation
        this.cityLocationRealm = cityLocationRealm
        this.countryLocationRealm = countryLocationRealm
        this.timeZoneIdentifier = timeZoneIdentifier
        this.codeIATA = codeIATA
        this.countryCode = countryCode
        this.externalID = externalID
        this.address = address
        this.phoneNumber = phoneNumber
        this.website = website
        this.internationalName = internationalName
        this.internationalAddress = internationalAddress
        this.ownerID = ownerID
        this.isUsing = isUsing
        this.wildCity = wildCity
    }
}

fun LocationRealm.toLocation(): Location {
    return Location(
        objID = objID,
        name = name,
        internationalName = internationalName,
        latLng = latitudeLongitudeToLatLng(latitude, longitude),
        type = type,
        descriptionLocation = descriptionLocation,
//        cityLocation = cityLocation,
//        countryLocation = countryLocation,
//        timeZone = timeZone,
        codeIATA = codeIATA,
        address = address,
        internationalAddress = internationalAddress,
        phoneNumber = phoneNumber,
        website = website,
        countryCode = countryCode,
        externalID = externalID,
        ownerID = ownerID,
        isUsing = isUsing,
        wildCity = wildCity
    )
}