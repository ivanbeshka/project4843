package ru.minegoat.oversees.modules.chat.network

import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.Single
import ru.minegoat.oversees.data.network.chat.model.ChatResponse
import ru.minegoat.oversees.modules.chat.network.responses.MessageResponse

interface ChatApi {
    fun getChat(chatId: String): Maybe<ChatResponse>
    fun getAllMessages(chatId: String): Single<List<MessageResponse>>
    fun readMessage(messageId: String, userId: String): Completable
}