package ru.minegoat.oversees.base.viewmodels

import androidx.lifecycle.ViewModel
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable

open class RxViewModel : ViewModel() {
    private val compositeDisposable = CompositeDisposable()

    fun Disposable.disposeOnFinish() {
        compositeDisposable.add(this)
    }

    fun provideDisposable(disposable: Disposable) {
        compositeDisposable.add(disposable)
    }

    override fun onCleared() {
        compositeDisposable.clear()
    }
}