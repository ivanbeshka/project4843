package ru.minegoat.oversees.data.network.location

import ru.minegoat.oversees.domain.location.Location
import ru.minegoat.oversees.domain.location.LocationType

fun createLocations(locationsPojo: List<LocationNetwork>): List<Location> {
    val countries = locationsPojo.filter { it.type == LocationType.COUNTRY.name.lowercase() }
        .map {
            it.toLocation(null, null)
        }

    val cities = locationsPojo.filter { it.type == LocationType.CITY.name.lowercase() }
        .map {
            val itCountry = countries.find { country ->
                country.objID == it.countryLocationID
            }
            it.toLocation(itCountry, null)
        }

    val otherLocations = locationsPojo.filter {
        it.type != LocationType.COUNTRY.name.lowercase() && it.type != LocationType.CITY.name.lowercase()
    }.map {
        val itCountry = countries.find { country ->
            country.objID == it.countryLocationID
        }
        val itCity = cities.find { city ->
            city.objID == it.cityLocationID
        }

        it.toLocation(itCountry, itCity)
    }

    return listOf(*countries.toTypedArray(), *cities.toTypedArray(), *otherLocations.toTypedArray())
}