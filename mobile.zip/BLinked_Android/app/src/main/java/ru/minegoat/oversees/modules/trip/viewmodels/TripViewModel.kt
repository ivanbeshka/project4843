package ru.minegoat.oversees.modules.trip.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import ru.minegoat.oversees.base.viewmodels.*
import ru.minegoat.oversees.domain.trip.Trip
import ru.minegoat.oversees.modules.trip.repository.TripRepository

class TripViewModel @AssistedInject constructor(
    private val utils: TripRepository
) : RxViewModel() {

    private val _trip = MutableLiveData<Trip>()
    val trip: LiveData<Trip> = _trip

    fun getTrip(objId: String) = viewModelScope.launch {
        delay(1000)
        _trip.value = utils.getTrip(objId)
    }

    @AssistedFactory
    interface Factory {
        fun create(): TripViewModel
    }
}