package ru.minegoat.oversees.data.network.user.model

import com.google.gson.annotations.SerializedName

class ResponseShortUser (
    @SerializedName("items")
    val items: List<ResponseShortUserItem>
)