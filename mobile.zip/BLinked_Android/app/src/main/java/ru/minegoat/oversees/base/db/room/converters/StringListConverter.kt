package ru.minegoat.oversees.base.db.room.converters

import androidx.room.TypeConverter
import com.google.gson.Gson

import com.google.gson.reflect.TypeToken

class StringListConverter {

    private val type = object : TypeToken<List<String>>() {}.type
    private val gson = Gson()

    @TypeConverter
    fun fromString(value: String): List<String> {
        return Gson().fromJson(value, type)
    }

    @TypeConverter
    fun fromArrayList(list: List<String>): String {
        return gson.toJson(list)
    }
}