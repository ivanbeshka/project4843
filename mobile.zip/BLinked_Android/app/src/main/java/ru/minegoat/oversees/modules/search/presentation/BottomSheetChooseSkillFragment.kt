package ru.minegoat.oversees.modules.search.presentation

import android.content.res.Resources
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatCheckBox
import androidx.core.os.bundleOf
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.databinding.FragmentBottomSheetChooseTechnicBinding
import ru.minegoat.oversees.domain.user.Skill
import ru.minegoat.oversees.modules.search.di.SearchComponentHolder


class BottomSheetChooseSkillFragment() :
    BottomSheetDialogFragment(R.layout.fragment_bottom_sheet_choose_technic) {

    private val binding by viewBinding(FragmentBottomSheetChooseTechnicBinding::bind)

    private var adapter: SkillsAdapter? = null
    private var choosenAdapter: ChoosenSkillAdapter? = null
    private val component by featureComponent(SearchComponentHolder)

    private val viewModel by lazyViewModel {
        component.searchViewModel().create()
    }

    val chooseTechnics = mutableSetOf<Skill>()
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        choosenAdapter = ChoosenSkillAdapter(
            object : RecyclerSkillDescriptionClickListener {
                override fun onClick(v: View, position: Int, item: Skill) {
                    parentFragmentManager.setFragmentResult(
                        CHOOSE_SKILL_KEY, bundleOf(
                            CHOOSE_SKILL_NAME to item.name,
                            CHOOSE_SKILL_DESCRIPTION to item.skillDescription
                        )
                    )

                    findNavController().navigate(R.id.action_bottomSheetChooseTechnicFragment_to_bottomSheetTechnicDescriptionFragment)
                }
            },
            object : RecyclerViewCheckBoxClickListener {
                override fun onClick(v: View, position: Int, item: Skill) {
                    if (v is AppCompatCheckBox) {
                        chooseTechnics.remove(item)
                    }
                    adapter?.let { adapter ->
                        val skillPos = adapter.data.indexOf(item)
                        adapter.updateChecked(false, skillPos)
                        adapter.notifyDataSetChanged()
                    }
                    viewModel.choosenSkillsList.value = chooseTechnics
                }
            }
        )
        adapter = SkillsAdapter(
            object : RecyclerSkillDescriptionClickListener {
                override fun onClick(v: View, position: Int, item: Skill) {
                    parentFragmentManager.setFragmentResult(
                        CHOOSE_SKILL_KEY, bundleOf(
                            CHOOSE_SKILL_NAME to item.name,
                            CHOOSE_SKILL_DESCRIPTION to item.skillDescription
                        )
                    )
                    findNavController().navigate(R.id.action_bottomSheetChooseTechnicFragment_to_bottomSheetTechnicDescriptionFragment)
                }
            },
            object : RecyclerViewCheckBoxClickListener {
                override fun onClick(v: View, position: Int, item: Skill) {
                    if (v is AppCompatCheckBox && v.isChecked) {
                        chooseTechnics.add(item)
                    } else if (v is AppCompatCheckBox && !v.isChecked) {
                        chooseTechnics.remove(item)
                    }
                    viewModel.choosenSkillsList.value = chooseTechnics
                }
            }
        )
        return super.onCreateView(inflater, container, savedInstanceState)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.llTechnics.minimumHeight = Resources.getSystem().displayMetrics.heightPixels
        binding.rcPopularTechnics.adapter = adapter
        binding.btnSelectSkill.setOnClickListener {
            findNavController().previousBackStackEntry?.savedStateHandle?.set(
                CHOOSE_SKILL_NAME, chooseTechnics,
            )
            dismiss()
        }
        binding.rcChoosenTechnics.adapter = choosenAdapter

        viewModel.choosenSkillsList.observe(viewLifecycleOwner) {
            choosenAdapter!!.data = it.toMutableList()
            loadChooseSkills(it.toMutableList())
        }

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                viewModel.getSkillsListBySearch(skillName = s.toString())
            }
        })
        loadSkills()
    }

    private fun loadSkills() {
        viewModel.getSkillsList()
            .observe(viewLifecycleOwner) { state ->
                state.on(
                    success = { skillList ->
                        val skillsToDisplay = mutableListOf<Skill>()
                        skillList.forEach {
                            skillsToDisplay.add(it)
                        }
                        adapter?.let { adapter ->
                            adapter.data = skillsToDisplay.toList()
                        }
                    },
                    error = {
                        Log.d("Error", "onLoadingSkills ${it.message}")
                    }
                )
            }
    }

    private fun loadChooseSkills(skills: MutableList<Skill>) {
        choosenAdapter?.let { adapter ->
            adapter.data = skills
            adapter.notifyDataSetChanged()
        }
    }



    companion object {
        const val CHOOSE_SKILL_KEY = "CHOOSE_SKILL_KEY"
        const val CHOOSE_SKILL_NAME = "CHOOSE_SKILL_NAME"
        const val CHOOSE_SKILL_DESCRIPTION = "CHOOSE_SKILL_DESCRIPTION"

        const val CHOOSE_SKILL_NAME_CHECKBOX = "CHOOSE_SKILL_NAME_CHECKBOX"
    }
}