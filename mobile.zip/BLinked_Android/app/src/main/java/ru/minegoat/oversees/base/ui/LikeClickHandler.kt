package ru.minegoat.oversees.base.ui

import android.view.View

class LikeClickHandler {
    fun onLikeClick(card: View) {
//        (card as MaterialCardView).child
        card.isSelected = !card.isSelected
    }
}