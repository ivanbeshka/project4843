package ru.minegoat.oversees.modules.master_profile.presentation

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.databinding.FragmentUserSkillsBinding
import ru.minegoat.oversees.domain.user.MasterSkill
import ru.minegoat.oversees.domain.user.Skill
import ru.minegoat.oversees.modules.user_profile.di.UserProfileComponentHolder
import ru.minegoat.oversees.modules.user_profile.presentation.UserProfileFragment

class UserSkillsFragment : Fragment(R.layout.fragment_user_skills) {

    private val binding by viewBinding(FragmentUserSkillsBinding::bind)

    private val component by featureComponent(UserProfileComponentHolder)

    private val skillViewModel by lazyViewModel {
        component.skillsViewModel().create()
    }

    private val userProfileViewModel by lazyViewModel {
        component.userProfileViewModel().create()
    }

    private val editUserViewModel by lazyViewModel {
        component.editUserProfileViewModel().create()
    }
    var userId: String = ""
    var masterSkills: List<MasterSkill> = emptyList()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val skillsAdapter = UserSkillsAdapter(object : UserSkillsAdapter.OnClick {
            override fun show(skill: Skill) {
                //TODO переход на карточку техники
//        findNavController().navigate(
//            R.id.action_userTechniquesFragment_to_searchSkillFragment
//        )
            }

            override fun executeAction(skill: Skill) {
                val newMasterSkills = masterSkills.toMutableList()
                newMasterSkills.removeIf { it.objId == skill.objId }
                masterSkills = newMasterSkills
                editUserViewModel.setUser(skills = newMasterSkills)
                editUserViewModel.saveUserProfileForSkills()
                skillViewModel.getUserSkills(newMasterSkills.map { it.objId })
            }

        })
        binding.skillsList.adapter = skillsAdapter



        userProfileViewModel.user.observe(viewLifecycleOwner) { state ->
            state.on(success = {
                editUserViewModel.setUser(it)
                userId = it.userId
                it.skills?.let { masterSkillsList ->
                    masterSkills = masterSkillsList
                    subscribeOnGetUserSkills(skillsAdapter, masterSkillsList)
                }
            }, error = {
                //todo check internet connection
                Log.e(TAG, "getUserProfile: ${it.message}", it)
            })
        }

        setOnToolbarClickListeners()
        setOnAddSkillClickListener()
    }

    override fun onResume() {
        userProfileViewModel.getUserProfile(UserProfileFragment.ProfileType.MY)
        super.onResume()
    }

    private fun subscribeOnGetUserSkills(
        userSkillsAdapter: UserSkillsAdapter,
        masterSkills: List<MasterSkill>
    ) {
        with(binding) {
            val skillsIds = masterSkills.map { it.objId }
            skillViewModel.getUserSkills(skillsIds)
            skillViewModel.masterSkillList.observe(viewLifecycleOwner) { state ->
                state.on(
                    success = {
                        val skillsWithExp: MutableList<Skill> = arrayListOf()
                        for (i in it.indices) {
                            for (j in masterSkills.indices) {
                                if (it[i].objId == masterSkills[j].objId) {
                                    val skillWithExp = it[i]
                                    skillWithExp.experience = masterSkills[j].experience
                                    skillsWithExp.add(skillWithExp)
                                    break
                                }
                            }
                        }
                        userSkillsAdapter.data = skillsWithExp
                        val counterTExt = "${resources.getString(R.string.added_techniques)} ${it.size}"
                        addedSkilsTitle.text = counterTExt
                        emptySkillsPanel.isVisible = it.isEmpty()
//                        addSkillButton.isVisible = it.isNotEmpty()
                    },
                    error = {
                        userSkillsAdapter.data = emptyList()
                        val counterText = "${resources.getString(R.string.added_techniques)} 0"
                        addedSkilsTitle.text = counterText
                        emptySkillsPanel.isVisible = true
//                        addSkillButton.isVisible = false
                    }
                )
            }
        }
    }

    private fun setOnToolbarClickListeners() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun setOnAddSkillClickListener() {
        binding.addSkillButton.setOnClickListener {
            findNavController().navigate(
                R.id.action_useSkillsFragment_to_searchSkillFragment
            )
        }
        binding.addSkillEmptyButton.setOnClickListener {
            findNavController().navigate(
                R.id.action_useSkillsFragment_to_searchSkillFragment
            )
        }
    }

    companion object {
        private const val TAG = "UserSkillsFragment"
    }
}