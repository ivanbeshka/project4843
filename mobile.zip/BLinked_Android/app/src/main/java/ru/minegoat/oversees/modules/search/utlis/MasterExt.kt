package ru.minegoat.oversees.modules.search.utlis

class MasterExt {
}