package ru.minegoat.oversees.base.di.modules

import android.content.Context
import dagger.Module
import dagger.Provides
import retrofit2.Retrofit
import ru.minegoat.oversees.base.helpers.file_manager.FileManager
import ru.minegoat.oversees.data.network.filemanager.GetFilesApi
import javax.inject.Singleton

@Module
class FileManagerModule {
    @Singleton
    @Provides
    fun provideFileManager(context: Context, getFiles: GetFilesApi): FileManager =
            FileManager(context, getFiles)

    @Singleton
    @Provides
    fun provideGetFilesApi(retrofit: Retrofit): GetFilesApi =
            retrofit.create(GetFilesApi::class.java)
}