package ru.minegoat.oversees.modules.user_profile.presentation

import android.os.Bundle
import android.view.View
import android.widget.PopupMenu
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.navigation.fragment.findNavController
import androidx.viewpager2.adapter.FragmentStateAdapter
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.tabs.TabLayoutMediator
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.FragmentAllEventsBinding
import ru.minegoat.oversees.modules.master_profile.presentation.EventType

class AllEventsFragment : Fragment(R.layout.fragment_all_events) {

    private val binding by viewBinding(FragmentAllEventsBinding::bind)

    override fun onDestroyView() {
        super.onDestroyView()
        binding.vpEvents.adapter = null
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tbEvents.setNavigationOnClickListener { findNavController().popBackStack() }

        binding.btnSorting.setOnClickListener { popup() }

        initVP()

        initTL()
    }

    private fun popup() {
        val popup = PopupMenu(this@AllEventsFragment.context, binding.btnSorting)
        popup.inflate(R.menu.events_sorting)
        popup.setOnMenuItemClickListener { item ->
            binding.apply {
                when (item.itemId) {
                    R.id.by_date -> {
                        btnSorting.text = getString(R.string.by_date)
                        btnSorting.setPaddingRelative(
                            binding.root.resources.getDimension(R.dimen.filter_btn_padding).toInt(),
                            btnSorting.paddingTop,
                            binding.root.resources.getDimension(R.dimen.filter_btn_padding).toInt(),
                            btnSorting.paddingBottom
                        )
                    }
                    R.id.by_price -> {
                        btnSorting.text = getString(R.string.by_price)
                        btnSorting.setPaddingRelative(
                            binding.root.resources.getDimension(R.dimen.filter_btn_padding).toInt(),
                            btnSorting.paddingTop,
                            binding.root.resources.getDimension(R.dimen.filter_btn_padding).toInt(),
                            btnSorting.paddingBottom
                        )
                    }
                    R.id.by_duration -> {
                        btnSorting.text = getString(R.string.duration)
                        btnSorting.setPaddingRelative(
                            binding.root.resources.getDimension(R.dimen.filter_btn_padding_duration).toInt(),
                            btnSorting.paddingTop,
                            binding.root.resources.getDimension(R.dimen.filter_btn_padding_duration).toInt(),
                            btnSorting.paddingBottom
                        )
                    }
                }
            }
            true
        }
        popup.show()
    }

    private fun initTL() {
        TabLayoutMediator(binding.tabEvents, binding.vpEvents) { tab, position ->
            when (position) {
                0 -> tab.text = getString(R.string.upcoming)
                1 -> tab.text = getString(R.string.past)
            }
        }.attach()
    }

    private fun initVP() {
        binding.vpEvents.adapter = AllEventsVPAdapter(
            this@AllEventsFragment.childFragmentManager,
            this@AllEventsFragment.lifecycle
        )
    }

    private class AllEventsVPAdapter(fm: FragmentManager, lifecycle: Lifecycle) :
        FragmentStateAdapter(fm, lifecycle) {

        override fun createFragment(position: Int) = when (EventType.values()[position]) {
            EventType.UPCOMING -> {
                AllEventsVPItemFragment.newInstance(EventType.UPCOMING)
            }
            EventType.PAST -> {
                AllEventsVPItemFragment.newInstance(EventType.PAST)
            }
        }

        override fun getItemCount(): Int = EventType.values().size
    }
}