package ru.minegoat.oversees.modules.map.presentation.map

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.IntentSender.SendIntentException
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResultListener
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.location.*
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.GoogleMap.OnMyLocationButtonClickListener
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.maps.android.clustering.ClusterManager
import com.google.maps.android.collections.MarkerManager
import ru.minegoat.oversees.R
import ru.minegoat.oversees.domain.location.marker
import ru.minegoat.oversees.base.utils.ui.dialogs.LocationRationaleDialog
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.base.utils.ui.fragment.showToast
import ru.minegoat.oversees.databinding.FragmentMapBinding
import ru.minegoat.oversees.domain.location.Location
import ru.minegoat.oversees.modules.map.di.MapComponentHolder
import ru.minegoat.oversees.modules.map.model.LocationClusterItem
import ru.minegoat.oversees.modules.map.presentation.search.SearchLocationsFragment

class MapFragment : Fragment(R.layout.fragment_map), OnMapReadyCallback,
    OnMyLocationButtonClickListener {

    private val component by featureComponent(MapComponentHolder)

    private val viewModel by lazyViewModel {
        component.locationViewModel().create()
    }

    private val locationUtils by lazy {
        component.locationUtils()
    }

    private val binding by viewBinding(FragmentMapBinding::bind)

    private var googleApiClient: GoogleApiClient? = null
    private lateinit var map: GoogleMap
    private var isFirstEnableLocation = true

    //add markers to this
    private lateinit var markerManager: MarkerManager
    private lateinit var clusterManager: ClusterManager<LocationClusterItem>
    private lateinit var clusterRender: MyClusterRender

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val mapFragment = (childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment)
        mapFragment.getMapAsync(this)

        with(binding) {
            fabMyLocation.setOnClickListener {
                enableMyLocation()

                if (!locationUtils.isLocationPermissionGranted()
                    && !locationUtils.isShowLocationPermissionRationale(requireActivity())
                ) {
                    showToast(R.string.permission_required_toast)

                    //go to settings
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    val uri: Uri = Uri.fromParts(SCHEME_PACKAGE, requireActivity().packageName, null)
                    intent.data = uri
                    startActivity(intent)
                }
            }

            viewSearch.tilSearch.setOnClickListener {
                findNavController().navigate(R.id.action_mapFragment_to_searchFragment)
            }

            viewSearch.etSearch.setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    findNavController().navigate(R.id.action_mapFragment_to_searchFragment)
                }
            }
        }

        setSearchLocationResultListener()
    }

    override fun onMapReady(googleMap: GoogleMap) {
        //first init [start]
        map = googleMap
        markerManager = MarkerManager(map)
        clusterManager = ClusterManager(context, map, markerManager)
        clusterRender = MyClusterRender(requireContext(), map, clusterManager)
        clusterManager.renderer = clusterRender
        //first init [end]

        googleMap.uiSettings.isCompassEnabled = false
        googleMap.uiSettings.isMapToolbarEnabled = false
        googleMap.setMapStyle(
            MapStyleOptions.loadRawResourceStyle(
                requireContext(),
                R.raw.map_style
            )
        )

        loadMarkers()
        setOnMarkerClickListener()

        map.setOnCameraIdleListener(clusterManager)
        setOnClusterClickListener()

        if (isFirstEnableLocation) {
            enableMyLocation()
            isFirstEnableLocation = false
        }
    }

    override fun onMyLocationButtonClick(): Boolean {
        //if false - move camera to user location automatic
        return false
    }

    private fun setOnMarkerClickListener() {
        clusterManager.setOnClusterItemClickListener { locationItem ->
            onMarkerClick(locationItem)
            true
        }
    }

    private fun onMarkerClick(locationItem: LocationClusterItem) {
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(locationItem.position, ZOOM_PLACE))

        locationItem.location.let {
            binding.viewSearch.etSearch.setText(it.name)
            findNavController().navigate(
                MapFragmentDirections.actionMapFragmentToMarkerInfoBottomSheet(
                    it.objID
                )
            )
        }
    }

    private fun setOnClusterClickListener() {
        clusterManager.setOnClusterClickListener {
            val builder = LatLngBounds.builder()
            for (item in it.items) {
                builder.include(item.position)
            }
            val bounds = builder.build()

            try {
                map.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, CLUSTERS_PADDING))
            } catch (e: Exception) {
                Log.d(TAG, "setOnClusterClickListener: ${e.message}")
            }

            true
        }
    }

    //if user click on location in search fragment
    private fun setSearchLocationResultListener() {
        setFragmentResultListener(SearchLocationsFragment.REQUEST_KEY_LOCATION_MAP) { _, bundle ->
            val objID = bundle.getString(SearchLocationsFragment.BUNDLE_KEY_LOCATION_ID)
            objID?.let { id ->
                viewModel.getLocationById(id).observe(viewLifecycleOwner) { state ->
                    state.on(
                        success = {
                            Log.d(TAG, "onGetLocation: $it")
                            binding.viewSearch.etSearch.setText(it.name)

                            it.latLng?.let { latLng ->
                                map.moveCamera(
                                    CameraUpdateFactory.newLatLngZoom(
                                        latLng,
                                        ZOOM_PLACE
                                    )
                                )

                                val marker =
                                    clusterManager.markerCollection.markers.find { marker ->
                                        marker.position == latLng
                                    }
                                val clusterItem: LocationClusterItem? =
                                    clusterRender.getClusterItem(marker)

                                clusterItem?.let { item ->
                                    onMarkerClick(item)
                                }

                                Log.d(TAG, "setSearchLocation Marker: $marker")
                            }
                        },
                        error = {
                            Log.d(TAG, "onGetLocation: ${it.message}")
                        }
                    )
                }
            }
        }
    }

    private fun loadMarkers() {
        viewModel.getUsedLocations().observe(viewLifecycleOwner) { state ->
            state.on(
                success = { locations ->
                    //todo
                    map.clear()
                    locations.forEach {
                        addLocationMarker(it)
                    }
                    clusterManager.cluster()
                    Log.d(TAG, "onLoadLocations ok $locations")
                },
                error = {
                    Log.d(TAG, "onLoadingLocations ${it.message}")
                }
            )
        }
    }

    private fun addLocationMarker(location: Location) {
        location.latLng?.let { latLng ->
            location.type?.marker()?.let {
                Log.d(TAG, "addLocationMarker: $location")
                val item = LocationClusterItem(latLng, location)

                val isUpdate = clusterManager.updateItem(item)
                if (!isUpdate) {
                    clusterManager.addItem(item)
                }
            }
        }
    }

    /**
     * Enables the My Location layer if the fine location permission has been granted.
     */
    @SuppressLint("MissingPermission", "ResourceType")
    private fun enableMyLocation() {

        // 1. Check if permissions are granted, if so, enable the my location layer
        if (locationUtils.isLocationPermissionGranted()) {
            map.isMyLocationEnabled = true
            enableSystemLocation()

            val locationButton =
                (childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment)
                    .view?.findViewById<View>(LOCATION_BUTTON_ID)
            locationButton?.visibility = View.GONE

            locationButton?.callOnClick()
            return
        }

        // 2. If if a permission rationale dialog should be shown
        if (locationUtils.isShowLocationPermissionRationale(requireActivity())) {
            LocationRationaleDialog.newInstance(
                LOCATION_PERMISSION_REQUEST_CODE
            ).show(requireActivity().supportFragmentManager, DIALOG_TAG)
            return
        }

        locationPermissionRequest.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )
    }

    private val locationPermissionRequest = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->

        val fineLocationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION]
        val coarseLocationGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION]
        if (fineLocationGranted != null && fineLocationGranted) {
            enableMyLocation()
        } else if (coarseLocationGranted != null && coarseLocationGranted) {
            enableMyLocation()
        }
    }

    //todo find not deprecated solution
    // not deprecated solution
    // https://developers.google.com/android/reference/com/google/android/gms/location/SettingsClient
    // not working(((
    private fun enableSystemLocation() {
        if (!locationUtils.isSystemLocationEnabled()) {

            if (googleApiClient == null) {
                googleApiClient = GoogleApiClient.Builder(requireContext())
                    .addApi(LocationServices.API)
                    .addConnectionCallbacks(object : GoogleApiClient.ConnectionCallbacks {
                        override fun onConnected(bundle: Bundle?) {}
                        override fun onConnectionSuspended(i: Int) {
                            googleApiClient?.connect()
                        }
                    })
                    .addOnConnectionFailedListener { connectionResult ->
                        Log.d(TAG, "Location error " + connectionResult.errorCode)
                    }.build()
            }

            googleApiClient?.connect()
            val locationRequest: LocationRequest = LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY,
                LOCATION_UPDATE_INTERVAL
            )
                .setMinUpdateIntervalMillis(LOCATION_UPDATE_FASTEST_INTERVAL)
                .build()


            val builder = LocationSettingsRequest.Builder()
                .addLocationRequest(locationRequest)
                .setAlwaysShow(true)

            val result = LocationServices.SettingsApi.checkLocationSettings(
                googleApiClient!!,
                builder.build()
            )

            result.setResultCallback {
                when (it.status.statusCode) {
                    LocationSettingsStatusCodes.RESOLUTION_REQUIRED -> try {

                        it.status.startResolutionForResult(requireActivity(), REQUEST_LOCATION)

                    } catch (e: SendIntentException) {
                        // Ignore the error.
                    }
                }
            }
        }
    }

    private companion object {
        private const val CLUSTERS_PADDING = 100

        private const val LOCATION_BUTTON_ID = 0x2

        private const val SCHEME_PACKAGE = "package"

        private const val ZOOM_ALL = 15f
        private const val ZOOM_PLACE = 17f

        private const val TAG = "Maps"
        private const val DIALOG_TAG = "Dialog"

        private const val LOCATION_PERMISSION_REQUEST_CODE = 198
        private const val REQUEST_LOCATION = 199
        private const val LOCATION_UPDATE_INTERVAL = 10000L
        private const val LOCATION_UPDATE_FASTEST_INTERVAL = 5000L
    }
}