package ru.minegoat.oversees.modules.master_profile.repository

import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.Single
import io.realm.kotlin.query.Sort
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import ru.minegoat.oversees.base.db.realm.Sorted
import ru.minegoat.oversees.data.db.master.MasterInfoRealm
import ru.minegoat.oversees.data.db.master.MasterTypeRealm
import ru.minegoat.oversees.data.db.master.toMasterInfo
import ru.minegoat.oversees.domain.master.MasterInfo
import ru.minegoat.oversees.domain.master.MasterType
import ru.minegoat.oversees.domain.master.toMasterInfoRealm
import ru.minegoat.oversees.domain.master.toMasterType
import javax.inject.Inject


class MasterInfoRepository @Inject constructor(
    private val ds: RealmDataStorage
) {
    fun getMasterInfoById(objectId: String): Maybe<MasterInfo> =
        ds.getById(MasterInfoRealm::class, objectId)
            .map {
                it.toMasterInfo(this)
            }

    fun getMasterInfoByUserId(masterID: String): Maybe<MasterInfo> =

        Maybe.create {
            try {
                val masterInfo = ds.fetch(
                    model = MasterInfoRealm::class,
                    predicate = "$MASTER_ID_PREDICATE = \'$masterID\'"
                )
                    .map {
                        it.first()
                    }
                    .map {
                        it.toMasterInfo(this)
                    }.blockingGet()
                if (masterInfo.masterTypes.isEmpty())
                    it.onSuccess(masterInfo)
                val masterTypeList = mutableListOf<MasterType>()
                masterInfo.masterTypes.forEach {
                    val masterType = getMasterTypeById(it.objID).blockingGet()
                    masterTypeList.add(
                        MasterType(
                            objID = masterType.objID,
                            name = masterType.name.lowercase(),
                            masterTypeDescription = masterType.masterTypeDescription
                        )
                    )
                }
                val newMasterInfo = MasterInfo(
                    objId = masterInfo.objId,
                    masterTypes = masterTypeList,
                    path = masterInfo.path,
                    masterId = masterInfo.masterId
                )
                it.onSuccess(newMasterInfo)
            } catch (e: java.lang.Exception) {
                it.onError(e)
            }
        }

    fun saveMasterInfo(masterInfo: MasterInfo): Completable =
        ds.update(masterInfo.toMasterInfoRealm())

    private fun getMasterTypeById(objId: String): Maybe<MasterType> =
        ds.getById(MasterTypeRealm::class, objId)
            .map {
                it.toMasterType()
            }

    fun getMasterTypes(): Single<List<MasterType>> =
        ds.fetch(MasterTypeRealm::class, sorted = Sorted("name", Sort.ASCENDING))
            .flattenAsFlowable {
                it
            }
            .map {
                it.toMasterType()
            }
            .toList()


    private companion object {
        private const val MASTER_ID_PREDICATE = "masterId"
    }

}