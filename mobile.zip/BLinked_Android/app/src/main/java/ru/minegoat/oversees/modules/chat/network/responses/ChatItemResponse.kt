package ru.minegoat.oversees.modules.chat.network.responses

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.data.network.chat.model.ChatResponse
import ru.minegoat.oversees.domain.chat.toMessageUi
import ru.minegoat.oversees.modules.chat.model.ChatItemUi
import ru.minegoat.oversees.modules.chat.model.ShortChatUi
import ru.minegoat.oversees.modules.chat.presentation.ChatListVPItemFragment.ChatListType

data class ChatItemResponse(
    @SerializedName("chat")
    val chat: ChatResponse,
    @SerializedName("last_message")
    val lastMessage: MessageResponse,
    @SerializedName("unread_msgs_count")
    val unreadMessagesCount: Int
)

fun ChatItemResponse.toChatItem(myUserId: String): ChatItemUi {
    return ChatItemUi(
        //todo chatListType
        chat = ShortChatUi(chat.objID, chat.name, ChatListType.ALL, chat.iconUrl),
        lastMessage = lastMessage.toMessage().toMessageUi(myUserId),
        unreadMessagesCount
    )
}