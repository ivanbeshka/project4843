package ru.minegoat.oversees.modules.map.presentation.map

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.core.view.isGone
import androidx.fragment.app.DialogFragment
import androidx.navigation.fragment.navArgs
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.DialogChooseMapBinding

class ChooseMapFragment : DialogFragment(R.layout.dialog_choose_map) {

    private val args: ChooseMapFragmentArgs by navArgs()
    private val latLng by lazy { args.latLng }

    private val binding by viewBinding(DialogChooseMapBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupMapsContainers()

        //if not found ymaps or gmaps go to store and install gmaps
        if (binding.containerGoogleMap.visibility == View.GONE
            && binding.containerYandexMap.visibility == View.GONE
        ) {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse("market://details?id=$GOOGLE_MAP_PACKAGE_NAME")
            startActivity(intent)
        }
    }

    private fun setupMapsContainers() {
        val pm = requireActivity().packageManager

        with(binding) {
            val yandexMapUri = Uri.parse(
                "yandexmaps://maps.yandex.ru/?rtext=~${latLng.latitude},${latLng.longitude}"
            )
            setupMapContainer(
                pm,
                yandexMapUri,
                YANDEX_MAP_PACKAGE_NAME,
                ivYandexMapIcon,
                tvYandexMapName,
                containerYandexMap
            )

            val googleMapUri = Uri.parse(
                "https://maps.google.com/maps?f=d&daddr=${latLng.latitude},${latLng.longitude}"
            )
            setupMapContainer(
                pm,
                googleMapUri,
                GOOGLE_MAP_PACKAGE_NAME,
                ivGoogleMapIcon,
                tvGoogleMapName,
                containerGoogleMap
            )
        }
    }

    private fun setupMapContainer(
        pm: PackageManager,
        uri: Uri,
        packageName: String,
        ivIcon: ImageView,
        tvName: TextView,
        container: View
    ) {
        val mapIntent = Intent(Intent.ACTION_VIEW, uri)
        mapIntent.setPackage(packageName)

        try {
            ivIcon.setImageDrawable(pm.getActivityIcon(mapIntent))
            tvName.text = pm.getApplicationLabel(
                pm.getApplicationInfo(
                    GOOGLE_MAP_PACKAGE_NAME, 0
                )
            )
        } catch (e: Exception) {
            Log.d(TAG, "onMapViewInit $packageName: $e")
            container.isGone = true
        }

        ivIcon.setOnClickListener {
            Log.d(TAG, "onMapClick: $packageName")
            mapIntent.resolveActivity(pm)?.let {
                startActivity(mapIntent)
            }
        }
    }

    private companion object {
        private const val GOOGLE_MAP_PACKAGE_NAME = "com.google.android.apps.maps"
        private const val YANDEX_MAP_PACKAGE_NAME = "ru.yandex.yandexmaps"

        private const val TAG = "ChooseMapFragment"
    }
}