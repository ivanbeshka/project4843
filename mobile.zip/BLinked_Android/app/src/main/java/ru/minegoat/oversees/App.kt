package ru.minegoat.oversees

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.util.Log
import com.google.android.gms.maps.MapsInitializer
import com.google.android.gms.maps.MapsInitializer.Renderer
import com.google.android.gms.maps.OnMapsSdkInitializedCallback
import ru.minegoat.oversees.modules.main.presentation.MainActivity
import ru.minegoat.oversees.base.di.AppComponent
import ru.minegoat.oversees.base.di.DaggerAppComponent
import ru.minegoat.oversees.base.di.modules.*
import ru.minegoat.oversees.base.helpers.syncer.Syncer

internal class App : Application(), OnMapsSdkInitializedCallback {
    override fun onCreate() {
        super.onCreate()
        component = DaggerAppComponent.builder()
            .appModule(AppModule(this))
            .realmModule(RealmModule())
            .roomModule(RoomModule())
            .locationModule(LocationModule())
            .retrofitModule(RetrofitModule())
            .utilsModule(UtilsModule())
            .syncerModule(SyncerModule())
            .messengerModule(MessengerModule())
            .authModule(AuthModule())
            .fileManagerModule(FileManagerModule())
            .documentRepositoryModule(DocumentRepositoryModule())
            .commentRepositoryModule(CommentRepositoryModule())
            .build()

        syncer = component.syncer()

        registerActivityCallbacks()

        //check maps version
        MapsInitializer.initialize(applicationContext, Renderer.LATEST, this)
    }

    override fun onMapsSdkInitialized(renderer: Renderer) {
        when (renderer) {
            Renderer.LATEST -> Log.d("MapsDemo", "The latest version of the renderer is used.")
            Renderer.LEGACY -> Log.d("MapsDemo", "The legacy version of the renderer is used.")
        }
    }

    private fun registerActivityCallbacks() {
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityCreated(activity: Activity, bundle: Bundle?) {}

            override fun onActivityStarted(activity: Activity) {}

            override fun onActivityResumed(activity: Activity) {
                if (activity is MainActivity) {
                    syncer.onResume()
                }
            }

            override fun onActivityPaused(activity: Activity) {
                if (activity is MainActivity) {
                    syncer.onPause()
                }
            }

            override fun onActivityStopped(activity: Activity) {}

            override fun onActivitySaveInstanceState(activity: Activity, bundle: Bundle) {}

            override fun onActivityDestroyed(activity: Activity) {}
        })
    }

    companion object {
        lateinit var component: AppComponent
            private set
        lateinit var syncer: Syncer
            private set
    }
}