package ru.minegoat.oversees.modules.user_profile.presentation

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.ItemCheckPhoneNumBinding
import ru.minegoat.oversees.domain.user.CountryPhone

class BottomSheetCheckPhoneNumAdapter(
    private val onItemClick: OnItemClick
) :
    RecyclerView.Adapter<BottomSheetCheckPhoneNumAdapter.CountryPhoneViewHolder>() {

    interface OnItemClick {
        fun setPhoneNum(countryPhone: CountryPhone)
    }

    private val differCallback = object : DiffUtil.ItemCallback<CountryPhone>() {
        override fun areItemsTheSame(oldItem: CountryPhone, newItem: CountryPhone): Boolean =
            oldItem.countryName == newItem.countryName

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: CountryPhone, newItem: CountryPhone): Boolean =
            oldItem.phonePrefix == newItem.phonePrefix
    }

    val differ = AsyncListDiffer(this, differCallback)

    var data: List<CountryPhone>
        get() = differ.currentList
        set(value) = differ.submitList(value)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryPhoneViewHolder =
        CountryPhoneViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.item_check_phone_num, parent, false)
        )

    override fun onBindViewHolder(holder: CountryPhoneViewHolder, position: Int) {
        holder.bind(data[position])
    }

    override fun getItemCount(): Int = data.size

    inner class CountryPhoneViewHolder(root: View) : RecyclerView.ViewHolder(root) {

        private val binding by viewBinding(ItemCheckPhoneNumBinding::bind)

        fun bind(countryPhone: CountryPhone) = with(binding) {
            tvCountryPrefix.apply {
                val setText = "${countryPhone.countryName} (${countryPhone.phonePrefix})"
                text = setText
                setOnClickListener {
                    onItemClick.setPhoneNum(countryPhone)
                }
            }
        }
    }
}