package ru.minegoat.oversees.data.repository.skill

import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.Single
import io.realm.kotlin.query.Sort
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import ru.minegoat.oversees.base.db.realm.Sorted
import ru.minegoat.oversees.data.db.skill.SkillRealm
import ru.minegoat.oversees.data.db.skill.toSkill
import ru.minegoat.oversees.data.network.skill.SkillApi
import ru.minegoat.oversees.data.network.skill.responses.toBusiness
import ru.minegoat.oversees.domain.user.Skill
import javax.inject.Inject

class SkillRepository @Inject constructor(
    private val api: SkillApi,
    private val ds: RealmDataStorage,
) {

    fun getSkillsList(): Single<List<Skill>> {
        return api.getSkillsList().map {
            it.items.map { skill ->
                skill.toBusiness()
            }
        }
    }

    fun getSkillsListByPredicate(predicate: String): Single<List<Skill>> {
        return api.getSkillsList()
            .map {
                it.items.map { skill ->
                    skill.toBusiness()
                }
                    .filter { skill ->
                        skill.name?.contains(predicate) ?: false
                    }
            }
    }

    fun getSkillById(objId: String): Maybe<Skill> {
        return ds.getById(SkillRealm::class, objId)
            .map { it.toSkill() }
    }

    fun getSkillsBySkillsIds(skillsIds: List<String>): Single<List<Skill>> {
        val dbPredicate =
            "$SKILLS_IDS_PREDICATE { ${skillsIds.joinToString { "oid(${it.trim()})" }}}"

        return ds.fetch(SkillRealm::class, dbPredicate)
            .map { skillRealm -> skillRealm.map { it.toSkill() } }
    }

    fun getSkillsWithPredicate(predicate: String): Single<List<Skill>> {
        //TODO tags predicate doesn't work
        val dbPredicate = "$NAME_PREDICATE '$predicate'"
//        val dbPredicate = "$NAME_PREDICATE '$predicate' $OR '#${predicate.trim()}' $TAGS_PREDICATE"

//        if (predicate.isBlank()) {
//            return Single.just(listOf())
//        }
        return ds.fetch(SkillRealm::class, dbPredicate, Sorted("name", Sort.ASCENDING))
            .map { skillRealm -> skillRealm.map { it.toSkill() } }
    }

    fun saveSkill(skill: SkillRealm): Completable {
        return ds.save(skill)
    }

    fun updateSkill(skillId: String): Completable {
        return ds.update(ds.getById(SkillRealm::class, skillId).blockingGet())
    }

    private companion object {
        private const val TAGS_PREDICATE = "CONTAINS[c] tags"
        private const val NAME_PREDICATE = "name CONTAINS[c]"
        private const val SKILLS_IDS_PREDICATE = "id IN"
        private const val AND = "AND"
        private const val OR = "OR"
    }
}