package ru.minegoat.oversees.modules.user_profile.presentation

import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipDrawable
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.ItemTechniqueShortBinding
import ru.minegoat.oversees.modules.user_profile.model.SkillUi


class DetailSkillAdapter(private val onClickListener: (skillId: String) -> Unit)
    :ListAdapter<SkillUi, DetailSkillAdapter.DetailSkillHolder>(DiffCallback){

    class DetailSkillHolder(private val binding: ItemTechniqueShortBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(
            skill: SkillUi,
            onClickListener: (userId: String) -> Unit
        ) {
            binding.tvName.text = skill.name
            for (tag in skill.tags) {
                val chip = Chip(this.itemView.context)
                val drawable = ChipDrawable.createFromAttributes(
                    this.itemView.context,
                    null,
                    0,
                    R.style.ActionChipStyle_Master
                )
                chip.setTextAppearanceResource(R.style.ActionChipStyle_Master)
                chip.setChipDrawable(drawable)
                chip.text = tag
                binding.chipGroup.addView(chip)
                binding.btOpenProfile.setOnClickListener {
                    onClickListener(skill.objId)
                }
            }

        }
    }

        companion object{
            private val DiffCallback = object : DiffUtil.ItemCallback<SkillUi>(){
                override fun areContentsTheSame(
                    oldItem: SkillUi,
                    newItem: SkillUi
                ): Boolean {
                    return oldItem.name == newItem.name
                            && oldItem.tags == newItem.tags
                }

                override fun areItemsTheSame(oldItem: SkillUi, newItem: SkillUi): Boolean {
                    return oldItem.objId == newItem.objId
                }
            }
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DetailSkillHolder {
        val viewHolder = DetailSkillHolder(
            ItemTechniqueShortBinding.inflate
                (LayoutInflater.from(parent.context), parent, false)
        )
        return viewHolder
    }

    override fun onBindViewHolder(holder: DetailSkillHolder, position: Int) {
        val item = getItem(position)
        holder.bind(getItem(position) ){
            onClickListener(item.objId)
        }
    }
}