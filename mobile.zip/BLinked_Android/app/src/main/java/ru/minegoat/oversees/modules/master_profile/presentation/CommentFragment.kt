package ru.minegoat.oversees.modules.master_profile.presentation

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.navigation.fragment.findNavController
import androidx.viewpager2.adapter.FragmentStateAdapter
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.tabs.TabLayoutMediator
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.FragmentFeedbackBinding
import ru.minegoat.oversees.domain.user.FeedbackType

class FeedbackFragment : Fragment(R.layout.fragment_feedback) {

    private val binding by viewBinding(FragmentFeedbackBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tbFeedback.setNavigationOnClickListener { findNavController().popBackStack() }

        initVP()

        initTL()
    }

    private fun initVP() {
        binding.vpFeedback.adapter = FeedbackVPAdapter(
            this@FeedbackFragment.childFragmentManager,
            this@FeedbackFragment.lifecycle
        )
    }

    private fun initTL() {
        TabLayoutMediator(binding.tabFeedback, binding.vpFeedback) { tab, position ->
            when (position) {
                0 -> tab.text = getString(R.string.masters)
                1 -> tab.text = getString(R.string.clients)
            }
        }.attach()
    }

    private class FeedbackVPAdapter(fm: FragmentManager, lifecycle: Lifecycle) :
        FragmentStateAdapter(fm, lifecycle) {

        override fun createFragment(position: Int) =
            when (FeedbackType.values()[position]) {
                FeedbackType.MASTERS -> {
                    FeedbackListVPItemFragment.newInstance(true)
                }
                FeedbackType.CLIENTS -> {
                    FeedbackListVPItemFragment.newInstance(false)
                }
            }

        override fun getItemCount(): Int = FeedbackType.values().size

        private enum class FeedbackType {
            MASTERS,
            CLIENTS
        }
    }
}