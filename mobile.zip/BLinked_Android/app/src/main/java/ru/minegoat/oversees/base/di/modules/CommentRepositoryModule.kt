package ru.minegoat.oversees.base.di.modules

import dagger.Module
import dagger.Provides
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import ru.minegoat.oversees.data.repository.comment.CommentRepository
import javax.inject.Singleton

@Module
class CommentRepositoryModule {

    @Singleton
    @Provides
    fun provideCommentRepository(ds: RealmDataStorage): CommentRepository = CommentRepository(ds)
}