package ru.minegoat.oversees.modules.trip.network

import io.reactivex.Single
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import ru.minegoat.oversees.data.network.search.model.TripRequest
import ru.minegoat.oversees.modules.trip.network.responses.ResponseShortTrip
import ru.minegoat.oversees.modules.trip.network.responses.ResponseTrip

interface TripApi {

    @GET("trip/details")
    suspend fun getTrip(@Query("id") objId: String): Response<ResponseTrip>

    @GET("search/trips")
    fun getTripList(@Query("location") objId: String): Single<ResponseShortTrip>

    @GET("search/trips")
    fun getTripList(): Single<ResponseShortTrip>

    @POST("search/trips")
    fun sendSearchRequest(@Body tripRequest: TripRequest) : Single<ResponseShortTrip>

}