package ru.minegoat.oversees.modules.master_profile.presentation

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.ItemEventNewBinding

class EventsTechnicAdapter: RecyclerView.Adapter<EventsTechnicAdapter.MainViewHolder>() {

    class MainViewHolder(view: View): RecyclerView.ViewHolder(view) {
        private val binding by viewBinding(ItemEventNewBinding::bind)

        fun bind(position: Int) {
            binding.tvEventName.text = "Путешествие на горный Алтай"
            binding.ivEventImage.setImageResource(R.drawable.altai)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_event_new, parent, false)
        view.layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT
        val params = view.layoutParams as ViewGroup.MarginLayoutParams
        val margin = view.context.resources.getDimensionPixelOffset(R.dimen.margin_events_technic)
        params.setMargins(margin, 0, margin,margin)
        return MainViewHolder(view)
    }

    override fun onBindViewHolder(holder: MainViewHolder, position: Int) {
        holder.bind(position)

    }

    override fun getItemCount(): Int {
        return 2
    }

}