package ru.minegoat.oversees.modules.map.presentation.search

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.ItemSearchLocationBinding
import ru.minegoat.oversees.domain.location.Location

class SearchLocationsAdapter(
    private val onLocationClick: (objID: String) -> Unit
) : RecyclerView.Adapter<SearchLocationsAdapter.ViewHolder>() {

    private val differ = AsyncListDiffer(this, LocationDiffUtilCallback())
    var data: List<Location>
        get() = differ.currentList
        set(value) = differ.submitList(value)

    inner class ViewHolder(root: View) : RecyclerView.ViewHolder(root) {
        private val binding by viewBinding(ItemSearchLocationBinding::bind)

        fun bind(location: Location) {
            binding.location = location

            binding.containerSearchLocation.setOnClickListener {
                onLocationClick(location.objID)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val root = inflater.inflate(R.layout.item_search_location, parent, false)
        return ViewHolder(root)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val location = data[position]
        holder.bind(location)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    private class LocationDiffUtilCallback : DiffUtil.ItemCallback<Location>() {
        override fun areItemsTheSame(oldItem: Location, newItem: Location): Boolean {
            return oldItem.objID == newItem.objID
        }

        override fun areContentsTheSame(oldItem: Location, newItem: Location): Boolean {
            return oldItem == newItem
        }
    }
}