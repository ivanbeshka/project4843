package ru.minegoat.oversees.modules.trip.network.responses

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.ShortTrip
import ru.minegoat.oversees.domain.user.ShortUser

class ResponseShortTripItem (
    @SerializedName("objID")
    val objId: String,
    @SerializedName("ownerID")
    val ownerId: String,
    @SerializedName("startDate")
    val startDate: Long?,
    @SerializedName("endDate")
    val endDate: Long?,
    @SerializedName("tags")
    val tags: String?,
    @SerializedName("mainImage")
    val mainImage: String?,
    @SerializedName("reviewsNumber")
    val reviewsNumber: Int?,
    @SerializedName("shortMilestones")
    val shortMilestones: List<ResponseShortMilestone>?,
    @SerializedName("name")
    val name: String?,
)

fun ResponseShortTripItem.toBusiness(owner: ShortUser): ShortTrip {
    return ShortTrip(
        objId = objId,
        owner = owner,
        name = name,
        startDate = startDate,
        endDate = endDate,
        mainImage = mainImage,
        tags = tags,
        shortMilestones = shortMilestones?.map { it.toBusiness() },
        reviewsNumber = reviewsNumber,
    )
}