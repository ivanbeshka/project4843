package ru.minegoat.oversees.modules.main.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.data.fixtures.LocationsFixture
import ru.minegoat.oversees.modules.main.repository.LocationsFixtureRepository
import ru.minegoat.oversees.base.viewmodels.*

class LocationsFixtureViewModel @AssistedInject constructor(
    private val repository: LocationsFixtureRepository
) : RxViewModel() {

    private val locationsFixtureLiveData = MutableLiveData<ScreenState<Boolean>>()

    fun saveLocationsFixture(): LiveData<ScreenState<Boolean>> {
        repository.saveLocationsFixture(LocationsFixture.locations)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { locationsFixtureLiveData.value = LoadingScreenState() }
            .subscribeBy(
                onComplete = {
                    locationsFixtureLiveData.value = SuccessScreenState(true)
                },
                onError = {
                    locationsFixtureLiveData.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()

        return locationsFixtureLiveData
    }

    @AssistedFactory
    interface Factory {
        fun create(): LocationsFixtureViewModel
    }
}