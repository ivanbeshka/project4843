package ru.minegoat.oversees.modules.master_profile.presentation

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.SpaceDividerItemDecoration
import ru.minegoat.oversees.databinding.ItemEventsListBinding

class EventsListsAdapter : RecyclerView.Adapter<EventsListsAdapter.ViewHolder>() {

    inner class ViewHolder(root: View) : RecyclerView.ViewHolder(root) {
        private val binding by viewBinding(ItemEventsListBinding::bind)

        private var minHeight = 0

        fun bind(position: Int) {
            binding.rvEvents.adapter = EventsAdapter(EventType.values()[position], true)
            binding.rvEvents.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                    super.onScrollStateChanged(recyclerView, newState)
                    val newHeight = recyclerView.measuredHeight
                    if (0 != newHeight && minHeight < newHeight) {
                        // keep track the height and prevent recycler view optimizing by resizing
                        minHeight = newHeight
                        recyclerView.minimumHeight = minHeight;
                    }
                }
            })
            binding.root.requestLayout()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val root = inflater.inflate(R.layout.item_events_list, parent, false)
        return ViewHolder(root)
    }

    override fun getItemCount(): Int {
        return 2
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(position)
    }
}