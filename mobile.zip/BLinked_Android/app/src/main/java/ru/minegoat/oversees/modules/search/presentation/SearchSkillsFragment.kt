package ru.minegoat.oversees.modules.search.presentation

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.databinding.FragmentSearchTechniquesBinding
import ru.minegoat.oversees.domain.user.Skill
import ru.minegoat.oversees.modules.search.di.SearchComponentHolder

class SearchSkillsFragment : Fragment(R.layout.fragment_search_techniques) {
    private val binding by viewBinding(FragmentSearchTechniquesBinding::bind)

    private val component by featureComponent(SearchComponentHolder)

    private val viewModel by lazyViewModel {
        component.searchViewModel().create()
    }

    private val skills = mutableListOf<String>()
    private val skillsIds = mutableListOf<String>()
    private val skillsNames = mutableListOf<String>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        findNavController().currentBackStackEntry?.savedStateHandle?.getLiveData<String>(
            BottomSheetChooseDateFragment.SET_RESULT_DATE_START
        )
            ?.observe(viewLifecycleOwner) {

                binding.etEventDate.setText(it)

            }
        findNavController().currentBackStackEntry?.savedStateHandle?.getLiveData<List<Skill>>(
            BottomSheetChooseSkillFragment.CHOOSE_SKILL_NAME
        )
            ?.observe(viewLifecycleOwner) {

                it.forEach {skill ->
                    skill.name?.let { it1 -> skillsNames.add(it1) }
                    skillsIds.add(skill.objId)
                }
                val toText = skillsNames.toString()
                binding.etEventTechnic.setText(toText.substring(1, toText.length - 1))
            }

        binding.apply {
            etEventTechnic.setOnClickListener() {
                findNavController().navigate(R.id.action_chooseSearchFragment_to_bottomSheetChooseTechnicFragment)
            }
            etEventType.setOnClickListener() {
                findNavController().navigate(R.id.action_chooseSearchFragment_to_bottomSheetChooseSkillType)
            }
            etEventDate.setOnClickListener {
                findNavController().navigate(R.id.action_chooseSearchFragment_to_bottomSheetChooseDateFragment)
            }
            etEventLocation.setOnClickListener {
                // TODO:  
            }
            viewModel.tripData.observe(viewLifecycleOwner) { state ->
                state.on(
                    success = {
                        Toast.makeText(requireContext(), "$it", Toast.LENGTH_SHORT).show()
                    }
                )
            }
            btnSearch.setOnClickListener() {
                findNavController().previousBackStackEntry?.savedStateHandle?.set(
                    SEND_FORM_SKILLS, skillsIds,
                )

                findNavController().previousBackStackEntry?.savedStateHandle?.set(
                    SEND_FORM_STATUS, true,
                )
                findNavController().navigateUp()
            }
        }
    }

    companion object {
        @JvmStatic
        fun newInstance(type: SearchType) = SearchSkillsFragment()

        const val SEND_FORM_KEY = "SEND_FORM_KEY"
        const val SEND_FORM_SKILLS = "SEND_FORM_SKILLS"
        const val SEND_FORM_MASTER_TYPES = "SEND_FORM_MASTER_TYPES"
        const val SEND_FORM_STATUS = "SEND_FORM_STATUS"
    }
}