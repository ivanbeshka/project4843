package ru.minegoat.oversees.data.repository.comment

import io.reactivex.Completable
import io.reactivex.Observable
import io.reactivex.Single
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import ru.minegoat.oversees.data.db.comment.CommentRealm
import ru.minegoat.oversees.data.db.comment.toComment
import ru.minegoat.oversees.domain.feedback.Comment
import ru.minegoat.oversees.domain.feedback.toCommentRealm
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CommentRepository @Inject constructor(private val ds: RealmDataStorage) {

    fun saveComment(comment: Comment, linkedObjId: String): Completable =
        Observable
            .just(comment)
            .concatMapCompletable {
                ds.save(it.toCommentRealm(linkedObjId))
            }

    fun getComments(linkedObjId: String): Single<List<Comment>> =
        ds.fetch(
            CommentRealm::class,
            "$OBJ_LINK_ID_PREDICATE \"$linkedObjId\""
        )
            .flattenAsFlowable { comments ->
                comments
            }
            .map { commentRealm ->
                commentRealm.toComment()
            }
            .toList()

    private companion object {
        private const val OBJ_LINK_ID_PREDICATE = "linkedObjId =="
    }
}