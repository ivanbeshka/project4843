package ru.minegoat.oversees.modules.chat.model

import ru.minegoat.oversees.modules.chat.presentation.ChatListVPItemFragment.ChatListType

data class ShortChatUi(
    val objID: String,
    val name: String,
    val type: ChatListType,
    val iconUrl: String?,
    val dates: String? = null //for linked trip (16 окт - 12 ноя 2022)
)