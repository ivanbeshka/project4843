package ru.minegoat.oversees.base.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.TypedArray
import android.util.AttributeSet
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.TextView
import androidx.appcompat.widget.AppCompatTextView
import ru.minegoat.oversees.R

class ExpandableTextView(context: Context, attrs: AttributeSet?, defStyle: Int) :
    AppCompatTextView(context, attrs, defStyle) {

    private val onExpandListeners: MutableList<OnExpandListener>

    var expandInterpolator: TimeInterpolator

    var collapseInterpolator: TimeInterpolator
    val myMaxLines: Int
    private var animationDuration: Long
    private var animating = false

    var isExpanded = false
        private set
    private var collapsedHeight = 0

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)

    init {
        val attributes: TypedArray =
            context.obtainStyledAttributes(attrs, R.styleable.ExpandableTextView, defStyle, 0)
        animationDuration = attributes.getInt(
            R.styleable.ExpandableTextView_animation_duration,
            DEF_ANIMATION_DURATION
        ).toLong()
        attributes.recycle()

        // keep the original value of maxLines
        myMaxLines = maxLines

        // create bucket of OnExpandListener instances
        onExpandListeners = ArrayList()

        // create default interpolators
        expandInterpolator = AccelerateDecelerateInterpolator()
        collapseInterpolator = AccelerateDecelerateInterpolator()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        // if this TextView is collapsed and maxLines = 0,
        // than make its height equals to zero
        var hMS = heightMeasureSpec
        if (myMaxLines == 0 && !isExpanded && !animating) {
            hMS = MeasureSpec.makeMeasureSpec(0, MeasureSpec.EXACTLY)
        }
        super.onMeasure(widthMeasureSpec, hMS)
    }

    /**
     * Toggle the expanded state of this [ExpandableTextView].
     * @return true if toggled, false otherwise.
     */
    fun toggle(): Boolean {
        return if (isExpanded) collapse() else expand()
    }

    /**
     * Expand this [ExpandableTextView].
     * @return true if expanded, false otherwise.
     */
    fun expand(): Boolean {
        if (!isExpanded && !animating && myMaxLines >= 0) {
            // notify listener
            notifyOnExpand()

            // measure collapsed height
            measure(
                MeasureSpec.makeMeasureSpec(this.measuredWidth, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
            )
            collapsedHeight = this.measuredHeight

            // indicate that we are now animating
            animating = true

            // set maxLines to MAX Integer, so we can calculate the expanded height
            maxLines = Int.MAX_VALUE

            // measure expanded height
            measure(
                MeasureSpec.makeMeasureSpec(this.measuredWidth, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
            )
            val expandedHeight = this.measuredHeight

            // animate from collapsed height to expanded height
            val valueAnimator = ValueAnimator.ofInt(collapsedHeight, expandedHeight)
            valueAnimator.addUpdateListener { animation ->
                this@ExpandableTextView.height = animation.animatedValue as Int
            }

            // wait for the animation to end
            valueAnimator.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    // reset min & max height (previously set with setHeight() method)
                    this@ExpandableTextView.maxHeight = Int.MAX_VALUE
                    this@ExpandableTextView.minHeight = 0

                    // if fully expanded, set height to WRAP_CONTENT, because when rotating the device
                    // the height calculated with this ValueAnimator isn't correct anymore
                    this@ExpandableTextView.layoutParams.height =
                        ViewGroup.LayoutParams.WRAP_CONTENT

                    // keep track of current status
                    isExpanded = true
                    animating = false
                }
            })

            // set interpolator
            valueAnimator.interpolator = expandInterpolator

            // start the animation
            valueAnimator
                .setDuration(animationDuration)
                .start()
            return true
        }
        return false
    }

    /**
     * Collapse this [TextView].
     * @return true if collapsed, false otherwise.
     */
    fun collapse(): Boolean {
        if (isExpanded && !animating && myMaxLines >= 0) {
            // notify listener
            notifyOnCollapse()

            // measure expanded height
            val expandedHeight = this.measuredHeight

            // indicate that we are now animating
            animating = true

            // animate from expanded height to collapsed height
            val valueAnimator = ValueAnimator.ofInt(expandedHeight, collapsedHeight)
            valueAnimator.addUpdateListener { animation ->
                this@ExpandableTextView.height = animation.animatedValue as Int
            }

            // wait for the animation to end
            valueAnimator.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    // keep track of current status
                    isExpanded = false
                    animating = false

                    // set maxLines back to original value
                    maxLines = myMaxLines

                    // if fully collapsed, set height back to WRAP_CONTENT, because when rotating the device
                    // the height previously calculated with this ValueAnimator isn't correct anymore
                    this@ExpandableTextView.layoutParams.height =
                        ViewGroup.LayoutParams.WRAP_CONTENT
                }
            })

            // set interpolator
            valueAnimator.interpolator = collapseInterpolator

            // start the animation
            valueAnimator
                .setDuration(animationDuration)
                .start()
            return true
        }
        return false
    }
    //endregion


    fun setAnimationDuration(animationDuration: Long) {
        this.animationDuration = animationDuration
    }

    fun addOnExpandListener(onExpandListener: OnExpandListener) {
        onExpandListeners.add(onExpandListener)
    }

    fun removeOnExpandListener(onExpandListener: OnExpandListener) {
        onExpandListeners.remove(onExpandListener)
    }

    fun setInterpolator(interpolator: TimeInterpolator) {
        expandInterpolator = interpolator
        collapseInterpolator = interpolator
    }

    private fun notifyOnCollapse() {
        for (onExpandListener in onExpandListeners) {
            onExpandListener.onCollapse(this)
        }
    }

    private fun notifyOnExpand() {
        for (onExpandListener in onExpandListeners) {
            onExpandListener.onExpand(this)
        }
    }

    interface OnExpandListener {
        fun onExpand(view: ExpandableTextView)
        fun onCollapse(view: ExpandableTextView)
    }

    companion object {
        const val DEF_ANIMATION_DURATION = 300
    }
}