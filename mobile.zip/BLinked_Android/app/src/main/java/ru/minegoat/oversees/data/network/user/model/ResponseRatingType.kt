package ru.minegoat.oversees.data.network.user.model

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.user.UserRating
import ru.minegoat.oversees.domain.user.UserRatingType

data class ResponseRatingType(
    @SerializedName("name")
    val name: String
    )

fun ResponseRatingType.toUserRatingType(): UserRatingType {
    return UserRatingType(
        name = this.name
    )
}