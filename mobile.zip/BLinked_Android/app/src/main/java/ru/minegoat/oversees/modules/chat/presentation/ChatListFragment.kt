package ru.minegoat.oversees.modules.chat.presentation

import android.annotation.SuppressLint
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.databinding.FragmentChatListBinding
import ru.minegoat.oversees.modules.chat.di.ChatComponentHolder
import ru.minegoat.oversees.modules.chat.presentation.ChatListVPItemFragment.ChatListType
import ru.minegoat.oversees.modules.chat.utils.UnreadMsgCountUtils

class ChatListFragment : Fragment(R.layout.fragment_chat_list) {

    private val component by featureComponent(ChatComponentHolder)

    private val viewModel by lazyViewModel {
        component.chatListViewModel().create()
    }

    private val binding by viewBinding(FragmentChatListBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initViewPager()

        initTabLayout()

        initTilSearch()

        initChatSearchOnTextChanged()

        subscribeOnUnreadChatsCount()
    }

    private fun subscribeOnUnreadChatsCount() {
        with(binding) {
            viewModel.getUnreadMessagesCount().observe(viewLifecycleOwner) { state ->
                state.on(success = { unreadMsgCountForTabs ->

                    val typesCount = ChatListType.values().size

                    for (i in 0 until typesCount) {
                        val tab = tlChatList.getTabAt(i)
                        val viewUnreadMsgCount =
                            tab?.customView?.findViewById<FrameLayout>(R.id.view_unread_message_count)

                        val tvUnreadMsgCount =
                            viewUnreadMsgCount?.findViewById<TextView>(R.id.tv_message_count)

                        tvUnreadMsgCount?.let {
                            val unreadMsgCountTab =
                                unreadMsgCountForTabs.getByType(ChatListType.values()[i])

                            if (unreadMsgCountTab.count > 0) {
                                viewUnreadMsgCount.visibility = View.VISIBLE
                                tvUnreadMsgCount.visibility = View.VISIBLE
                                it.text =
                                    UnreadMsgCountUtils.unreadMsgCountToString(unreadMsgCountTab.count)
                            } else {
                                viewUnreadMsgCount.visibility = View.INVISIBLE
                            }
                        }
                    }
                })
            }
        }
    }

    private fun initChatSearchOnTextChanged() {
        viewModel.onNextChatNamePredicate("")
        binding.viewSearch.etSearch.doOnTextChanged { text, _, _, _ ->
            text?.let {
                viewModel.onNextChatNamePredicate(it.toString())
            }
        }
    }

    private fun initTilSearch() {
        with(binding) {
            val boxStrokeColor =
                ContextCompat.getColorStateList(requireContext(), R.color.color_til_stroke_chat)
            boxStrokeColor?.let {
                viewSearch.tilSearch.setBoxStrokeColorStateList(it)
            }

            val boxStrokeWidth = resources.getDimensionPixelSize(R.dimen.stroke_0_5)
            viewSearch.tilSearch.boxStrokeWidthFocused = boxStrokeWidth
            viewSearch.tilSearch.boxStrokeWidth = boxStrokeWidth

            val startIconColor =
                ContextCompat.getColorStateList(requireContext(), R.color.color_til_search_icon)
            viewSearch.tilSearch.setStartIconTintList(startIconColor)
        }
    }

    private fun initTabLayout() {
        with(binding) {
            val tabTitles = listOf(
                getString(R.string.all_chats),
                getString(R.string.private_chats),
                getString(R.string.group_chats)
            )
            TabLayoutMediator(tlChatList, vpChatList) { tab, position ->
                tab.setCustomView(R.layout.view_tab_item_chat_list)

                val tvTabName = tab.customView?.findViewById<TextView>(R.id.tv_tab_name)
                tvTabName?.text = tabTitles[position]
            }.attach()


            tlChatList.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab: TabLayout.Tab?) {
                    val tvTabName = tab?.customView?.findViewById<TextView>(R.id.tv_tab_name)
                    tvTabName?.setTypeface(null, Typeface.BOLD)
                }

                override fun onTabUnselected(tab: TabLayout.Tab?) {
                    val tvTabName = tab?.customView?.findViewById<TextView>(R.id.tv_tab_name)
                    tvTabName?.setTypeface(null, Typeface.NORMAL)
                }

                override fun onTabReselected(tab: TabLayout.Tab?) {
                    val tvTabName = tab?.customView?.findViewById<TextView>(R.id.tv_tab_name)
                    tvTabName?.setTypeface(null, Typeface.BOLD)
                }
            })

            tlChatList.getTabAt(START_TAB_POS)?.select()
        }
    }

    private fun initViewPager() {
        with(binding) {
            @SuppressLint("WrongConstant") //not wrong constant
            vpChatList.offscreenPageLimit = VIEWPAGER_TABS

            vpChatList.adapter = ChatListViewPagerAdapter(
                this@ChatListFragment.childFragmentManager,
                this@ChatListFragment.viewLifecycleOwner.lifecycle
            )
        }
    }

    override fun onDestroyView() {
        binding.vpChatList.adapter = null
        super.onDestroyView()
    }

    private class ChatListViewPagerAdapter(fm: FragmentManager, lifecycle: Lifecycle) :
        FragmentStateAdapter(fm, lifecycle) {

        override fun getItemCount(): Int = ChatListType.values().size

        override fun createFragment(position: Int): Fragment {
            return when (ChatListType.values()[position]) {
                ChatListType.ALL -> {
                    ChatListVPItemFragment.newInstance(ChatListType.ALL)
                }
                ChatListType.PRIVATE -> {
                    ChatListVPItemFragment.newInstance(ChatListType.PRIVATE)
                }
                ChatListType.GROUPS -> {
                    ChatListVPItemFragment.newInstance(ChatListType.GROUPS)
                }
            }
        }
    }

    private companion object {
        private const val START_TAB_POS = 0
        private const val VIEWPAGER_TABS = 5
    }
}