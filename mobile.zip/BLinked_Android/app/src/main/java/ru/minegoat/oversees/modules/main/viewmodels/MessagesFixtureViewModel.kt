package ru.minegoat.oversees.modules.main.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.base.viewmodels.*
import ru.minegoat.oversees.data.fixtures.MessagesFixture
import ru.minegoat.oversees.modules.main.repository.MessagesFixtureRepository

class MessagesFixtureViewModel @AssistedInject constructor(
    private val repo: MessagesFixtureRepository
) : RxViewModel() {
    private val messagesFixtureLiveData = MutableLiveData<ScreenState<Boolean>>()

    fun saveMessagesFixture(): LiveData<ScreenState<Boolean>> {
        repo.saveMessages(MessagesFixture.messages)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { messagesFixtureLiveData.value = LoadingScreenState() }
            .subscribeBy(
                onComplete = {
                    messagesFixtureLiveData.value = SuccessScreenState(true)
                },
                onError = {
                    messagesFixtureLiveData.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()

        return messagesFixtureLiveData
    }

    @AssistedFactory
    interface Factory {
        fun create(): MessagesFixtureViewModel
    }
}