package ru.minegoat.oversees.modules.user_profile.presentation

import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.BottomSheetSelectFileDirectoryBinding

class BottomSheetSelectFileDirectory : BottomSheetDialogFragment(R.layout.bottom_sheet_select_file_directory) {

    private val binding by viewBinding(BottomSheetSelectFileDirectoryBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tvPhotoLaunch.apply {
            setOnClickListener {
                setResultAndExit(UserAccountFragment.FragmentAction.TAKE_PHOTO)
            }}

        binding.tvFilesLaunch.apply {
            setOnClickListener {
                setResultAndExit(UserAccountFragment.FragmentAction.CHOOSE_DOC)
            }
        }
    }

    private fun setResultAndExit(resultAction: UserAccountFragment.FragmentAction) {
        setFragmentResult(
            UserAccountFragment.REQUEST_ACTION_KEY,
            bundleOf(UserAccountFragment.ACTION_BUNDLE_KEY to resultAction.ordinal)
        )
        findNavController().navigateUp()
    }
}