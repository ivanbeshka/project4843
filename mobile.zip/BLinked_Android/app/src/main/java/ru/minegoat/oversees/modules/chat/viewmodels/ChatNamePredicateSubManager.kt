package ru.minegoat.oversees.modules.chat.viewmodels

import io.reactivex.Observable
import io.reactivex.subjects.ReplaySubject

class ChatNamePredicateSubManager {

    private val publishSub = ReplaySubject.create<String>()

    fun onNext(namePredicate: String) =
        publishSub.onNext(namePredicate)

    fun get(): Observable<String> =
        publishSub
}