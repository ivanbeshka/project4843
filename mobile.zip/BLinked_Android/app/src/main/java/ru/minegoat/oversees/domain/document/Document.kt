package ru.minegoat.oversees.domain.document

import android.net.Uri
import ru.minegoat.oversees.data.db.document.DocumentRealm

data class Document(
    val objID: String,
    val linkedObjId: String,
    var userFileName: String,
    var storageFileName: String,
    var mediaType: MediaType,
    var uri: Uri
) {
    companion object {
        fun fromUri(uri: Uri): Document {
            val filePath = uri.path
            filePath?.let {
                val fileName = it.substringAfterLast('/', "")
                return Document(
                    objID = "",
                    linkedObjId = "",
                    userFileName = fileName,
                    storageFileName = fileName,
                    mediaType = MediaType.fromFileName(fileName),
                    uri = uri
                )
            } ?: return Document("", "", "", "", MediaType.OTHER, uri)
        }
    }
}

fun Document.toDocumentRealm(linkedObjId: String): DocumentRealm = DocumentRealm(
    objId = this.objID,
    linkedObjId = linkedObjId,
    userFileName = this.userFileName,
    storageFileName = this.uri.toString(),
    mediaType = this.mediaType
)