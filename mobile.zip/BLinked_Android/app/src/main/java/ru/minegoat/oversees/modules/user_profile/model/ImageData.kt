package ru.minegoat.oversees.modules.user_profile.model

data class ImageData(
    val imageByteArray: ByteArray?,
    val imageFileName: String?
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as ImageData

        if (!imageByteArray.contentEquals(other.imageByteArray)) return false
        if (imageFileName != other.imageFileName) return false

        return true
    }

    override fun hashCode(): Int {
        var result = imageByteArray.contentHashCode()
        result = 31 * result + imageFileName.hashCode()
        return result
    }
}
