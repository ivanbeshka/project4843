package ru.minegoat.oversees.modules.user_profile.presentation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import android.widget.ArrayAdapter
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.FragmentFiltersBinding

class FiltersFragment : Fragment(R.layout.fragment_filters) {

    private val binding by viewBinding(FragmentFiltersBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val items = listOf("Путешествие", "Паломничество", "Ретрит", "Церемония", "Событие", "Обучение")
        val adapter = ArrayAdapter(requireContext(), R.layout.item_dropdown_menu_filters, items)
        binding.dropdownFieldType.setAdapter(adapter)

    }
}