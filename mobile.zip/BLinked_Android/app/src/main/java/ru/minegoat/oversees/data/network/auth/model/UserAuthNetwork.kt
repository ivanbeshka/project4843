package ru.minegoat.oversees.data.network.auth.model

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.auth.Role
import ru.minegoat.oversees.domain.auth.UserAuth
import java.time.LocalDateTime

data class UserAuthNetwork(
    @SerializedName("id")
    val id: Int,
    @SerializedName("username")
    val username: String,
    @SerializedName("userIdentifier")
    val userIdentifier: String,
    @SerializedName("password")
    val password: String,
    @SerializedName("apiToken")
    val apiToken: String,
    @SerializedName("roles")
    val roles: ArrayList<String> = arrayListOf(),
    @SerializedName("salt")
    val salt: String? = null,
    @SerializedName("phone")
    val phone: String? = null,
    @SerializedName("description")
    val description: String? = null,
    @SerializedName("isGuide")
    val isGuide: Boolean = false,
    @SerializedName("name")
    val name: String? = null,
    @SerializedName("avatar")
    val avatar: String? = null,
    @SerializedName("lastSuccessfulSyncDate")
    val lastSuccessfulSyncDate: String? = null,
    @SerializedName("lastSyncTryDate")
    val lastSyncTryDate: String? = null,
    @SerializedName("tripsRoles")
    val tripsRoles: ArrayList<String> = arrayListOf(),
    @SerializedName("apiTokenExpiresAt")
    val apiTokenExpiresAt: String,
    @SerializedName("tokenExpired")
    val tokenExpired: Boolean = false
)

fun UserAuthNetwork.toUserAuth(): UserAuth {
    return UserAuth(
        id = id,
        username = username,
        userIdentifier = userIdentifier,
        roles = roles.map { Role.valueOf(it) },
        password = password,
        apiToken = apiToken,
        salt = salt,
        phone = phone,
        description = description,
        isGuide = isGuide,
        name = name,
        avatar = avatar,
        lastSuccessfulSyncDate = lastSuccessfulSyncDate,
        lastSyncTryDate = lastSyncTryDate,
        tripsRoles = tripsRoles,
        apiTokenExpiresAt = LocalDateTime.parse(apiTokenExpiresAt.dropLast(UNUSED_TIME_SIZE)),
        tokenExpired = tokenExpired
    )
}

private const val UNUSED_TIME_SIZE = 6
