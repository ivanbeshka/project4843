package ru.minegoat.oversees.modules.master_profile.di

import javax.inject.Scope

@Scope
annotation class MasterScope