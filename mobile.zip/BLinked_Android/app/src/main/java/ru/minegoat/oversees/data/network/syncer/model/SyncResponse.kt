package ru.minegoat.oversees.data.network.syncer.model

import com.google.gson.annotations.SerializedName

data class SyncResponse(
    @SerializedName("items")
    val items: List<SyncItemResponse>? = null
)
