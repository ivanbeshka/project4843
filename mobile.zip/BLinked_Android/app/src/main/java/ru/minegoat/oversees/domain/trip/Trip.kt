package ru.minegoat.oversees.domain.trip

import ru.minegoat.oversees.domain.user.ShortUser
import ru.minegoat.oversees.domain.chat.ChatLinkedObjType
import ru.minegoat.oversees.domain.chat.IChatLinkedObj

data class Trip(
    val objId: String,
    val ownerId: String? = null,
    val name: String? = null,
    val startDate: Long? = null,
    val endDate: Long? = null,
    val mainImage: String? = null,
    val locked: Boolean? = null,
    val duration: Int? = null,
    val tripDescription: String? = null,
    val users: List<ShortUser>? = null,
    val tags: String? = null,
    var milestones: List<Milestone>? = null,
    val visibility: Boolean? = null,
    val cost: String? = null,
//    val costDescription: Int? = null, // ? = null? = null? = null? = null? = null

    val attentionTagsNumber: Int? = null,
    val badTagsNumber: Int? = null,
    val goodTagsNumber: Int? = null,
    val imagesNumber: Int? = null,
    val reviewsNumber: Int? = null,
) : IChatLinkedObj {

    override fun getId(): String {
        return objId
    }

    override fun getType(): ChatLinkedObjType {
        return ChatLinkedObjType.TRIP
    }

    override fun getChatName(): String {
        return name ?: ""
    }
}