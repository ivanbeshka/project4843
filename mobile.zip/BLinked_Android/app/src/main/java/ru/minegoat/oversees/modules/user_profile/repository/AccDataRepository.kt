package ru.minegoat.oversees.modules.user_profile.repository

import io.reactivex.Completable
import io.realm.kotlin.Realm
import ru.minegoat.oversees.App
import ru.minegoat.oversees.base.db.room.RoomDB
import ru.minegoat.oversees.data.repository.auth.AuthRepository
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import ru.minegoat.oversees.modules.user_profile.network.UserProfileApi
import javax.inject.Inject

class AccDataRepository @Inject constructor(
    private val roomDB: RoomDB,
    private val realm: Realm,
    private val userProfileApi: UserProfileApi,
    private val authSharedPref: AuthSharedPref
) {

    fun deleteAcc(): Completable {
        return userProfileApi.deleteUserProfile()
            .andThen(clearAllDataFromDB())
            .doOnComplete {
                authSharedPref.clear()
                authSharedPref.isDeleted = true
            }
    }

    fun clearAllDataFromDB(): Completable {
        return Completable.create {
            try {
                roomDB.clearAllTables()
                realm.writeBlocking {
                    deleteAll()
                }
            } catch (e: Exception) {
                it.onError(e)
            }

            it.onComplete()
        }
    }
}