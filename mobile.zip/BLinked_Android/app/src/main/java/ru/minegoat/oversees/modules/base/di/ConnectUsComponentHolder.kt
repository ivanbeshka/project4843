package ru.minegoat.oversees.modules.base.di

import ru.minegoat.oversees.App
import ru.minegoat.oversees.base.di.holders.FeatureComponentHolder

object ConnectUsComponentHolder: FeatureComponentHolder<ConnectUsComponent>() {

    override fun build(): ConnectUsComponent {
        return DaggerConnectUsComponent.builder()
            .appComponent(App.component)
            .connectUsModule(ConnectUsModule())
            .build()
    }

}