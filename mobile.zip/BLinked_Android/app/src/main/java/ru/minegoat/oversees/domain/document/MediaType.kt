package ru.minegoat.oversees.domain.document

enum class MediaType {
    IMAGE, VIDEO, PDF, DOC, OTHER;

    companion object {

        private const val jpg = "jpg"
        private const val tif = "tif"
        private const val png = "png"
        private const val pdf = "pdf"
        private const val doc = "doc"
        private const val docx = "docx"
        private const val rtf = "rtf"
        private const val mp4 = "mp4"
        private const val avi = "avi"

        fun fromFileName(name: String): MediaType {
            return when (name.substringAfterLast('.', "").lowercase()) {
                jpg, tif, png  -> IMAGE
                pdf            -> PDF
                doc, docx, rtf -> DOC
                mp4, avi       -> VIDEO
                else           -> OTHER
            }
        }

    }
}

val Int.toMediaType
    get() =
        when (this) {
            MediaType.IMAGE.ordinal -> MediaType.IMAGE
            MediaType.VIDEO.ordinal -> MediaType.VIDEO
            MediaType.PDF.ordinal   -> MediaType.PDF
            MediaType.DOC.ordinal   -> MediaType.DOC
            else                    -> MediaType.OTHER
        }