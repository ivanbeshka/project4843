package ru.minegoat.oversees.modules.chat.network.responses

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.data.db.chat.MessageRoom
import ru.minegoat.oversees.domain.chat.Message

data class MessageResponse(
    @SerializedName("obj_id")
    val objID: String,
    @SerializedName("owner_id")
    val ownerId: String,
    @SerializedName("owner_name")
    val ownerName: String,
    @SerializedName("chat_id")
    val chatId: String,
    @SerializedName("text")
    val text: String,
    @SerializedName("date_time")
    val dateTime: Long, //sec
    @SerializedName("content_url")
    val contentUrl: String? = null
)

fun MessageResponse.toRoom(): MessageRoom {
    return MessageRoom(
        objID = objID,
        ownerId = ownerId,
        ownerName = ownerName,
        chatId = chatId,
        text = text,
        dateTime = dateTime,
        contentUrl = contentUrl
    )
}

fun MessageResponse.toMessage(): Message {
    return Message(
        objID = objID,
        ownerId = ownerId,
        ownerName = ownerName,
        chatId = chatId,
        text = text,
        dateTimeSec = dateTime,
        contentUrl = contentUrl
    )
}
