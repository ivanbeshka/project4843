package ru.minegoat.oversees.modules.master_profile.presentation

import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.FragmentFeedbackListVPItemBinding
import ru.minegoat.oversees.domain.user.FeedbackType
