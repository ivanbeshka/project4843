package ru.minegoat.oversees.data.network.user.model

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.data.network.karma.KAttributeNetwork
import ru.minegoat.oversees.data.network.karma.KarmaNetwork
import ru.minegoat.oversees.data.network.karma.toKarma
import ru.minegoat.oversees.domain.user.ShortUser

class ResponseShortUserItem(
    @SerializedName("avatarURL")
    val avatarURL: String?,
    @SerializedName("id")
    val userId: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("phone")
    val phone: String?,
    @SerializedName("userDescription")
    val description: String?,
    @SerializedName("guide")
    val guide: Boolean,
    @SerializedName("isGuide")
    val isGuide: Boolean,
    @SerializedName("isMaster")
    val isMaster: Boolean,
    @SerializedName("homeLocationID")
    val homeLocationID: String?,
    @SerializedName("sex")
    val sex: String,
    @SerializedName("karmaSum")
    val karmaSum: Int?
)

fun ResponseShortUserItem.toBusiness(): ShortUser {
    return ShortUser(
        userId = userId,
        role = null,
        name = name,
        avatar = avatarURL,
        phone = phone,
        isMaster = isMaster,
        karmaSum = karmaSum
    )
}