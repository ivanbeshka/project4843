package ru.minegoat.oversees.base.di.modules

import dagger.Module
import dagger.Provides
import io.realm.kotlin.Realm
import io.realm.kotlin.RealmConfiguration
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import ru.minegoat.oversees.data.db.location.LocationRealm
import ru.minegoat.oversees.data.db.document.DocumentRealm
import ru.minegoat.oversees.data.db.master.MasterInfoRealm
import ru.minegoat.oversees.data.db.master.MasterTypeRealm
import ru.minegoat.oversees.data.db.skill.SkillRealm
import ru.minegoat.oversees.data.db.userProfile.RequestToMasterStatusModel
import ru.minegoat.oversees.data.db.comment.CommentRealm
import ru.minegoat.oversees.data.db.comment.ShortUserRealm
import javax.inject.Singleton

@Module
class RealmModule {

    @Singleton
    @Provides
    fun provideRealmConf(): RealmConfiguration =
       RealmConfiguration.Builder(
            setOf(
                LocationRealm::class,
                DocumentRealm::class,
                SkillRealm::class,
                CommentRealm::class,
                ShortUserRealm::class,
                RequestToMasterStatusModel::class,
                MasterTypeRealm::class,
                MasterInfoRealm::class
            )
        )
            .schemaVersion(REALM_VERSION).build()

    @Singleton
    @Provides
    fun provideRealm(configuration: RealmConfiguration): Realm =
        Realm.open(configuration)

    //@Singleton
    //@Provides
    //fun provideDataStorage(realm: Realm): DataStorage = RealmDataStorage(realm)

    @Singleton
    @Provides
    fun provideDataStorage(realm: Realm): RealmDataStorage = RealmDataStorage(realm)

    private companion object {
        private const val REALM_VERSION = 1L
    }
}