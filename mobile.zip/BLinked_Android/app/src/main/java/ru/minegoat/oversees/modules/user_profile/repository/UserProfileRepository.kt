package ru.minegoat.oversees.modules.user_profile.repository

import android.util.Base64
import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.Single
import ru.minegoat.oversees.data.db.userProfile.dao.UserDao
import ru.minegoat.oversees.data.db.userProfile.toUser
import ru.minegoat.oversees.data.network.user.model.toUser
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import ru.minegoat.oversees.domain.user.User
import ru.minegoat.oversees.domain.user.toNetwork
import ru.minegoat.oversees.domain.user.toRoom
import ru.minegoat.oversees.modules.user_profile.model.ImageData
import ru.minegoat.oversees.modules.user_profile.network.UserProfileApi
import ru.minegoat.oversees.modules.user_profile.presentation.UserProfileFragment.ProfileType
import javax.inject.Inject

class UserProfileRepository @Inject constructor(
    private val api: UserProfileApi,
    private val userDao: UserDao,
    private val authSharedPref: AuthSharedPref
) {
    fun getUserProfile(profileType: ProfileType, otherUserId: String?): Maybe<User> {
        if (profileType == ProfileType.MY) {
            authSharedPref.userId?.let {
                return getUserProfileFromNetwork(it)
                    .onErrorResumeNext(getUserProfileFromDB(it))
            }
        } else if (profileType == ProfileType.OTHER && otherUserId != null) {
            return getUserProfileFromNetwork(otherUserId)
                .onErrorResumeNext(getUserProfileFromDB(otherUserId))
        }
        return Maybe.empty()
    }

    fun saveUserProfile(user: User, imageToImageData: () -> ImageData): Completable {

        return saveUserToDB(user)
            .andThen(
                Single.create {
                    val imageData = imageToImageData()
                    it.onSuccess(imageData)
                }
                    .flatMapCompletable {
                        val encodedImage = it.imageByteArray?.let { byteArr ->
                            Base64.encodeToString(byteArr, Base64.DEFAULT)
                        }
                        api.updateUserProfile(
                            user.toNetwork(
                                encodedImage,
                                it.imageFileName
                            )
                        )
                    }
            )
    }

    fun saveUserProfileForSkills(user: User): Completable {

        return saveUserToDB(user)
    }

    private fun getUserProfileFromDB(userId: String): Maybe<User> {
        return userDao.getById(userId)
            .map {
                it.toUser()
            }
    }

    private fun getUserProfileFromNetwork(userId: String): Maybe<User> {

        return api.getUserProfile(userId)
            .map {
                it.toUser()
            }
            .doOnSuccess {
                saveUserToDB(it).subscribe()
            }
            .toMaybe()
    }

    private fun saveUserToDB(user: User): Completable {
        return userDao.insert(user.toRoom())
    }
}