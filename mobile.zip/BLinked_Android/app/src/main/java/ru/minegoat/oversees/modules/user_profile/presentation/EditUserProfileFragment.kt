package ru.minegoat.oversees.modules.user_profile.presentation

import android.content.ContentResolver
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemSelectedListener
import android.widget.ArrayAdapter
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import androidx.core.os.bundleOf
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResultListener
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.bumptech.glide.Glide
import com.google.android.material.card.MaterialCardView
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.subscribeBy
import ru.minegoat.oversees.BuildConfig
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.image.TakePictureWithUriReturnContract
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.base.utils.ui.fragment.showToast
import ru.minegoat.oversees.base.utils.ui.loadImageFromOurApi
import ru.minegoat.oversees.base.utils.ui.loadImageFromUri
import ru.minegoat.oversees.base.utils.ui.view.setCountryCode
import ru.minegoat.oversees.base.utils.ui.view.toPhone
import ru.minegoat.oversees.databinding.FragmentEditUserProfileBinding
import ru.minegoat.oversees.domain.auth.Phone
import ru.minegoat.oversees.domain.user.*
import ru.minegoat.oversees.modules.map.presentation.search.SearchLocationsFragment
import ru.minegoat.oversees.modules.master_profile.presentation.SocialNetworkBottomSheet
import ru.minegoat.oversees.modules.user_profile.di.UserProfileComponentHolder
import ru.minegoat.oversees.modules.user_profile.model.ImageData
import java.io.ByteArrayOutputStream
import java.io.File


class EditUserProfileFragment : Fragment(R.layout.fragment_edit_user_profile),
    OnItemSelectedListener {

    private val component by featureComponent(UserProfileComponentHolder)

    private val compositeDisposable = CompositeDisposable()

    private val editUserViewModel by lazyViewModel {
        component.editUserProfileViewModel().create()
    }
    private val userProfileViewModel by lazyViewModel {
        component.userProfileViewModel().create()
    }
    private val editAvatarViewModel by lazyViewModel {
        component.editAvatarViewModel().create()
    }

    private var defaultSocialNetworkList: List<SocialNetwork> = listOf(
        SocialNetwork(SocialNetworkName.INSTAGRAM, ""),
        SocialNetwork(SocialNetworkName.FACEBOOK, ""),
        SocialNetwork(SocialNetworkName.TWITTER, ""),
        SocialNetwork(SocialNetworkName.VK, ""),
        SocialNetwork(SocialNetworkName.TELEGRAM, ""),
        SocialNetwork(SocialNetworkName.YOUTUBE, "")
    )

    private val binding by viewBinding(FragmentEditUserProfileBinding::bind)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        userProfileViewModel.getUserProfile(UserProfileFragment.ProfileType.MY)

        workToToolbar()
        workToAccountImage()
        workToUserName()
        workToSex()
        workToLocation()
        workToPhone()
        workToStatus()
        onSaveAccount()
        onDeleteAccount()
        onGetUserData()
        onPickData()
    }

    override fun onDestroyView() {
        compositeDisposable.clear()
        super.onDestroyView()
    }

    private fun workToToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun workToAccountImage() {
        binding.changeAvatarButton.setOnClickListener {
            findNavController().navigate(R.id.action_editUserProfileFragment_to_changeAvatarBottomSheet)
        }
        editAvatarViewModel.imageUriLiveData.observe(viewLifecycleOwner) { uri ->
            loadImageFromUri(binding.avatarImageView, uri)
        }
    }

    private fun workToUserName() {
        binding.nameEditText.setOnFocusChangeListener { view, hasFocus ->
            val tv = view as EditText
            if (!hasFocus) {
                if (!tv.text.isNullOrBlank()) {
                    editUserViewModel.setUser(name = tv.text.toString().trim())
                } else {
                    showToast(R.string.user_name_not_be_empty)
                }
            }
        }
    }

    private fun workToSex() {
        with(binding.spinnerSex) {
            adapter = ArrayAdapter(
                requireContext(),
                android.R.layout.simple_spinner_item,
                Sex.values().map { getString(it.res) }).apply {
                setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            onItemSelectedListener = this@EditUserProfileFragment
        }
    }

    private fun workToLocation() {
        with(binding) {
            homeLocationPanel.setOnClickListener {
                editHomeLocation()
            }

            locationEditText.setOnClickListener {
                editHomeLocation()
            }
        }
        userProfileViewModel.locationNameLiveData.observe(viewLifecycleOwner)
        { state ->
            state.on(
                success = {
                    binding.locationEditText.setText(it)
                    binding.locationEditText.setTextColor(
                        ContextCompat.getColor(
                            requireContext(),
                            R.color.gray_90,
                        )
                    )
                }
            )
        }
        setFragmentResultListener(SearchLocationsFragment.REQUEST_KEY_LOCATION_EDIT_PROFILE) { _, bundle ->
            bundle.getString(SearchLocationsFragment.BUNDLE_KEY_LOCATION_ID)?.let {
                editUserViewModel.setUser(homeLocationId = it)
            }
        }
    }

    private fun workToPhone() {
        with(binding) {
            phoneCodeTextView.apply {
                setCountryCode(this, CountryPhone("", "+7", CountryFlags.RU))
            }

            changePhoneButton.setOnClickListener {
                findNavController().navigate(R.id.action_editUserProfileFragment_to_checkPhoneNumFragment)
            }
        }
        setFragmentResultListener(CheckPhoneNumFragment.PHONE_REQUEST_KEY) { _, bundle ->

            val phone = bundle.getString(CheckPhoneNumFragment.PHONE_BUNDLE)
            if (phone != null)
                editUserViewModel.setUser(phone = Phone.fromSplitString(phone))
        }
    }

    private fun workToStatus() {
        with(binding) {
            statusEditText.run {
                doOnTextChanged { _, _, _, count ->
                    val newText = "$count ${resources.getString(R.string.from_60_symbols)}"
                    symbolsCounterTextView.text = newText
                }
                setOnFocusChangeListener { view, hasFocus ->
                    val et = view as EditText
                    if (!hasFocus) {
                        if (et.text != null) {
                            editUserViewModel.setUser(aboutMe = et.text.toString().trim())
                        }
                    }
                }
            }
        }
    }

    private fun onSaveAccount() {
        with(binding) {
            saveButton.setOnClickListener {
                nameEditText.clearFocus()
                statusEditText.clearFocus()

                val avaUri = editAvatarViewModel.imageUriLiveData.value

                if (!nameEditText.text.isNullOrEmpty()) {
                    editUserViewModel.saveUser(imageToImageData = {
                        val imageByteArray = avaUri?.let { uri ->
                            val imageBitmap =
                                Glide.with(requireContext()).asBitmap().load(uri).submit().get()

                            val stream = ByteArrayOutputStream()
                            imageBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                            stream.toByteArray()
                        }
                        ImageData(
                            imageByteArray,
                            avaUri?.toString()?.split(URI_DELIMITER)?.last()?.replace("%", "")
                        )
                    })
                } else {
                    showToast(R.string.user_name_not_be_empty)
                }
            }
        }
        editUserViewModel.isUserSaved.observe(viewLifecycleOwner) { state ->
            state.on(
                loading = {
                    binding.scrollContainer.visibility = View.GONE
                    binding.progressBar.visibility = View.VISIBLE
                },
                success = {
                    findNavController().navigate(R.id.action_editUserProfileFragment_to_userProfileFragment)
                },
                error = {
                    showToast(R.string.oops_something_went_wrong)
                    binding.scrollContainer.visibility = View.VISIBLE
                    binding.progressBar.visibility = View.GONE
                }
            )
        }
    }

    private fun onDeleteAccount() {
        binding.deleteButton.setOnClickListener {
            findNavController().navigate(R.id.action_editUserProfileFragment_to_dialogDeleteAccount)
        }
        setFragmentResultListener(DialogDeleteAccountFragment.REQUEST_ACTION_KEY) { _, bundle ->
            bundle.getBoolean(DialogDeleteAccountFragment.ACTION_BUNDLE_KEY).let { needDelete ->
                if (needDelete) {
                    compositeDisposable.add(userProfileViewModel.deleteProfile().subscribeBy(
                        onComplete = {
                            showToast(R.string.delete_account_complete)
                        },
                        onError = {
                            showToast(R.string.delete_account_error)
                        }
                    ))
                }
            }
        }
    }


    private fun initSocialNetworks(socialNetworkList: List<SocialNetwork>) {
        val materialCardViewList = arrayOf(
            binding.socialNetworkGroup.insta,
            binding.socialNetworkGroup.facebook,
            binding.socialNetworkGroup.twitter,
            binding.socialNetworkGroup.vk,
            binding.socialNetworkGroup.telegram,
            binding.socialNetworkGroup.youtube
        )
        for (i in socialNetworkList.indices) {
            Log.d("save new user data", "socialNetwork $i: ${socialNetworkList[i]}")
            setOnClickSocialNetwork(
                socialNetworkList,
                materialCardViewList[i],
                i,
                socialNetworkList[i]
            )
        }
    }

    private fun setOnClickSocialNetwork(
        socialNetworks: List<SocialNetwork>,
        cardView: MaterialCardView,
        index: Int,
        socialNetwork: SocialNetwork
    ) {
        cardView.setOnClickListener {
            showSocialNetworkDialog(socialNetworks, index, socialNetwork)
        }
    }

    private fun showSocialNetworkDialog(
        socialNetworks: List<SocialNetwork>,
        index: Int,
        socialNetwork: SocialNetwork
    ) {
        findNavController().navigate(
            EditUserProfileFragmentDirections.actionEditUserProfileFragmentToSocialNetworkBottomSheet(
                socialNetwork
            )
        )

        setFragmentResultListener(SocialNetworkBottomSheet.LINK_RESULT_KEY) { _, bundle ->
            bundle.getString(SocialNetworkBottomSheet.LINK_BUNDLE_KEY)?.let {
                socialNetworks[index].link = it
                editUserViewModel.setUser(socialNetworks = socialNetworks)
            }
        }
    }

    private fun onGetUserData() {
        userProfileViewModel.user.observe(viewLifecycleOwner) { state ->
            state.on(
                loading = {
                    with(binding) {
                        scrollContainer.visibility = View.GONE
                        progressBar.visibility = View.VISIBLE
                    }
                },
                success = {
                    editUserViewModel.setUser(it)
                    with(binding) {
                        progressBar.visibility = View.GONE
                        scrollContainer.visibility = View.VISIBLE
                        if (it.isMaster != null && it.isMaster == true) {
                            deleteButton.visibility = View.GONE
                        } else {
                            deleteButton.visibility = View.VISIBLE
                        }
                    }
                }, error = {
                    showToast(R.string.connection_error)
                    findNavController().navigateUp()
                })
        }

        editUserViewModel.user.observe(viewLifecycleOwner) { user ->
            with(binding) {
                user.name?.let {
                    if (it != nameEditText.text.toString()) {
                        nameEditText.text = Editable.Factory.getInstance().newEditable(it)
                    }
                }

                if (user.sex != null) {
                    val index = Sex.values().indexOf(user.sex)
                    spinnerSex.setSelection(index)
                } else {
                    setOnSaveSexListener(Sex.UNDEFINED)
                }

                user.description?.let {
                    if (it != statusEditText.text.toString()) {
                        statusEditText.text = Editable.Factory.getInstance().newEditable(it)
                    }
                }

                user.avatarUrl?.let {
                    loadImageFromOurApi(avatarImageView, it)
                }

                user.phone?.let {
                    phoneCodeTextView.apply {
                        background = ResourcesCompat.getDrawable(
                            resources,
                            R.drawable.shape_et_phone_code_transparent,
                            null
                        )
                        setTextColor(ResourcesCompat.getColor(resources, R.color.gray_90, null))
                        setCountryCode(
                            this,
                            CountryPhone(
                                "",
                                "+${it.phonePrefix}",
                                CountryFlags.valueOf(it.countryCode)
                            )
                        )
                    }
                    phoneNumberTextView.apply {
                        background = ResourcesCompat.getDrawable(
                            resources,
                            R.drawable.shape_et_phone_number_transparent,
                            null
                        )
                        setTextColor(ResourcesCompat.getColor(resources, R.color.gray_90, null))
                        text = it.phone.toPhone(user.phone.countryCode)
                    }
                }

                user.homeLocationId?.let {
                    userProfileViewModel.getLocationById(it)
                }

                user.socialNetworks?.let {
                    if (user.socialNetworks.isNotEmpty()) {
                        initSocialNetworks(it)
                    } else {
                        initSocialNetworks(defaultSocialNetworkList)
                    }
                }
            }
        }
    }

    private fun onPickData() {
        val picChooserContract =
            registerForActivityResult(ActivityResultContracts.GetContent()) { imageUri ->
                imageUri?.let {
                    editAvatarViewModel.setImageUri(it)
                }
            }

        val takePictureContract =
            registerForActivityResult(TakePictureWithUriReturnContract()) { (success, imageUri) ->
                if (success) {
                    imageUri.let {
                        editAvatarViewModel.setImageUri(it)
                    }
                }
            }

        setFragmentResultListener(ChooseEditPhotoAction.REQUEST_EDIT_PHOTO_ACTION_KEY) { _, bundle ->
            val action = bundle.getInt(ChooseEditPhotoAction.EDIT_PHOTO_ACTION_BUNDLE_KEY)
            when (ChooseEditPhotoAction.EditPhotoAction.values()[action]) {
                ChooseEditPhotoAction.EditPhotoAction.CHOOSE -> {
                    picChooserContract.launch(IMAGE)
                }

                ChooseEditPhotoAction.EditPhotoAction.TAKE -> {
                    takePictureContract.launch(getTmpFileUri())
                }

                ChooseEditPhotoAction.EditPhotoAction.DELETE -> {
                    deleteUserAva()
                }
            }
        }
    }

    private fun getTmpFileUri(): Uri {
        val tmpFile =
            File.createTempFile(
                EditUserAvatarFragment.TEMP_FILE_NAME_PREFIX,
                EditUserAvatarFragment.PNG, requireContext().cacheDir
            ).apply {
                createNewFile()
                deleteOnExit()
            }

        return FileProvider.getUriForFile(
            requireContext(),
            "${BuildConfig.APPLICATION_ID}${EditUserAvatarFragment.PROVIDER}",
            tmpFile
        )
    }

    private fun deleteUserAva() {
        val imageUri = Uri.Builder().scheme(ContentResolver.SCHEME_ANDROID_RESOURCE)
            .authority(resources.getResourcePackageName(R.drawable.ic_ava_default))
            .appendPath(resources.getResourceTypeName(R.drawable.ic_ava_default))
            .appendPath(resources.getResourceEntryName(R.drawable.ic_ava_default)).build()

        editAvatarViewModel.setImageUri(imageUri)
    }

    private fun editHomeLocation() {
        findNavController().navigate(
            R.id.action_editUserProfileFragment_to_searchLocationsFragment,
            bundleOf(SearchLocationsFragment.BUNDLE_KEY_IS_USING to false)
        )
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        when (position) {
            0 -> setOnSaveSexListener(Sex.UNDEFINED)
            1 -> setOnSaveSexListener(Sex.MAN)
            2 -> setOnSaveSexListener(Sex.WOMAN)
        }
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
        //TODO("Not yet implemented")
    }

    private fun setOnSaveSexListener(sex: Sex) {
        editUserViewModel.setUser(sex = sex)
    }

    private companion object {
        private const val TAG = "EditUserProfileFragment"
        private const val URI_DELIMITER = "/"
        private const val IMAGE = "image/*"
    }
}


