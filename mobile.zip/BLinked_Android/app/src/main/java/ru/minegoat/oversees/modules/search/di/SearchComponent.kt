package ru.minegoat.oversees.modules.search.di

import dagger.Component
import ru.minegoat.oversees.base.di.AppComponent
import ru.minegoat.oversees.base.di.components.DiComponent
import ru.minegoat.oversees.modules.search.viewmodels.SearchViewModel

@SearchScope
@Component(dependencies = [AppComponent::class], modules = [SearchModule::class])
interface SearchComponent : DiComponent {

    fun searchViewModel(): SearchViewModel.Factory
}