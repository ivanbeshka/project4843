package ru.minegoat.oversees.modules.search.presentation

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.FragmentSearchMastersBinding


class SearchMastersFragment : Fragment(R.layout.fragment_search_masters) {

    private val binding by viewBinding(FragmentSearchMastersBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.etMasterType.setOnClickListener {
            findNavController().navigate(R.id.action_chooseSearchFragment_to_bottomSheetChooseDateFragment)
        }
    }

    companion object {
        @JvmStatic
        fun newInstance(type: SearchType) = SearchMastersFragment()
    }
}