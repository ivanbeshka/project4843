package ru.minegoat.oversees.data.network.chat.model

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.data.db.chat.ChatLinkedObjRoom
import ru.minegoat.oversees.domain.chat.ChatLinkedObjType

data class ChatLinkedObjResponse(
    @SerializedName("linked_obj_id")
    val linkedObjId: String,
    @SerializedName("type")
    val type: String //chat linked obj type
)

fun ChatLinkedObjResponse.toRoom(): ChatLinkedObjRoom {
    return ChatLinkedObjRoom(
        linkedObjId = linkedObjId,
        type = ChatLinkedObjType.valueOf(type)
    )
}
