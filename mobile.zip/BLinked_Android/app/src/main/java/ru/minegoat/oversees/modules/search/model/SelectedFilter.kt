package ru.minegoat.oversees.modules.search.model

data class SelectedFilter(
    val filterType: FilterType,
    val filterValue: CharSequence
)
