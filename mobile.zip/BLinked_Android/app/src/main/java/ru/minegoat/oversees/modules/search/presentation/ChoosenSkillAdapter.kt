package ru.minegoat.oversees.modules.search.presentation

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import ru.minegoat.oversees.databinding.ItemTechnicBinding
import ru.minegoat.oversees.domain.user.Skill

class ChoosenSkillAdapter(
    val listener: RecyclerSkillDescriptionClickListener,
    val checkBoxListener: RecyclerViewCheckBoxClickListener,
) : RecyclerView.Adapter<ChoosenSkillAdapter.ViewHolder>() {

    private val differ = AsyncListDiffer(this, SkillDiffUtilCallback())
    var data: MutableList<Skill>
        get() = differ.currentList
        set(value) = differ.submitList(value)

    inner class ViewHolder(val binding: ItemTechnicBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemTechnicBinding.inflate(inflater, parent, false)
        return ViewHolder(binding)
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val skill = data[position]
        holder.binding.descriptionButton.setOnClickListener { view ->
            listener.onClick(
                view,
                holder.bindingAdapterPosition,
                data[holder.bindingAdapterPosition]
            )
        }

        holder.binding.cbTechnic.setOnClickListener {view ->
            checkBoxListener.onClick(
                view,
                holder.bindingAdapterPosition,
                data[holder.bindingAdapterPosition]
            )
        }

        holder.binding.cbTechnic.text = skill.name
        holder.binding.cbTechnic.isChecked = true

    }

    override fun getItemCount(): Int {
        return data.size
    }

    private class SkillDiffUtilCallback : DiffUtil.ItemCallback<Skill>() {
        override fun areItemsTheSame(oldItem: Skill, newItem: Skill): Boolean {
            return oldItem.objId == newItem.objId
        }

        override fun areContentsTheSame(oldItem: Skill, newItem: Skill): Boolean {
            return oldItem == newItem
        }
    }

}