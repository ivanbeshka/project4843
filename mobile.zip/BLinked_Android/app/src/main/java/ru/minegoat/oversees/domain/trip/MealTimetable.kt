package ru.minegoat.oversees.domain.trip

class MealTimetable(
    val type: String? = null,
    val startTime: Int? = null,
    val endTime: Int? = null,
    val checked: Boolean? = null
)
