package ru.minegoat.oversees.modules.user_profile.presentation

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import androidx.core.os.bundleOf
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.DialogChooseEditPhotoActionBinding

class ChooseEditPhotoAction : DialogFragment(R.layout.dialog_choose_edit_photo_action) {

    private val binding by viewBinding(DialogChooseEditPhotoActionBinding::bind)

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        if (dialog != null && dialog?.window != null) {
            dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog?.window?.requestFeature(Window.FEATURE_NO_TITLE)
        }

        return super.onCreateView(inflater, container, savedInstanceState)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tvChoosePhoto.setOnClickListener {
            setResultAndExit(EditPhotoAction.CHOOSE)
        }

        binding.tvTakePhoto.setOnClickListener {
            setResultAndExit(EditPhotoAction.TAKE)
        }

        binding.tvDeletePhoto.setOnClickListener {
            setResultAndExit(EditPhotoAction.DELETE)
        }
    }

    private fun setResultAndExit(editPhotoAction: EditPhotoAction) {
        setFragmentResult(
            REQUEST_EDIT_PHOTO_ACTION_KEY,
            bundleOf(EDIT_PHOTO_ACTION_BUNDLE_KEY to editPhotoAction.ordinal)
        )
        findNavController().navigateUp()
    }

    enum class EditPhotoAction {
        CHOOSE,
        TAKE,
        DELETE
    }

    companion object {
        const val REQUEST_EDIT_PHOTO_ACTION_KEY = "request_edit_photo_action"
        const val EDIT_PHOTO_ACTION_BUNDLE_KEY = "edit_photo_action_key"
    }
}