package ru.minegoat.oversees.data.network.location

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.base.utils.latitudeLongitudeToLatLng
import ru.minegoat.oversees.domain.location.Location
import ru.minegoat.oversees.domain.location.LocationType
import java.util.*

data class LocationNetwork(
    @SerializedName("syncStatusDateTime")
    val syncStatusTimeSec: Long? = null,
    @SerializedName("syncAction")
    val syncAction: String? = null,
    @SerializedName("searchTags")
    val searchTags: String? = null,
    @SerializedName("objID")
    val objID: String,
    @SerializedName("name")
    val name: String? = null,
    @SerializedName("internationalName")
    val internationalName: String? = null,
    @SerializedName("latitude")
    val latitude: Double? = null,
    @SerializedName("longitude")
    val longitude: Double? = null,
    @SerializedName("type")
    val type: String? = null,
    @SerializedName("descriptionLocation")
    val descriptionLocation: String? = null,
    @SerializedName("cityLocationID")
    val cityLocationID: String? = null,
    @SerializedName("countryLocationID")
    val countryLocationID: String? = null,
    @SerializedName("timeZoneIdentifier")
    val timeZone: String? = null,
    @SerializedName("codeIATA")
    val codeIATA: String? = null, //for airport
    @SerializedName("address")
    val address: String? = null,
    @SerializedName("internationalAddress")
    val internationalAddress: String? = null,
    @SerializedName("phoneNumber")
    val phoneNumber: String? = null,
    @SerializedName("website")
    val website: String? = null,
    @SerializedName("countryCode")
    val countryCode: String? = null,
    @SerializedName("externalID")
    val externalID: String? = null,
    @SerializedName("ownerID")
    val ownerID: String? = null,
    @SerializedName("isUsing")
    val isUsing: Boolean = false,
    @SerializedName("using")
    val using: Boolean = false,
    @SerializedName("wildCity")
    val wildCity: Boolean = false,
)

fun LocationNetwork.toLocation(countryLocation: Location?, cityLocation: Location?): Location {
    return Location(
        objID = objID,
        name = name,
        internationalName = internationalName,
        latLng = latitudeLongitudeToLatLng(latitude, longitude),
        type = type?.uppercase()?.let { LocationType.valueOf(it) },
        descriptionLocation = descriptionLocation,
        timeZone = TimeZone.getTimeZone(timeZone),
        codeIATA = codeIATA,
        address = address,
        countryCode = countryCode,
        website = website,
        externalID = externalID,
        phoneNumber = phoneNumber,
        ownerID = ownerID,
        isUsing = isUsing,
        wildCity = wildCity,
        internationalAddress = internationalAddress,
        cityLocation = if (cityLocation?.objID == cityLocationID) cityLocation else null,
        countryLocation = if (countryLocation?.objID == countryLocationID) countryLocation else null
    )
}
