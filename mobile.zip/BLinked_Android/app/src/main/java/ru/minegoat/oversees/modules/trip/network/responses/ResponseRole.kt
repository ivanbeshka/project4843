package ru.minegoat.oversees.modules.trip.network.responses

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.user.UserRole

data class ResponseRole(
    @SerializedName("id")
    val id: String?,
    @SerializedName("name")
    val name: String?,
)

fun ResponseRole.toBusiness(): UserRole {
    return UserRole(
        name = name,
        id = id
    )
}