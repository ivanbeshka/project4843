package ru.minegoat.oversees.modules.search.presentation

import android.content.res.Resources
import android.os.Bundle
import android.view.View
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import ru.minegoat.oversees.R
import ru.minegoat.oversees.databinding.FragmentBottomSheetChooseMasterBinding

class BottomSheetChooseMasterFragment : BottomSheetDialogFragment(R.layout.fragment_bottom_sheet_choose_master) {
   private val binding by viewBinding(FragmentBottomSheetChooseMasterBinding::bind)

   override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
      super.onViewCreated(view, savedInstanceState)
      binding.llBottomsheet.minimumHeight = Resources.getSystem().displayMetrics.heightPixels
   }
}