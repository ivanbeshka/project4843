package ru.minegoat.oversees.modules.user_profile.presentation

import android.view.View
import ru.minegoat.oversees.modules.user_profile.model.ShortMasterUi

interface MastersRecyclerClickListener {
    fun onClick(v: View, position: Int, master: ShortMasterUi)
}