package ru.minegoat.oversees.data.db.master

import io.realm.kotlin.types.annotations.PrimaryKey
import io.realm.kotlin.types.ObjectId
import io.realm.kotlin.types.RealmObject

class MasterTypeRealm():RealmObject {
    @PrimaryKey
    var id: ObjectId = ObjectId.create()
    val objId: String
        get() {
            return id.toString()
        }

    var name: String? = null
    var masterTypeDescription: String? = null

    constructor(
        objId: String,
        name: String,
        masterTypeDescription: String? = null
    ) : this(){
        this.id = ObjectId.Companion.from(objId)
        this.name = name
        this.masterTypeDescription = masterTypeDescription
    }
}