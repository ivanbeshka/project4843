package ru.minegoat.oversees.base.utils.ui.dialogs

import android.Manifest.permission
import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import ru.minegoat.oversees.R

/**
 * A dialog that explains the use of the location permission and requests the necessary
 * permission.
 */
class LocationRationaleDialog : DialogFragment() {
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val requestCode =
            arguments?.getInt(ARGUMENT_PERMISSION_REQUEST_CODE) ?: 0
        return AlertDialog.Builder(activity)
            .setMessage(R.string.permission_rationale_location)
            .setPositiveButton(R.string.ok) { _, _ -> // After click on Ok, request the permission.
                ActivityCompat.requestPermissions(
                    requireActivity(),
                    arrayOf(
                        permission.ACCESS_FINE_LOCATION,
                        permission.ACCESS_COARSE_LOCATION
                    ),
                    requestCode
                )
            }
            .setNegativeButton(R.string.cancel, null)
            .create()
    }

    override fun onStart() {
        super.onStart()
        val colorOrange = ContextCompat.getColor(requireContext(), R.color.orange)
        (dialog as AlertDialog?)!!.getButton(AlertDialog.BUTTON_POSITIVE)
            .setTextColor(colorOrange)
        (dialog as AlertDialog?)!!.getButton(AlertDialog.BUTTON_NEGATIVE)
            .setTextColor(colorOrange)
    }

    companion object {
        private const val ARGUMENT_PERMISSION_REQUEST_CODE = "requestCode"

        fun newInstance(
            requestCode: Int
        ): LocationRationaleDialog {
            val arguments = Bundle().apply {
                putInt(ARGUMENT_PERMISSION_REQUEST_CODE, requestCode)
            }
            return LocationRationaleDialog().apply {
                this.arguments = arguments
            }
        }
    }
}
