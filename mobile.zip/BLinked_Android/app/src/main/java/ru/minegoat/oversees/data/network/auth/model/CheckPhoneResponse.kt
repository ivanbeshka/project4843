package ru.minegoat.oversees.data.network.auth.model

import com.google.gson.annotations.SerializedName

data class CheckPhoneResponse(
    @SerializedName("items")
    val items: List<CheckPhone>
)