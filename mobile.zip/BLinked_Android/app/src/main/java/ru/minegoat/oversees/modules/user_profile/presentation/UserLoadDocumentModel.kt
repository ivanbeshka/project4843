package ru.minegoat.oversees.modules.user_profile.presentation

data class UserLoadDocumentModel(
    val fileName: String,
    val image: Int,
)
