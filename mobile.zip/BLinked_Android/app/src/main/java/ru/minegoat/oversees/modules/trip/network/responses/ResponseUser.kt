package ru.minegoat.oversees.modules.trip.network.responses

import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.domain.user.ShortUser

data class ResponseUser(
    @SerializedName("id")
    val id: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("role")
    val role: ResponseRole?,
    @SerializedName("avatar")
    val avatar: String?,
)

fun ResponseUser.toBusiness(): ShortUser {
    return ShortUser(
        userId = id,
        name = name,
        role = role?.toBusiness(),
        avatar = avatar,
    )
}