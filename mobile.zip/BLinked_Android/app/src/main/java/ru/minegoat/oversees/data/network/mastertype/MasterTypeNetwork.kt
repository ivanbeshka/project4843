package ru.minegoat.oversees.data.network.mastertype

import android.util.Log
import com.google.gson.annotations.SerializedName
import ru.minegoat.oversees.data.db.master.MasterTypeRealm

data class MasterTypeNetwork (
    @SerializedName("syncStatusDateTime")
    val syncStatusTimeSec: Long,
    @SerializedName("objID")
    val objID: String,
    @SerializedName("masterTypeName")
    val name: String,
    @SerializedName("masterTypeDescription")
    val masterTypeDescription: String? = null
)

fun MasterTypeNetwork.toMasterTypeRealm(): MasterTypeRealm =
    MasterTypeRealm(objID, name, masterTypeDescription).apply {
        Log.d("VVVVV", "MasterTypeNetwork.toMasterTypeRealm = $this")
    }