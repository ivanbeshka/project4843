package ru.minegoat.oversees.modules.master_profile.viewmodels

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.base.viewmodels.RxViewModel
import ru.minegoat.oversees.data.repository.comment.CommentRepository
import ru.minegoat.oversees.domain.feedback.Comment

class CommentViewModel @AssistedInject constructor(
    private val repository: CommentRepository
) : RxViewModel() {

    private val compositeDisposable by lazy { CompositeDisposable() }

    private val _comments = MutableLiveData<List<Comment>>()
    val comments: LiveData<List<Comment>> = _comments

    fun saveComment(comment: Comment) {
        compositeDisposable.add(
            repository.saveComment(comment = comment, linkedObjId = "0")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                    onComplete = {
                        Log.d("MyLog", "save comment: complete")
                    },
                    onError = {
                        Log.d("MyLog", "save comment: ${it.message}")
                    }
                )
        )
    }

    fun getComments() {
        compositeDisposable.add(
            repository.getComments("0")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeBy(
                    onSuccess = {
                        _comments.postValue(it)
                    },
                    onError = {
                        Log.d("MyLog", "get comment: ${it.message}")
                    }
                )
        )
    }

    @AssistedFactory
    interface Factory {
        fun create(): CommentViewModel
    }
}