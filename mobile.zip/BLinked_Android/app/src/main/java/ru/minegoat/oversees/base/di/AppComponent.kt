package ru.minegoat.oversees.base.di

import dagger.Component
import io.realm.kotlin.Realm
import retrofit2.Retrofit
import ru.minegoat.oversees.base.db.realm.RealmDataStorage
import ru.minegoat.oversees.base.db.room.RoomDB
import ru.minegoat.oversees.base.di.modules.*
import ru.minegoat.oversees.base.helpers.file_manager.FileManager
import ru.minegoat.oversees.base.helpers.auth.Authenticator
import ru.minegoat.oversees.base.helpers.messenger.Messenger
import ru.minegoat.oversees.base.helpers.syncer.Syncer
import ru.minegoat.oversees.base.utils.LocationUtils
import ru.minegoat.oversees.data.repository.document.DocumentRepository
import ru.minegoat.oversees.data.repository.comment.CommentRepository
import ru.minegoat.oversees.data.repository.location.LocationRepository
import ru.minegoat.oversees.data.repository.skill.SkillRepository
import ru.minegoat.oversees.data.repository.user.UserRepository
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import javax.inject.Singleton

@Singleton
@Component(
    modules = [
        AppModule::class,
        RealmModule::class,
        RoomModule::class,
        RetrofitModule::class,
        UtilsModule::class,
        LocationModule::class,
        SyncerModule::class,
        MessengerModule::class,
        AuthModule::class,
        UserModule::class,
        FileManagerModule::class,
        DocumentRepositoryModule::class,
        CommentRepositoryModule::class
    ]
)
interface AppComponent {

    //base
    fun realm(): Realm

    fun room(): RoomDB

    fun retrofit(): Retrofit

    fun tokenPref(): AuthSharedPref

    fun dataStorage(): RealmDataStorage

    //helpers
    fun syncer(): Syncer

    fun messenger(): Messenger

    fun authenticator(): Authenticator

    //other
    fun locationRepository(): LocationRepository
    fun locationUtils(): LocationUtils

    fun userRepository(): UserRepository

    fun skillRepository(): SkillRepository

    fun fileManager(): FileManager

    fun documentRepository(): DocumentRepository

    fun commentRepository(): CommentRepository
    //also global viewmodels, api, and some dependencies
}