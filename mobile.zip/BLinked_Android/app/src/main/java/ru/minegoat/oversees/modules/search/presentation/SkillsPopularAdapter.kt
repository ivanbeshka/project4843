package ru.minegoat.oversees.modules.search.presentation

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import ru.minegoat.oversees.databinding.ItemCardTechnicBinding
import ru.minegoat.oversees.domain.user.Skill

class SkillsPopularAdapter(
    val listener: RecyclerSkillDescriptionClickListener
) : RecyclerView.Adapter<SkillsPopularAdapter.ViewHolder>() {

    private val differ = AsyncListDiffer(this, SkillDiffUtilCallback())
    var data: List<Skill>
        get() = differ.currentList
        set(value) = differ.submitList(value)
    inner class ViewHolder(val binding: ItemCardTechnicBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemCardTechnicBinding.inflate(inflater, parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val skill = data[position]
        holder.binding.skill = skill
        holder.binding.apply {
            tvTechnicName.text = skill.name
            tvTechnicDescription.text = skill.skillDescription
            cvSkillItem.setOnClickListener{view ->
                listener.onClick(
                    view,
                    holder.bindingAdapterPosition,
                    data[holder.bindingAdapterPosition]
                )
            }
        }

    }

    override fun getItemCount(): Int {
        return data.size
    }

    private class SkillDiffUtilCallback : DiffUtil.ItemCallback<Skill>() {
        override fun areItemsTheSame(oldItem: Skill, newItem: Skill): Boolean {
            return oldItem.objId == newItem.objId
        }

        override fun areContentsTheSame(oldItem: Skill, newItem: Skill): Boolean {
            return oldItem == newItem
        }
    }

}