package ru.minegoat.oversees.modules.chat.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import ru.minegoat.oversees.base.viewmodels.ErrorScreenState
import ru.minegoat.oversees.base.viewmodels.RxViewModel
import ru.minegoat.oversees.base.viewmodels.ScreenState
import ru.minegoat.oversees.base.viewmodels.SuccessScreenState
import ru.minegoat.oversees.data.sharedpref.AuthSharedPref
import ru.minegoat.oversees.modules.chat.model.*
import ru.minegoat.oversees.modules.chat.presentation.ChatListVPItemFragment.ChatListType
import ru.minegoat.oversees.modules.chat.presentation.MessageListAdapter
import ru.minegoat.oversees.modules.chat.repository.ChatListRepository
import java.util.concurrent.TimeUnit

class ChatListVPItemViewModel @AssistedInject constructor(
    private val chatNamePredicateSubManager: ChatNamePredicateSubManager,
    private val unreadMsgCountForTabsSubManager: UnreadMsgCountForTabsSubManager,
    private val repo: ChatListRepository,
    private val authSharedPref: AuthSharedPref
) : RxViewModel() {

    private var isFirstGetChatListItems = true

    val shortChatTrip = ShortChatUi(
        "qwwqwqwwqw",
        "Чат для путешествия!",
        ChatListType.GROUPS,
        "https://klike.net/uploads/posts/2020-05/1588837021_5.jpg",
        "16 окт - 12 ноя 2022"
    )

    val lastMessageTrip = MessageUi(
        "roeworuowerowerowr",
        "fksdjfsdjflksdfj",
        "Маша",
        "qwwqwqwwqw",
        "Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!",
        "12:30",
        "12.12.12",
        0,
        MessageListAdapter.MessageItemType.MY
    )

    val shortChatService = ShortChatUi(
        "fjsdlfjsdci",
        "Чат для бронирования сервиса!",
        ChatListType.PRIVATE,
        "https://static8.depositphotos.com/1229718/1053/i/450/depositphotos_10534574-stock-photo-important-date.jpg"
    )

    val lastMessageService = MessageUi(
        "ruuerwoqoerewr",
        "fksdjfsdj",
        "Маша",
        "fjsdlfjsdci",
        "Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!Привет!!!!!!!",
        "12:30",
        "12.12.12",
        0,
        MessageListAdapter.MessageItemType.MY
    )

    private val chatListItems = MutableLiveData<ScreenState<List<ChatItemUi>>>()

    val chatList = listOf(
        ChatItemUi(
            shortChatTrip,
            lastMessageTrip,
            1
        ),
        ChatItemUi(
            shortChatService,
            lastMessageService,
            1000
        ),
        ChatItemUi(
            shortChatTrip,
            lastMessageTrip,
            101
        ),
        ChatItemUi(
            shortChatService,
            lastMessageService,
            1
        ),
        ChatItemUi(
            shortChatTrip,
            lastMessageTrip,
            1443
        ),
        ChatItemUi(
            shortChatService,
            lastMessageService,
            1
        ),
        ChatItemUi(
            shortChatTrip,
            lastMessageTrip,
            123
        ),
        ChatItemUi(
            shortChatService,
            lastMessageService,
            11111
        ),
        ChatItemUi(
            shortChatTrip,
            lastMessageTrip,
            1569
        ),
        ChatItemUi(
            shortChatService,
            lastMessageService,
            9999
        ),
        ChatItemUi(
            shortChatTrip,
            lastMessageTrip,
            1
        ),
        ChatItemUi(
            shortChatService,
            lastMessageService,
            1
        ),
        ChatItemUi(
            shortChatTrip,
            lastMessageTrip,
            2
        ),
        ChatItemUi(
            shortChatService,
            lastMessageService,
            0
        ),
        ChatItemUi(
            shortChatTrip,
            lastMessageTrip,
            1
        ),
        ChatItemUi(
            shortChatService,
            lastMessageService,
            0
        ),
        ChatItemUi(
            shortChatTrip,
            lastMessageTrip,
            1
        ),
        ChatItemUi(
            shortChatService,
            lastMessageService,
            1
        ),
        ChatItemUi(
            shortChatTrip,
            lastMessageTrip,
            1
        ),
        ChatItemUi(
            shortChatService,
            lastMessageService,
            1
        ),
        ChatItemUi(
            shortChatTrip,
            lastMessageTrip,
            1
        ),
        ChatItemUi(
            shortChatService,
            lastMessageService,
            1
        ),
        ChatItemUi(
            shortChatTrip,
            lastMessageTrip,
            1
        ),
        ChatItemUi(
            shortChatService,
            lastMessageService,
            1
        ),
    )

    fun getChatListItems(
        type: ChatListType
    ): LiveData<ScreenState<List<ChatItemUi>>> {
//        repo.getChatListItems()
//            .subscribeOn(Schedulers.io())
//            .observeOn(AndroidSchedulers.mainThread())
//            .doOnSubscribe { chatListItems.value = LoadingScreenState() }
//            .subscribeBy(
//                onNext = {
//                    chatListItems.value = SuccessScreenState(it)
//                },
//                onError = {
//                    chatListItems.value = ErrorScreenState(it)
//                }
//            )
//            .disposeOnFinish()


        chatNamePredicateSubManager.get()
            .map { it.trim() }
            .distinctUntilChanged()
            .debounce(DEBOUNCE_TIMEOUT, TimeUnit.MICROSECONDS)
            //todo
//            .switchMap { predicate ->
//
//            }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeBy(
                onNext = { predicate ->
                    val filteredChatList = chatList
                        .filter { //todo do this in switchMap, up
                            (it.chat.type == type || type == ChatListType.ALL)
                                    && it.chat.name.contains(predicate, true)
                        }

                    unreadMsgCountForTabsSubManager.onNext(
                        UnreadMsgCountForTabs.UnreadMsgCountTabUi(
                            type,
                            filteredChatList.filter { it.unreadMessagesCount > 0 }.size)
                    )

                    chatListItems.value = SuccessScreenState(filteredChatList)
                },
                onError = {
                    chatListItems.value = ErrorScreenState(it)
                }
            )
            .disposeOnFinish()

        return chatListItems
    }

    private companion object {
        private const val DEBOUNCE_TIMEOUT = 500L
    }

    @AssistedFactory
    interface Factory {
        fun create(): ChatListVPItemViewModel
    }
}