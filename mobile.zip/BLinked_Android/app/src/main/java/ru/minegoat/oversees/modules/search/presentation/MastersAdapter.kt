package ru.minegoat.oversees.modules.search.presentation

import android.view.LayoutInflater

import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import ru.minegoat.oversees.databinding.ItemMasterBinding
import ru.minegoat.oversees.domain.user.ShortUser

class MastersAdapter(
    private val onEventClick: (objID: String) -> Unit
) : RecyclerView.Adapter<MastersAdapter.ViewHolder>() {

    private val differ = AsyncListDiffer(this, MasterDiffUtilCallback())
    var data: List<ShortUser>
        get() = differ.currentList
        set(value) = differ.submitList(value)

    inner class ViewHolder(val binding: ItemMasterBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemMasterBinding.inflate(inflater, parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val user = data[position]
        holder.binding.user = user

        holder.binding.cvEvent.setOnClickListener {
            onEventClick(user.userId)
        }

    }

    override fun getItemCount(): Int {
        return data.size
    }

    private class MasterDiffUtilCallback : DiffUtil.ItemCallback<ShortUser>() {
        override fun areItemsTheSame(oldItem: ShortUser, newItem: ShortUser): Boolean {
            return oldItem.userId == newItem.userId
        }

        override fun areContentsTheSame(oldItem: ShortUser, newItem: ShortUser): Boolean {
            return oldItem == newItem
        }
    }

}