package ru.minegoat.oversees.modules.chat.di

import dagger.Component
import ru.minegoat.oversees.base.di.AppComponent
import ru.minegoat.oversees.base.di.components.DiComponent
import ru.minegoat.oversees.base.di.modules.MessageTransportModule
import ru.minegoat.oversees.modules.chat.viewmodels.ChatListVPItemViewModel
import ru.minegoat.oversees.modules.chat.viewmodels.ChatListViewModel
import ru.minegoat.oversees.modules.chat.viewmodels.ChatViewModel

@ChatScope
@Component(dependencies = [AppComponent::class], modules = [ChatModule::class,MessageTransportModule::class])
interface ChatComponent : DiComponent {

    fun chatListViewModel(): ChatListViewModel.Factory
    fun chatListVPItemViewModel(): ChatListVPItemViewModel.Factory
    fun chatViewModel(): ChatViewModel.Factory
}