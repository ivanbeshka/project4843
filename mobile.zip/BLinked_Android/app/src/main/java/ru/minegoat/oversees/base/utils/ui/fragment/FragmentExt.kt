package ru.minegoat.oversees.base.utils.ui.fragment

import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.di.components.DiComponent
import ru.minegoat.oversees.base.di.holders.FeatureComponentHolder
import ru.minegoat.oversees.base.viewmodels.Factory
import ru.minegoat.oversees.databinding.CustomToastBinding
import kotlin.properties.ReadOnlyProperty

fun <Holder : FeatureComponentHolder<Component>, Component : DiComponent> Fragment.featureComponent(
    holder: Holder
): ReadOnlyProperty<Fragment, Component> {
    return FragmentComponentHolderProperty(holder)
}

inline fun <reified T : ViewModel> Fragment.lazyViewModel(
    noinline create: (stateHandle: SavedStateHandle) -> T
) = viewModels<T> {
    Factory(this, create)
}

inline fun <reified T : ViewModel> Fragment.lazyActivityViewModel(
    noinline create: (stateHandle: SavedStateHandle) -> T
) = activityViewModels<T> {
    Factory(this, create)
}

fun Fragment.showToast(stringRes: Int) {
    showToast(getString(stringRes))
}

fun Fragment.showToast(message: String) {
    Toast.makeText(context, message, Toast.LENGTH_LONG).apply {
        setGravity(Gravity.TOP, 0, 80)
    }.show()
}

fun Fragment.showSpecialToast(icon: Int = R.drawable.ic_toast, header: String, message: String?) {
    val binding = CustomToastBinding.inflate(layoutInflater)
    with (binding){
        if (icon != R.drawable.ic_toast)
            this.icon.setImageResource(icon)
        headerTextView.text = header
        message?.run {
            messageTextView.text = this
            messageTextView.visibility= View.VISIBLE
        }
    }

    Toast(requireContext()).apply {
        view = binding.root
        setGravity(Gravity.TOP or Gravity.FILL_HORIZONTAL, 0, 80)
        duration = Toast.LENGTH_SHORT
        show()
    }

}

fun Fragment.showKeyboard(editText: EditText) {
    val imm = requireContext()
        .getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    imm.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT)
}