package ru.minegoat.oversees.modules.user_profile.presentation

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.loadImageFromOurApi
import ru.minegoat.oversees.databinding.ItemMasterCardBinding
import ru.minegoat.oversees.modules.user_profile.model.ShortMasterUi

class MasterListAdapter(
    val listener: MastersRecyclerClickListener
) :
    RecyclerView.Adapter<MasterListAdapter.MasterListViewHolder>() {

    private val differ = AsyncListDiffer(this, MasterDiffUtilCallback())
    var masters: List<ShortMasterUi>
        get() = differ.currentList
        set(value) = differ.submitList(value)


    inner class MasterListViewHolder(root: View) : RecyclerView.ViewHolder(root){
        private val binding by viewBinding(ItemMasterCardBinding::bind)
        fun bind(master: ShortMasterUi) = with(binding){

            master.sumKarma?.let {
                chipCarmaCount.text = it.toString()
                if (it >= 0) {
                    chipCarmaCount.setTextColor(root.resources.getColor(R.color.primary_100))
                    chipCarmaCount.setChipIconTintResource(R.color.primary_100)
                } else {
                    chipCarmaCount.setTextColor(root.resources.getColor(R.color.red))
                    chipCarmaCount.setChipIconTintResource(R.color.red)
                }
            }

            if(master.avatarUrl != null){
                loadImageFromOurApi(ivMasterPhoto, master.avatarUrl)
            }
            tvMasterName.text = master.name
            clItemMaster.setOnClickListener{view ->
                listener.onClick(
                    view,
                    bindingAdapterPosition,
                    masters[bindingAdapterPosition]
                )
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MasterListViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_master_card, parent, false)
        return MasterListViewHolder(view)
    }

    override fun getItemCount(): Int = masters.size

    override fun onBindViewHolder(holder: MasterListViewHolder, position: Int) {
        holder.bind(masters[position])
    }

    private class MasterDiffUtilCallback : DiffUtil.ItemCallback<ShortMasterUi>() {
        override fun areItemsTheSame(oldItem: ShortMasterUi, newItem: ShortMasterUi): Boolean {
            return oldItem.objID == newItem.objID
        }

        override fun areContentsTheSame(oldItem: ShortMasterUi, newItem: ShortMasterUi): Boolean {
            return oldItem == newItem
        }
    }
}