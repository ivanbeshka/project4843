package ru.minegoat.oversees.base.utils.ui

import android.graphics.Rect
import android.view.View
import android.widget.LinearLayout
import androidx.recyclerview.widget.RecyclerView

//Params:
//orientation – Divider orientation. Should be LinearLayout.HORIZONTAL or LinearLayout.VERTICAL.
class SpaceDividerItemDecoration(
    private val spaceSizePx: Int,
    private val orientation: Int,
    private val startSpaceSizePx: Int? = null,
) : RecyclerView.ItemDecoration() {

    override fun getItemOffsets(
        outRect: Rect,
        view: View,
        parent: RecyclerView,
        state: RecyclerView.State
    ) {
        if (orientation == LinearLayout.HORIZONTAL) {
            with(outRect) {
                if (parent.getChildAdapterPosition(view) == START_POS) {
                    left = startSpaceSizePx ?: spaceSizePx
                }
                right = spaceSizePx
            }
        } else if (orientation == LinearLayout.VERTICAL) {
            with(outRect) {
                if (parent.getChildAdapterPosition(view) == START_POS) {
                    top = startSpaceSizePx ?: spaceSizePx
                }
                bottom = spaceSizePx
            }
        }
    }

    private companion object {
        private const val START_POS = 0
    }
}