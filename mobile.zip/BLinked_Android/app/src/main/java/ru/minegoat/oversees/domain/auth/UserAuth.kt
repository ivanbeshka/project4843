package ru.minegoat.oversees.domain.auth

import java.time.LocalDateTime

data class UserAuth(
    val id: Int,
    val username: String,
    val userIdentifier: String,
    val roles: List<Role> = arrayListOf(),
    val password: String,
    val apiToken: String,
    val salt: String? = null,
    val phone: String? = null,
    val description: String? = null,
    val isGuide: Boolean = false,
    val name: String? = null,
    val avatar: String? = null,
    val lastSuccessfulSyncDate: String? = null,
    val lastSyncTryDate: String? = null,
    val tripsRoles: ArrayList<String> = arrayListOf(),
    val apiTokenExpiresAt: LocalDateTime,
    val tokenExpired: Boolean = false
)
