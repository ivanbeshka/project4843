package ru.minegoat.oversees.modules.master_profile.presentation

import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import by.kirich1409.viewbindingdelegate.viewBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import ru.minegoat.oversees.R
import ru.minegoat.oversees.base.utils.ui.fragment.featureComponent
import ru.minegoat.oversees.base.utils.ui.fragment.lazyViewModel
import ru.minegoat.oversees.databinding.BottomSheetSocialNetworkLinkBinding
import ru.minegoat.oversees.modules.user_profile.di.UserProfileComponentHolder

class SocialNetworkBottomSheet :
    BottomSheetDialogFragment(R.layout.bottom_sheet_social_network_link) {

    private val component by featureComponent(UserProfileComponentHolder)

    private val viewModel by lazyViewModel {
        component.editUserProfileViewModel().create()
    }

    private val args: SocialNetworkBottomSheetArgs by navArgs()
    private val socialNetwork by lazy { args.socialNetwork }

    private val binding by viewBinding(BottomSheetSocialNetworkLinkBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        with(binding) {

            tvSocialNetworkName.text = getString(socialNetwork.name.res)
            socialNetwork.link?.let {
                etLink.setText(socialNetwork.link)
            }

            var link = ""

            saveButton.setOnClickListener {
                if (etLink.text.isNotEmpty()) link = etLink.text.toString()
                setFragmentResult(
                    LINK_RESULT_KEY,
                    bundleOf(
                        LINK_BUNDLE_KEY to link
                    )
                )
                findNavController().navigateUp()
            }

        }
    }

    companion object {
        const val LINK_RESULT_KEY = "link_result"
        const val LINK_BUNDLE_KEY = "link_bundle"
    }


}